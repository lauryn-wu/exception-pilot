# Wording preview — no model calls

20 fresh lists × 2 targets × 2 backgrounds × 2 questions × 3 instructions = 480 calls in the default config. This preview includes every first-list request.

All conditions share the verified record table and target attributes. Both backgrounds have 20% exceptions; only six non-target labels change.

## Exact question and response wording

### Question: original

Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.

### Question: recorded

Which class, A or B, is recorded for this vehicle in the table above?

### Response: direct

Reply with only A or B.

### Response: cot_classification

Work through the classification, then put A or B alone on the final line.

### Response: cot_neutral

Think step by step, then put A or B alone on the final line.

## All 24 first-list requests

Condition headings and answer keys below are for human inspection, never extra API content.

### wd-list-000/2/support/original/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### wd-list-000/5/support/original/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/2/conflict/recorded/cot_classification

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/5/conflict/original/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/2/conflict/original/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/2/conflict/recorded/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/2/conflict/original/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### wd-list-000/2/support/original/cot_classification

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/5/support/original/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### wd-list-000/5/conflict/recorded/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/2/support/recorded/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### wd-list-000/2/conflict/original/cot_classification

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/2/support/recorded/cot_classification

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/2/conflict/recorded/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### wd-list-000/2/support/original/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/5/conflict/recorded/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### wd-list-000/5/support/recorded/cot_classification

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/5/conflict/original/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### wd-list-000/2/support/recorded/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WQL7RX
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/5/support/recorded/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### wd-list-000/5/conflict/original/cot_classification

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/5/conflict/recorded/cot_classification

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | B |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | B |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | A |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | A |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | A |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | B |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Work through the classification, then put A or B alone on the final line.
```

### wd-list-000/5/support/recorded/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### wd-list-000/5/support/original/cot_classification

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| WQ7N8P | Built for desert heat | Manual | Vinyl | Four | A |
| WY9WXW | Equipped for hot sand | Manual | Cloth | Two | A |
| WQL7RX | Operates on polar ice | Automatic | Cloth | Two | B |
| WEUWPP | Operates in tropical forests | Manual | Cloth | Two | B |
| W96G6U | Built for subzero temperatures | Manual | Cloth | Two | B |
| WZD7DT | Designed for humid summers | Automatic | Cloth | Four | A |
| WUKDV5 | Equipped with snow tracks | Automatic | Cloth | Two | B |
| WDD6WS | Designed for frozen terrain | Automatic | Cloth | Four | A |
| WUQ9MM | Used at an Arctic station | Manual | Cloth | Two | B |
| WYQSM5 | Used at an equatorial station | Manual | Vinyl | Two | A |

License plate: WZD7DT
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Work through the classification, then put A or B alone on the final line.
```

