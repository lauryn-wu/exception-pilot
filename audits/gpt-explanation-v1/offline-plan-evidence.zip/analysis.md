# GPT matched explanation diagnostic

UNEXECUTED: 0/192 fresh GPT responses returned.
**INCOMPLETE: not a completed experiment.**

Pending: 192; failed: 0; ambiguous: 0; cached in this invocation: 0.
Fixed-budget invalid/truncated/refusal returns count as unsuccessful. Infrastructure-unavailable outcomes remain unavailable: incomplete arm accuracies and primary contrast are undefined, with accuracy bounds shown.

| Arm | Background | Correct / planned | Unavailable | Invalid | Truncated |
|---|---|---:|---:|---:|---:|
| direct | support | 0/48 | 48 | 0 | 0 |
| direct | conflict | 0/48 | 48 | 0 | 0 |
| explanation | support | 0/48 | 48 | 0 | 0 |
| explanation | conflict | 0/48 | 48 | 0 | 0 |

Primary contrast: None; four-block 95% interval: None.
Observed priced usage: $0.000000; dispatches missing a complete cost estimate: 0.
Category counts, paired changes, eligibility, model identities and ordered output messages are in analysis.json.

- Four construction blocks are the primary resampling units; the 24-world interval is a sensitivity analysis. The 192 responses are not independent worlds.
- An all-perfect [0, 0] bootstrap interval only resamples observed outcomes and does not establish population certainty.
- This tests an explanation request at fixed API reasoning.effort=none; that setting does not prove absence of internal reasoning.
- Written output and the instruction effect on task interpretation are not isolated. No mechanism, novelty, or project-success claim follows automatically.
- The requested model is an alias, not a dated snapshot. Returned identifiers and timestamps document what was observed, not snapshot-level reproducibility.
- Nonempty preceding text is only explanation-format compliance; semantic annotations remain not reviewed.
- Inputs and analysis were chosen after observing the Qwen screen. Qwen responses are not GPT controls.

STOP_AFTER_192_SCIENTIFIC_REQUESTS_NO_AUTOMATIC_EXPANSION
