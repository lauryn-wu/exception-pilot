# Constrained answer-revision preview — no API calls

24 fresh worlds × 2 recorded-class variants × 4 conditions = 192 planned calls. The cumulative cap is 224 attempts, including explicitly requested transport retries.

This document shows the eight exact user messages from the first world, common request settings, and each arm's exact schema. preview.json contains all 192 exact requests. Each request starts an independent conversation. The shared MISSING definition is unchanged; all target cells are recorded. These are fresh tables.

Within each pair (the original order anchors and the new revision/control arms), user messages are identical and schemas differ only in the serialized order of schema properties. Actual returned JSON key order is checked. Nonempty reasoning text is required, without judging its quality or truth. Any returned schema, order, empty-reasoning, or technical failure is retained and stops collection; do not resample or resume past it. Headings and answer keys below are not added to API messages.

## Request settings shared by all arms

```json
{
  "model": "gpt-4o-2024-08-06",
  "temperature": 0.0,
  "max_completion_tokens": 1000,
  "n": 1,
  "store": false
}
```

## Exact response format: reasoning_first

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "reasoning": {
          "type": "string"
        },
        "answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        }
      },
      "required": [
        "answer",
        "reasoning"
      ],
      "additionalProperties": false
    }
  }
}
```

## Exact response format: answer_first

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        },
        "reasoning": {
          "type": "string"
        }
      },
      "required": [
        "answer",
        "reasoning"
      ],
      "additionalProperties": false
    }
  }
}
```

## Exact response format: revision

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "initial_answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        },
        "reasoning": {
          "type": "string"
        },
        "final_answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        }
      },
      "required": [
        "initial_answer",
        "reasoning",
        "final_answer"
      ],
      "additionalProperties": false
    }
  }
}
```

## Exact response format: repeat_control

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "initial_answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        },
        "final_answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        },
        "reasoning": {
          "type": "string"
        }
      },
      "required": [
        "initial_answer",
        "reasoning",
        "final_answer"
      ],
      "additionalProperties": false
    }
  }
}
```

## revision-list-000/record_1/answer_first

Recorded class: A; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## revision-list-000/record_2/reasoning_first

Recorded class: C; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## revision-list-000/record_2/revision

Recorded class: C; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with three fields, "initial_answer", "reasoning", and "final_answer". Set both answer fields to A, B, or C and write your reasoning in "reasoning". Your final answer may match or differ from your initial answer.
```

## revision-list-000/record_2/answer_first

Recorded class: C; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## revision-list-000/record_1/revision

Recorded class: A; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with three fields, "initial_answer", "reasoning", and "final_answer". Set both answer fields to A, B, or C and write your reasoning in "reasoning". Your final answer may match or differ from your initial answer.
```

## revision-list-000/record_2/repeat_control

Recorded class: C; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with three fields, "initial_answer", "reasoning", and "final_answer". Set both answer fields to A, B, or C and write your reasoning in "reasoning". Your final answer may match or differ from your initial answer.
```

## revision-list-000/record_1/repeat_control

Recorded class: A; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with three fields, "initial_answer", "reasoning", and "final_answer". Set both answer fields to A, B, or C and write your reasoning in "reasoning". Your final answer may match or differ from your initial answer.
```

## revision-list-000/record_1/reasoning_first

Recorded class: A; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| VFHF9P | Equipped with snow tracks | Automatic | Vinyl | Four | X | B |
| V7JELQ | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| VND5MN | Operates on polar ice | Automatic | Vinyl | Four | Y | B |
| VPVJK9 | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| VGGTHV | Used at an Arctic station | Automatic | Vinyl | Four | Z | B |
| VFG47J | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| VS26AK | Built for desert heat | Manual | Cloth | Two | Y | A |
| VLN56V | Equipped for hot sand | Manual | Vinyl | Two | X | C |
| VHFQRF | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| V7GBQK | Designed for humid summers | Manual | Vinyl | Four | X | A |

License plate: VFG47J
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```
