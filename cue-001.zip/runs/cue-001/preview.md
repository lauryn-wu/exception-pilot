# Reasoning instruction and output diagnostic — no API calls

24 worlds × 2 recorded-class variants × 3 conditions = 144 planned calls. The cumulative cap is 160 attempts, including explicitly requested transport retries.

This document shows the six requests from the first world; preview.json contains all 144 exact requests. Each request starts an independent conversation. All targets have a recorded class. The shared MISSING definition is preserved from the previous task wording. Headings and answer keys below are for human inspection and are not added to API messages.

## cue-list-000/record_2/visible

Recorded class: A; same-climate pattern: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | A |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

## cue-list-000/record_1/visible

Recorded class: C; same-climate pattern: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

## cue-list-000/record_1/cue

Recorded class: C; same-climate pattern: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Output only ANSWER: followed by A, B, or C.
```

## cue-list-000/record_2/direct

Recorded class: A; same-climate pattern: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | A |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

## cue-list-000/record_2/cue

Recorded class: A; same-climate pattern: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | A |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Output only ANSWER: followed by A, B, or C.
```

## cue-list-000/record_1/direct

Recorded class: C; same-climate pattern: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```
