# Constrained answer-order preview — no API calls

12 fresh worlds × 2 recorded-class variants × 3 conditions = 72 planned calls. The cumulative cap is 88 attempts, including explicitly requested transport retries.

This document shows the six exact user messages from the first world, common request settings, and each arm's exact schema. preview.json contains all 72 exact requests. Each request starts an independent conversation. The shared MISSING definition is unchanged; all target cells are recorded. These are fresh tables.

The two explanation arms have identical user messages and schemas differing only in the serialized order of schema properties. Actual returned JSON key order is checked. Nonempty reasoning text is required, without judging its quality or truth. Any returned schema, order, empty-reasoning, or technical failure is retained and stops collection; do not resample or resume past it. Headings and answer keys below are not added to API messages.

## Request settings shared by all arms

```json
{
  "model": "gpt-4o-2024-08-06",
  "temperature": 0.0,
  "max_completion_tokens": 1000,
  "n": 1,
  "store": false
}
```

## Exact response format: answer_only

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        }
      },
      "required": [
        "answer"
      ],
      "additionalProperties": false
    }
  }
}
```

## Exact response format: reasoning_first

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "reasoning": {
          "type": "string"
        },
        "answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        }
      },
      "required": [
        "answer",
        "reasoning"
      ],
      "additionalProperties": false
    }
  }
}
```

## Exact response format: answer_first

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_response",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        },
        "reasoning": {
          "type": "string"
        }
      },
      "required": [
        "answer",
        "reasoning"
      ],
      "additionalProperties": false
    }
  }
}
```

## order-list-000/record_2/reasoning_first

Recorded class: B; same-climate pattern: A.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| R4QW5T | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| RQCJ56 | Built for desert heat | Automatic | Vinyl | Two | Y | A |
| RYWWYC | Equipped for hot sand | Automatic | Cloth | Two | Y | A |
| R7AFRC | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| RA5ZZS | Operates in tropical forests | Automatic | Vinyl | Two | Z | B |
| RFJHJH | Used at an Arctic station | Automatic | Cloth | Two | Z | C |
| RAFYGG | Built for subzero temperatures | Automatic | Vinyl | Two | Z | C |
| RLEAU4 | Designed for humid summers | Automatic | Cloth | Four | X | A |
| RR5XMB | Equipped with snow tracks | Manual | Vinyl | Two | X | C |
| RZTFZN | Designed for frozen terrain | Manual | Vinyl | Four | X | B |

License plate: RA5ZZS
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## order-list-000/record_1/reasoning_first

Recorded class: C; same-climate pattern: A.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| R4QW5T | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| RQCJ56 | Built for desert heat | Automatic | Vinyl | Two | Y | A |
| RYWWYC | Equipped for hot sand | Automatic | Cloth | Two | Y | A |
| R7AFRC | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| RA5ZZS | Operates in tropical forests | Automatic | Vinyl | Two | Z | C |
| RFJHJH | Used at an Arctic station | Automatic | Cloth | Two | Z | C |
| RAFYGG | Built for subzero temperatures | Automatic | Vinyl | Two | Z | C |
| RLEAU4 | Designed for humid summers | Automatic | Cloth | Four | X | A |
| RR5XMB | Equipped with snow tracks | Manual | Vinyl | Two | X | C |
| RZTFZN | Designed for frozen terrain | Manual | Vinyl | Four | X | B |

License plate: RA5ZZS
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## order-list-000/record_1/answer_first

Recorded class: C; same-climate pattern: A.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| R4QW5T | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| RQCJ56 | Built for desert heat | Automatic | Vinyl | Two | Y | A |
| RYWWYC | Equipped for hot sand | Automatic | Cloth | Two | Y | A |
| R7AFRC | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| RA5ZZS | Operates in tropical forests | Automatic | Vinyl | Two | Z | C |
| RFJHJH | Used at an Arctic station | Automatic | Cloth | Two | Z | C |
| RAFYGG | Built for subzero temperatures | Automatic | Vinyl | Two | Z | C |
| RLEAU4 | Designed for humid summers | Automatic | Cloth | Four | X | A |
| RR5XMB | Equipped with snow tracks | Manual | Vinyl | Two | X | C |
| RZTFZN | Designed for frozen terrain | Manual | Vinyl | Four | X | B |

License plate: RA5ZZS
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## order-list-000/record_2/answer_first

Recorded class: B; same-climate pattern: A.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| R4QW5T | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| RQCJ56 | Built for desert heat | Automatic | Vinyl | Two | Y | A |
| RYWWYC | Equipped for hot sand | Automatic | Cloth | Two | Y | A |
| R7AFRC | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| RA5ZZS | Operates in tropical forests | Automatic | Vinyl | Two | Z | B |
| RFJHJH | Used at an Arctic station | Automatic | Cloth | Two | Z | C |
| RAFYGG | Built for subzero temperatures | Automatic | Vinyl | Two | Z | C |
| RLEAU4 | Designed for humid summers | Automatic | Cloth | Four | X | A |
| RR5XMB | Equipped with snow tracks | Manual | Vinyl | Two | X | C |
| RZTFZN | Designed for frozen terrain | Manual | Vinyl | Four | X | B |

License plate: RA5ZZS
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with two fields, "answer" and "reasoning". Set "answer" to A, B, or C and write your reasoning in "reasoning".
```

## order-list-000/record_2/answer_only

Recorded class: B; same-climate pattern: A.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| R4QW5T | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| RQCJ56 | Built for desert heat | Automatic | Vinyl | Two | Y | A |
| RYWWYC | Equipped for hot sand | Automatic | Cloth | Two | Y | A |
| R7AFRC | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| RA5ZZS | Operates in tropical forests | Automatic | Vinyl | Two | Z | B |
| RFJHJH | Used at an Arctic station | Automatic | Cloth | Two | Z | C |
| RAFYGG | Built for subzero temperatures | Automatic | Vinyl | Two | Z | C |
| RLEAU4 | Designed for humid summers | Automatic | Cloth | Four | X | A |
| RR5XMB | Equipped with snow tracks | Manual | Vinyl | Two | X | C |
| RZTFZN | Designed for frozen terrain | Manual | Vinyl | Four | X | B |

License plate: RA5ZZS
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with one field, "answer", whose value is A, B, or C.
```

## order-list-000/record_1/answer_only

Recorded class: C; same-climate pattern: A.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| R4QW5T | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| RQCJ56 | Built for desert heat | Automatic | Vinyl | Two | Y | A |
| RYWWYC | Equipped for hot sand | Automatic | Cloth | Two | Y | A |
| R7AFRC | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| RA5ZZS | Operates in tropical forests | Automatic | Vinyl | Two | Z | C |
| RFJHJH | Used at an Arctic station | Automatic | Cloth | Two | Z | C |
| RAFYGG | Built for subzero temperatures | Automatic | Vinyl | Two | Z | C |
| RLEAU4 | Designed for humid summers | Automatic | Cloth | Four | X | A |
| RR5XMB | Equipped with snow tracks | Manual | Vinyl | Two | X | C |
| RZTFZN | Designed for frozen terrain | Manual | Vinyl | Four | X | B |

License plate: RA5ZZS
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with one field, "answer", whose value is A, B, or C.
```
