# Counterfactual preview — no model calls

This comparison is for human inspection. Target flags and condition names are not sent to the model.
The actual request includes the verified class in each record by design.

| Plate | Description | Conflict label | Support label | Queried target |
|---|---|---|---|---|
| VJR5QP | Operates on polar ice | A | B |  |
| VE7L8M | Operates in tropical forests | B | A |  |
| V6KLAW | Built for subzero temperatures | A | B |  |
| VSAF66 | Designed for humid summers | A | A | yes |
| V9TVWL | Built for desert heat | B | B |  |
| VZ2TBY | Used at an Arctic station | B | B | yes |
| VDC9YS | Equipped for hot sand | B | A |  |
| VSPW84 | Used at an equatorial station | B | A |  |
| V3BX85 | Designed for frozen terrain | A | B |  |
| VYYXBN | Equipped with snow tracks | A | A |  |

Both worlds: five A, five B, two exceptions. Six other labels change; both targets stay fixed.

## One exact CoT request

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| VJR5QP | Operates on polar ice | Manual | Cloth | Four | A |
| VE7L8M | Operates in tropical forests | Manual | Cloth | Four | B |
| V6KLAW | Built for subzero temperatures | Automatic | Vinyl | Two | A |
| VSAF66 | Designed for humid summers | Automatic | Cloth | Two | A |
| V9TVWL | Built for desert heat | Automatic | Vinyl | Four | B |
| VZ2TBY | Used at an Arctic station | Manual | Vinyl | Four | B |
| VDC9YS | Equipped for hot sand | Manual | Cloth | Two | B |
| VSPW84 | Used at an equatorial station | Automatic | Vinyl | Two | B |
| V3BX85 | Designed for frozen terrain | Manual | Cloth | Two | A |
| VYYXBN | Equipped with snow tracks | Manual | Vinyl | Four | A |

License plate: VSAF66
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Work through the classification, then put A or B alone on the final line.
```

All eight requests for this list are in preview.json. All 160 tasks are in plan.json.
