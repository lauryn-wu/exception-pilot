# Offline rationale audit

Coder: `record-evidence-lexical-v2`. 96 scorable visible responses.

Provisional lexical codes describe detected written evidence; never_stated means no qualifying assertion was detected, not proof of absence. They do not establish retrieval, task recognition, or faithful internal reasoning. The conservative rule requires a target-record assertion, includes multiline record blocks, and rejects bare inferential comparisons. Missing-label evidence takes precedence; both flags remain in CSV. Evidence excerpts are Markdown-normalized, not raw character offsets.

The brief's single-line regex disagrees with the revised record-evidence flag on 27/96 responses. Both legacy flags are retained. JSON reasoning fields are decoded. Missing-gold tasks, nonreasoning anchors, and replay tasks are excluded. Revision and reasoning-first traces are also shown separately below.

| Run | Cell | Outcome | Code | Count | Share within cell/outcome |
|---|---|---|---|---:|---:|
| query-form-mistral-001 | all selected arms | correct | never_stated | 7 | 13.2% |
| query-form-mistral-001 | all selected arms | correct | relabeled_missing | 5 | 9.4% |
| query-form-mistral-001 | all selected arms | correct | stated_then_overridden | 0 | 0.0% |
| query-form-mistral-001 | all selected arms | correct | stated_and_followed | 41 | 77.4% |
| query-form-mistral-001 | all selected arms | wrong | never_stated | 9 | 20.9% |
| query-form-mistral-001 | all selected arms | wrong | relabeled_missing | 30 | 69.8% |
| query-form-mistral-001 | all selected arms | wrong | stated_then_overridden | 4 | 9.3% |
| query-form-mistral-001 | all selected arms | wrong | stated_and_followed | 0 | 0.0% |

| Run | Cell | Outcome | Code | Count | Share within cell/outcome |
|---|---|---|---|---:|---:|
| query-form-mistral-001 | key/visible | correct | never_stated | 4 | 12.1% |
| query-form-mistral-001 | key/visible | correct | relabeled_missing | 1 | 3.0% |
| query-form-mistral-001 | key/visible | correct | stated_then_overridden | 0 | 0.0% |
| query-form-mistral-001 | key/visible | correct | stated_and_followed | 28 | 84.8% |
| query-form-mistral-001 | key/visible | wrong | never_stated | 0 | 0.0% |
| query-form-mistral-001 | key/visible | wrong | relabeled_missing | 15 | 100.0% |
| query-form-mistral-001 | key/visible | wrong | stated_then_overridden | 0 | 0.0% |
| query-form-mistral-001 | key/visible | wrong | stated_and_followed | 0 | 0.0% |
| query-form-mistral-001 | profile/visible | correct | never_stated | 3 | 15.0% |
| query-form-mistral-001 | profile/visible | correct | relabeled_missing | 4 | 20.0% |
| query-form-mistral-001 | profile/visible | correct | stated_then_overridden | 0 | 0.0% |
| query-form-mistral-001 | profile/visible | correct | stated_and_followed | 13 | 65.0% |
| query-form-mistral-001 | profile/visible | wrong | never_stated | 9 | 32.1% |
| query-form-mistral-001 | profile/visible | wrong | relabeled_missing | 15 | 53.6% |
| query-form-mistral-001 | profile/visible | wrong | stated_then_overridden | 4 | 14.3% |
| query-form-mistral-001 | profile/visible | wrong | stated_and_followed | 0 | 0.0% |
