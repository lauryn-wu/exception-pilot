# Question × uncertainty diagnostic

Model: `gpt-4o-2024-08-06`; protocol: `verified-facts-factorial-v1`.

Valid: 595/640; invalid: 1; provider errors: 0; attempts: 596.

Complete independent list pairs: 18.

Explanatory study specified after observing the previous wording boundary. Question text and the uncertainty sentence vary independently. All cells share each list; the independent sample size is complete lists, not calls. Completion is not a pass, mechanism claim, novelty claim, or authorization for another study. The earlier stop_explicit_record_boundary decision is preserved.

Analysis status: **technical_failure**. No numerical pass threshold.

## Paired cell accuracies

These tables use only lists with all 32 valid answers. The target facts remain fixed across backgrounds; six non-target labels change. Every call is stateless.

| Question | Uncertainty sentence | Response | Support accuracy | Conflict accuracy |
|---|---|---|---:|---:|
| original | absent | direct | 100.0% | 100.0% |
| original | absent | cot_neutral | 100.0% | 50.0% |
| original | present | direct | 100.0% | 100.0% |
| original | present | cot_neutral | 100.0% | 50.0% |
| recorded | absent | direct | 100.0% | 100.0% |
| recorded | absent | cot_neutral | 100.0% | 100.0% |
| recorded | present | direct | 100.0% | 100.0% |
| recorded | present | cot_neutral | 100.0% | 80.6% |

## Reasoning-specific extra conflict penalties

E = (reasoning support − reasoning conflict) − (direct support − direct conflict). Positive E means conflict hurts reasoning more. Inspect the components too.

| Question / sentence | E | 95% list bootstrap | Positive / zero / negative lists |
|---|---:|---|---|
| original/absent | 50.0 pp | [33.3 pp, 66.7 pp] | 13 / 5 / 0 |
| original/present | 50.0 pp | [33.3 pp, 66.7 pp] | 13 / 5 / 0 |
| recorded/absent | 0.0 pp | [0.0 pp, 0.0 pp] | 0 / 18 / 0 |
| recorded/present | 19.4 pp | [8.3 pp, 30.6 pp] | 7 / 11 / 0 |

| Question / sentence | Direct conflict penalty | Reasoning conflict penalty | Direct − reasoning in conflict |
|---|---:|---:|---:|
| original/absent | 0.0 pp | 50.0 pp | 50.0 pp |
| original/present | 0.0 pp | 50.0 pp | 50.0 pp |
| recorded/absent | 0.0 pp | 0.0 pp | 0.0 pp |
| recorded/present | 0.0 pp | 19.4 pp | 19.4 pp |

## Factorial contrasts in E

Primary interaction = (original present − original absent) − (recorded present − recorded absent). Positive means the sentence increases E more under the original question. Zero interaction can coexist with additive wording effects.

| Contrast | Difference | 95% list bootstrap | Positive / zero / negative lists |
|---|---:|---|---|
| Sentence effect under original minus sentence effect under recorded (primary) | -19.4 pp | [-44.4 pp, 2.8 pp] | 4 / 6 / 8 |
| Original: sentence present minus absent | 0.0 pp | [-16.7 pp, 16.7 pp] | 5 / 8 / 5 |
| Recorded: sentence present minus absent | 19.4 pp | [8.3 pp, 30.6 pp] | 7 / 11 / 0 |
| Sentence absent: original minus recorded | 50.0 pp | [33.3 pp, 66.7 pp] | 13 / 5 / 0 |
| Sentence present: original minus recorded | 30.6 pp | [8.3 pp, 50.0 pp] | 10 / 6 / 2 |
| Average present-minus-absent effect across questions | 9.7 pp | [1.4 pp, 18.1 pp] | 8 / 8 / 2 |
| Average original-minus-recorded effect across sentence levels | 40.3 pp | [26.4 pp, 55.6 pp] | 14 / 4 / 0 |

Intervals use 10,000 whole-list resamples, seed 981723. They are descriptive, not simultaneous confidence statements. Degenerate intervals reflect a constant observed vector, not population certainty. Small or uncertain effects do not prove absence. The primary contrast and all components must be interpreted together.

These are effects of exact prompt interventions on final answers, not observations of an internal mechanism. Only one snapshot and task family are tested. See FACTORIAL_PROTOCOL.md for scope, limitations, and the fixed interpretation plan.

## All returned answers (valid-only denominators)

| Question | Sentence | Response | Background | Correct / valid / planned | Accuracy |
|---|---|---|---|---:|---:|
| original | absent | direct | conflict | 36 / 36 / 40 | 100.0% |
| original | absent | direct | support | 36 / 36 / 40 | 100.0% |
| original | absent | cot_neutral | conflict | 18 / 37 / 40 | 48.6% |
| original | absent | cot_neutral | support | 38 / 38 / 40 | 100.0% |
| original | present | direct | conflict | 37 / 37 / 40 | 100.0% |
| original | present | direct | support | 37 / 37 / 40 | 100.0% |
| original | present | cot_neutral | conflict | 19 / 38 / 40 | 50.0% |
| original | present | cot_neutral | support | 38 / 38 / 40 | 100.0% |
| recorded | absent | direct | conflict | 37 / 37 / 40 | 100.0% |
| recorded | absent | direct | support | 37 / 37 / 40 | 100.0% |
| recorded | absent | cot_neutral | conflict | 37 / 37 / 40 | 100.0% |
| recorded | absent | cot_neutral | support | 38 / 38 / 40 | 100.0% |
| recorded | present | direct | conflict | 37 / 37 / 40 | 100.0% |
| recorded | present | direct | support | 38 / 38 / 40 | 100.0% |
| recorded | present | cot_neutral | conflict | 29 / 37 / 40 | 78.4% |
| recorded | present | cot_neutral | support | 36 / 37 / 40 | 97.3% |
