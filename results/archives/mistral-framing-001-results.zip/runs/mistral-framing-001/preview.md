# Record-status framing intervention — exact request preview

This is a fresh run. Preparing this preview makes zero API calls.
The baseline stage stops after the capability probe and every direct/visible baseline response. An explicit --stage intervene invocation is required afterward. Baseline accuracy never determines eligibility.

All 48 target cases appear below. Each has one direct baseline request, one visible-reasoning baseline request, and four assistant prefixes supplied three times each. Repeats use the same prompt; they are separate requests. The schedule is frozen and randomized within case blocks. preview.json contains all 673 complete requests in execution order. Metadata is for analysis only and is not supplied to the model. An assistant message marked prefix=true is an unfinished explanation; all subsequent text is newly generated.

Plan hash: `a34939b547f9cf8ee6f04e7c7cdf8ce8c8f1dcb4159cadbafaccbc2e5e6fc393`

## Shared request settings

These settings apply to every baseline and intervention request:

```json
{
  "model": "mistral-small-2603",
  "temperature": 0.6,
  "top_p": 0.95,
  "max_tokens": 1600,
  "reasoning_effort": "none",
  "stream": false
}
```

## Prefix capability probe

The probe uses the same settings except max_tokens=32.

User message:

```text
Output exactly this text, without quotation marks or commentary:
Cobalt Maple Lantern
```

Assistant prefix (prefix=true; includes a trailing space after Cobalt):

```text
Cobalt 
```

## framing-list-017/record_2

### Direct baseline — exact user message

Task: `framing-list-017/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FYNYN4 | Used at an Arctic station | Automatic | Vinyl | Four | X | A |
| F9NRHQ | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FR68AG | Designed for frozen terrain | Manual | Vinyl | Four | Z | B |
| FJ3PWP | Designed for humid summers | Automatic | Cloth | Four | Y | B |
| FP7BGT | Equipped for hot sand | Automatic | Vinyl | Four | Z | B |
| FGRP3R | Built for desert heat | Manual | Cloth | Four | Z | C |
| FX98LH | Used at an equatorial station | Manual | Vinyl | Four | Y | B |
| FBUX42 | Built for subzero temperatures | Automatic | Cloth | Four | Y | A |
| FRAFD4 | Equipped with snow tracks | Automatic | Vinyl | Four | X | A |
| FZ79HL | Operates in tropical forests | Automatic | Cloth | Two | Y | C |

License plate: FR68AG
Description: Designed for frozen terrain
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-017/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FYNYN4 | Used at an Arctic station | Automatic | Vinyl | Four | X | A |
| F9NRHQ | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FR68AG | Designed for frozen terrain | Manual | Vinyl | Four | Z | B |
| FJ3PWP | Designed for humid summers | Automatic | Cloth | Four | Y | B |
| FP7BGT | Equipped for hot sand | Automatic | Vinyl | Four | Z | B |
| FGRP3R | Built for desert heat | Manual | Cloth | Four | Z | C |
| FX98LH | Used at an equatorial station | Manual | Vinyl | Four | Y | B |
| FBUX42 | Built for subzero temperatures | Automatic | Cloth | Four | Y | A |
| FRAFD4 | Equipped with snow tracks | Automatic | Vinyl | Four | X | A |
| FZ79HL | Operates in tropical forests | Automatic | Cloth | Two | Y | C |

License plate: FR68AG
Description: Designed for frozen terrain
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-017/record_2/original/r1`, `framing-list-017/record_2/original/r2`, `framing-list-017/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-017/record_2/paraphrase/r1`, `framing-list-017/record_2/paraphrase/r2`, `framing-list-017/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-017/record_2/recorded/r1`, `framing-list-017/record_2/recorded/r2`, `framing-list-017/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-017/record_2/bare/r1`, `framing-list-017/record_2/bare/r2`, `framing-list-017/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B

```

## framing-list-000/record_2

### Direct baseline — exact user message

Task: `framing-list-000/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FR7W4R | Used at an Arctic station | Automatic | Cloth | Two | Z | A |
| FW3A6P | Designed for humid summers | Manual | Cloth | Four | Y | C |
| FNNQFM | Designed for frozen terrain | Automatic | Cloth | Two | X | C |
| FG96G2 | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| F88GF2 | Equipped for hot sand | Automatic | Cloth | Two | Z | B |
| FNRUCL | Built for desert heat | Automatic | Cloth | Two | X | B |
| F6XRJL | Operates on polar ice | Manual | Vinyl | Four | Y | A |
| FJF58V | Built for subzero temperatures | Automatic | Vinyl | Four | Z | A |
| F57GWA | Used at an equatorial station | Manual | Cloth | Two | Y | C |
| FJ92EW | Equipped with snow tracks | Manual | Cloth | Four | X | A |

License plate: FNNQFM
Description: Designed for frozen terrain
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-000/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FR7W4R | Used at an Arctic station | Automatic | Cloth | Two | Z | A |
| FW3A6P | Designed for humid summers | Manual | Cloth | Four | Y | C |
| FNNQFM | Designed for frozen terrain | Automatic | Cloth | Two | X | C |
| FG96G2 | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| F88GF2 | Equipped for hot sand | Automatic | Cloth | Two | Z | B |
| FNRUCL | Built for desert heat | Automatic | Cloth | Two | X | B |
| F6XRJL | Operates on polar ice | Manual | Vinyl | Four | Y | A |
| FJF58V | Built for subzero temperatures | Automatic | Vinyl | Four | Z | A |
| F57GWA | Used at an equatorial station | Manual | Cloth | Two | Y | C |
| FJ92EW | Equipped with snow tracks | Manual | Cloth | Four | X | A |

License plate: FNNQFM
Description: Designed for frozen terrain
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-000/record_2/original/r1`, `framing-list-000/record_2/original/r2`, `framing-list-000/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-000/record_2/paraphrase/r1`, `framing-list-000/record_2/paraphrase/r2`, `framing-list-000/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-000/record_2/recorded/r1`, `framing-list-000/record_2/recorded/r2`, `framing-list-000/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-000/record_2/bare/r1`, `framing-list-000/record_2/bare/r2`, `framing-list-000/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C

```

## framing-list-015/record_2

### Direct baseline — exact user message

Task: `framing-list-015/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FD82ZX | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| FWES2L | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| F38XT3 | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FJRGUP | Built for desert heat | Manual | Cloth | Two | Y | B |
| FYCE72 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| FRHXAR | Equipped with snow tracks | Manual | Vinyl | Two | Z | C |
| FU6QRW | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQU8LM | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| FXMS4T | Used at an equatorial station | Manual | Vinyl | Two | Z | B |
| FRWJH7 | Designed for frozen terrain | Manual | Cloth | Two | Z | C |

License plate: FYCE72
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-015/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FD82ZX | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| FWES2L | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| F38XT3 | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FJRGUP | Built for desert heat | Manual | Cloth | Two | Y | B |
| FYCE72 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| FRHXAR | Equipped with snow tracks | Manual | Vinyl | Two | Z | C |
| FU6QRW | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQU8LM | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| FXMS4T | Used at an equatorial station | Manual | Vinyl | Two | Z | B |
| FRWJH7 | Designed for frozen terrain | Manual | Cloth | Two | Z | C |

License plate: FYCE72
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-015/record_2/original/r1`, `framing-list-015/record_2/original/r2`, `framing-list-015/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-015/record_2/paraphrase/r1`, `framing-list-015/record_2/paraphrase/r2`, `framing-list-015/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-015/record_2/recorded/r1`, `framing-list-015/record_2/recorded/r2`, `framing-list-015/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-015/record_2/bare/r1`, `framing-list-015/record_2/bare/r2`, `framing-list-015/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B

```

## framing-list-023/record_1

### Direct baseline — exact user message

Task: `framing-list-023/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FTVLQC | Designed for frozen terrain | Automatic | Vinyl | Two | Y | C |
| FCPWVV | Designed for humid summers | Manual | Vinyl | Two | X | B |
| FNRVVM | Equipped with snow tracks | Manual | Vinyl | Four | Y | A |
| FV2HN5 | Equipped for hot sand | Manual | Cloth | Two | Z | B |
| FMABDD | Operates in tropical forests | Automatic | Cloth | Four | Y | A |
| F7U8ZH | Used at an equatorial station | Manual | Vinyl | Two | X | B |
| FJ6JYB | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FT8K3U | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FK4WVE | Built for desert heat | Manual | Cloth | Two | Z | B |
| FH6PXU | Used at an Arctic station | Manual | Cloth | Four | Z | A |

License plate: FMABDD
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-023/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FTVLQC | Designed for frozen terrain | Automatic | Vinyl | Two | Y | C |
| FCPWVV | Designed for humid summers | Manual | Vinyl | Two | X | B |
| FNRVVM | Equipped with snow tracks | Manual | Vinyl | Four | Y | A |
| FV2HN5 | Equipped for hot sand | Manual | Cloth | Two | Z | B |
| FMABDD | Operates in tropical forests | Automatic | Cloth | Four | Y | A |
| F7U8ZH | Used at an equatorial station | Manual | Vinyl | Two | X | B |
| FJ6JYB | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FT8K3U | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FK4WVE | Built for desert heat | Manual | Cloth | Two | Z | B |
| FH6PXU | Used at an Arctic station | Manual | Cloth | Four | Z | A |

License plate: FMABDD
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-023/record_1/original/r1`, `framing-list-023/record_1/original/r2`, `framing-list-023/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-023/record_1/paraphrase/r1`, `framing-list-023/record_1/paraphrase/r2`, `framing-list-023/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-023/record_1/recorded/r1`, `framing-list-023/record_1/recorded/r2`, `framing-list-023/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-023/record_1/bare/r1`, `framing-list-023/record_1/bare/r2`, `framing-list-023/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A

```

## framing-list-005/record_1

### Direct baseline — exact user message

Task: `framing-list-005/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FFLYVF | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| FSMPW2 | Built for desert heat | Automatic | Vinyl | Two | X | B |
| FW4ES7 | Designed for frozen terrain | Automatic | Cloth | Four | Z | A |
| FW5MEU | Used at an equatorial station | Automatic | Cloth | Four | Z | B |
| F64LA4 | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| FQG7KC | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| F73DR6 | Built for subzero temperatures | Automatic | Vinyl | Four | Z | C |
| F5GRZD | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| FQ3PZE | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |
| FEFUCP | Designed for humid summers | Automatic | Vinyl | Two | X | A |

License plate: FEFUCP
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-005/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FFLYVF | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| FSMPW2 | Built for desert heat | Automatic | Vinyl | Two | X | B |
| FW4ES7 | Designed for frozen terrain | Automatic | Cloth | Four | Z | A |
| FW5MEU | Used at an equatorial station | Automatic | Cloth | Four | Z | B |
| F64LA4 | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| FQG7KC | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| F73DR6 | Built for subzero temperatures | Automatic | Vinyl | Four | Z | C |
| F5GRZD | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| FQ3PZE | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |
| FEFUCP | Designed for humid summers | Automatic | Vinyl | Two | X | A |

License plate: FEFUCP
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-005/record_1/original/r1`, `framing-list-005/record_1/original/r2`, `framing-list-005/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-005/record_1/paraphrase/r1`, `framing-list-005/record_1/paraphrase/r2`, `framing-list-005/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-005/record_1/recorded/r1`, `framing-list-005/record_1/recorded/r2`, `framing-list-005/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-005/record_1/bare/r1`, `framing-list-005/record_1/bare/r2`, `framing-list-005/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A

```

## framing-list-018/record_1

### Direct baseline — exact user message

Task: `framing-list-018/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F9FTT9 | Operates on polar ice | Manual | Cloth | Two | Y | C |
| FLVBZR | Designed for frozen terrain | Manual | Cloth | Four | X | B |
| FAV7TD | Built for desert heat | Automatic | Vinyl | Four | Z | A |
| FTW8BE | Used at an Arctic station | Automatic | Cloth | Four | X | B |
| FYXKS5 | Used at an equatorial station | Manual | Cloth | Two | X | A |
| FPWSGT | Designed for humid summers | Manual | Cloth | Two | Y | C |
| FWZLFB | Equipped with snow tracks | Manual | Cloth | Two | Y | B |
| FPH625 | Operates in tropical forests | Automatic | Vinyl | Four | Z | C |
| FK5RRU | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FDM3PF | Equipped for hot sand | Automatic | Vinyl | Two | Y | C |

License plate: F9FTT9
Description: Operates on polar ice
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-018/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F9FTT9 | Operates on polar ice | Manual | Cloth | Two | Y | C |
| FLVBZR | Designed for frozen terrain | Manual | Cloth | Four | X | B |
| FAV7TD | Built for desert heat | Automatic | Vinyl | Four | Z | A |
| FTW8BE | Used at an Arctic station | Automatic | Cloth | Four | X | B |
| FYXKS5 | Used at an equatorial station | Manual | Cloth | Two | X | A |
| FPWSGT | Designed for humid summers | Manual | Cloth | Two | Y | C |
| FWZLFB | Equipped with snow tracks | Manual | Cloth | Two | Y | B |
| FPH625 | Operates in tropical forests | Automatic | Vinyl | Four | Z | C |
| FK5RRU | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FDM3PF | Equipped for hot sand | Automatic | Vinyl | Two | Y | C |

License plate: F9FTT9
Description: Operates on polar ice
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-018/record_1/original/r1`, `framing-list-018/record_1/original/r2`, `framing-list-018/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-018/record_1/paraphrase/r1`, `framing-list-018/record_1/paraphrase/r2`, `framing-list-018/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-018/record_1/recorded/r1`, `framing-list-018/record_1/recorded/r2`, `framing-list-018/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-018/record_1/bare/r1`, `framing-list-018/record_1/bare/r2`, `framing-list-018/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: C

```

## framing-list-016/record_2

### Direct baseline — exact user message

Task: `framing-list-016/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FW6DVR | Equipped for hot sand | Manual | Cloth | Four | X | B |
| FKQN7R | Designed for frozen terrain | Manual | Vinyl | Two | X | C |
| FUB2PJ | Used at an Arctic station | Manual | Cloth | Two | Z | B |
| FGZHJZ | Used at an equatorial station | Manual | Vinyl | Four | X | A |
| FQW7SA | Built for desert heat | Manual | Cloth | Four | Z | A |
| FYZYXW | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FNT7F9 | Operates on polar ice | Manual | Cloth | Four | Y | B |
| FX4C83 | Designed for humid summers | Manual | Vinyl | Two | Y | A |
| F248HW | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| FT3M2S | Equipped with snow tracks | Manual | Vinyl | Four | Z | C |

License plate: FW6DVR
Description: Equipped for hot sand
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-016/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FW6DVR | Equipped for hot sand | Manual | Cloth | Four | X | B |
| FKQN7R | Designed for frozen terrain | Manual | Vinyl | Two | X | C |
| FUB2PJ | Used at an Arctic station | Manual | Cloth | Two | Z | B |
| FGZHJZ | Used at an equatorial station | Manual | Vinyl | Four | X | A |
| FQW7SA | Built for desert heat | Manual | Cloth | Four | Z | A |
| FYZYXW | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FNT7F9 | Operates on polar ice | Manual | Cloth | Four | Y | B |
| FX4C83 | Designed for humid summers | Manual | Vinyl | Two | Y | A |
| F248HW | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| FT3M2S | Equipped with snow tracks | Manual | Vinyl | Four | Z | C |

License plate: FW6DVR
Description: Equipped for hot sand
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-016/record_2/original/r1`, `framing-list-016/record_2/original/r2`, `framing-list-016/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-016/record_2/paraphrase/r1`, `framing-list-016/record_2/paraphrase/r2`, `framing-list-016/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-016/record_2/recorded/r1`, `framing-list-016/record_2/recorded/r2`, `framing-list-016/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-016/record_2/bare/r1`, `framing-list-016/record_2/bare/r2`, `framing-list-016/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: B

```

## framing-list-010/record_1

### Direct baseline — exact user message

Task: `framing-list-010/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F457H3 | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| F4SHB2 | Used at an Arctic station | Automatic | Vinyl | Four | X | B |
| FE7PPP | Operates on polar ice | Manual | Cloth | Four | Z | A |
| FNEXGU | Designed for humid summers | Manual | Cloth | Two | Y | A |
| FAUVMJ | Built for desert heat | Manual | Vinyl | Four | Z | C |
| FX55HP | Designed for frozen terrain | Manual | Cloth | Two | X | B |
| FWEPUG | Operates in tropical forests | Automatic | Cloth | Two | Y | C |
| F9M8CU | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| FWTSXL | Equipped with snow tracks | Manual | Vinyl | Four | Z | A |
| FQLQPW | Used at an equatorial station | Automatic | Cloth | Four | X | C |

License plate: FNEXGU
Description: Designed for humid summers
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-010/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F457H3 | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| F4SHB2 | Used at an Arctic station | Automatic | Vinyl | Four | X | B |
| FE7PPP | Operates on polar ice | Manual | Cloth | Four | Z | A |
| FNEXGU | Designed for humid summers | Manual | Cloth | Two | Y | A |
| FAUVMJ | Built for desert heat | Manual | Vinyl | Four | Z | C |
| FX55HP | Designed for frozen terrain | Manual | Cloth | Two | X | B |
| FWEPUG | Operates in tropical forests | Automatic | Cloth | Two | Y | C |
| F9M8CU | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| FWTSXL | Equipped with snow tracks | Manual | Vinyl | Four | Z | A |
| FQLQPW | Used at an equatorial station | Automatic | Cloth | Four | X | C |

License plate: FNEXGU
Description: Designed for humid summers
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-010/record_1/original/r1`, `framing-list-010/record_1/original/r2`, `framing-list-010/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-010/record_1/paraphrase/r1`, `framing-list-010/record_1/paraphrase/r2`, `framing-list-010/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-010/record_1/recorded/r1`, `framing-list-010/record_1/recorded/r2`, `framing-list-010/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-010/record_1/bare/r1`, `framing-list-010/record_1/bare/r2`, `framing-list-010/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A

```

## framing-list-018/record_2

### Direct baseline — exact user message

Task: `framing-list-018/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F9FTT9 | Operates on polar ice | Manual | Cloth | Two | Y | A |
| FLVBZR | Designed for frozen terrain | Manual | Cloth | Four | X | B |
| FAV7TD | Built for desert heat | Automatic | Vinyl | Four | Z | A |
| FTW8BE | Used at an Arctic station | Automatic | Cloth | Four | X | B |
| FYXKS5 | Used at an equatorial station | Manual | Cloth | Two | X | A |
| FPWSGT | Designed for humid summers | Manual | Cloth | Two | Y | C |
| FWZLFB | Equipped with snow tracks | Manual | Cloth | Two | Y | B |
| FPH625 | Operates in tropical forests | Automatic | Vinyl | Four | Z | C |
| FK5RRU | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FDM3PF | Equipped for hot sand | Automatic | Vinyl | Two | Y | C |

License plate: F9FTT9
Description: Operates on polar ice
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-018/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F9FTT9 | Operates on polar ice | Manual | Cloth | Two | Y | A |
| FLVBZR | Designed for frozen terrain | Manual | Cloth | Four | X | B |
| FAV7TD | Built for desert heat | Automatic | Vinyl | Four | Z | A |
| FTW8BE | Used at an Arctic station | Automatic | Cloth | Four | X | B |
| FYXKS5 | Used at an equatorial station | Manual | Cloth | Two | X | A |
| FPWSGT | Designed for humid summers | Manual | Cloth | Two | Y | C |
| FWZLFB | Equipped with snow tracks | Manual | Cloth | Two | Y | B |
| FPH625 | Operates in tropical forests | Automatic | Vinyl | Four | Z | C |
| FK5RRU | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FDM3PF | Equipped for hot sand | Automatic | Vinyl | Two | Y | C |

License plate: F9FTT9
Description: Operates on polar ice
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-018/record_2/original/r1`, `framing-list-018/record_2/original/r2`, `framing-list-018/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-018/record_2/paraphrase/r1`, `framing-list-018/record_2/paraphrase/r2`, `framing-list-018/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-018/record_2/recorded/r1`, `framing-list-018/record_2/recorded/r2`, `framing-list-018/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-018/record_2/bare/r1`, `framing-list-018/record_2/bare/r2`, `framing-list-018/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F9FTT9.

1. **Given Data for F9FTT9:**
   - License plate: F9FTT9
   - Description: Operates on polar ice
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A

```

## framing-list-005/record_2

### Direct baseline — exact user message

Task: `framing-list-005/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FFLYVF | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| FSMPW2 | Built for desert heat | Automatic | Vinyl | Two | X | B |
| FW4ES7 | Designed for frozen terrain | Automatic | Cloth | Four | Z | A |
| FW5MEU | Used at an equatorial station | Automatic | Cloth | Four | Z | B |
| F64LA4 | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| FQG7KC | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| F73DR6 | Built for subzero temperatures | Automatic | Vinyl | Four | Z | C |
| F5GRZD | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| FQ3PZE | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |
| FEFUCP | Designed for humid summers | Automatic | Vinyl | Two | X | C |

License plate: FEFUCP
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-005/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FFLYVF | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| FSMPW2 | Built for desert heat | Automatic | Vinyl | Two | X | B |
| FW4ES7 | Designed for frozen terrain | Automatic | Cloth | Four | Z | A |
| FW5MEU | Used at an equatorial station | Automatic | Cloth | Four | Z | B |
| F64LA4 | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| FQG7KC | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| F73DR6 | Built for subzero temperatures | Automatic | Vinyl | Four | Z | C |
| F5GRZD | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| FQ3PZE | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |
| FEFUCP | Designed for humid summers | Automatic | Vinyl | Two | X | C |

License plate: FEFUCP
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-005/record_2/original/r1`, `framing-list-005/record_2/original/r2`, `framing-list-005/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-005/record_2/paraphrase/r1`, `framing-list-005/record_2/paraphrase/r2`, `framing-list-005/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-005/record_2/recorded/r1`, `framing-list-005/record_2/recorded/r2`, `framing-list-005/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-005/record_2/bare/r1`, `framing-list-005/record_2/bare/r2`, `framing-list-005/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FEFUCP.

1. **Given Data for FEFUCP:**
   - License plate: FEFUCP
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C

```

## framing-list-016/record_1

### Direct baseline — exact user message

Task: `framing-list-016/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FW6DVR | Equipped for hot sand | Manual | Cloth | Four | X | C |
| FKQN7R | Designed for frozen terrain | Manual | Vinyl | Two | X | C |
| FUB2PJ | Used at an Arctic station | Manual | Cloth | Two | Z | B |
| FGZHJZ | Used at an equatorial station | Manual | Vinyl | Four | X | A |
| FQW7SA | Built for desert heat | Manual | Cloth | Four | Z | A |
| FYZYXW | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FNT7F9 | Operates on polar ice | Manual | Cloth | Four | Y | B |
| FX4C83 | Designed for humid summers | Manual | Vinyl | Two | Y | A |
| F248HW | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| FT3M2S | Equipped with snow tracks | Manual | Vinyl | Four | Z | C |

License plate: FW6DVR
Description: Equipped for hot sand
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-016/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FW6DVR | Equipped for hot sand | Manual | Cloth | Four | X | C |
| FKQN7R | Designed for frozen terrain | Manual | Vinyl | Two | X | C |
| FUB2PJ | Used at an Arctic station | Manual | Cloth | Two | Z | B |
| FGZHJZ | Used at an equatorial station | Manual | Vinyl | Four | X | A |
| FQW7SA | Built for desert heat | Manual | Cloth | Four | Z | A |
| FYZYXW | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FNT7F9 | Operates on polar ice | Manual | Cloth | Four | Y | B |
| FX4C83 | Designed for humid summers | Manual | Vinyl | Two | Y | A |
| F248HW | Operates in tropical forests | Manual | Cloth | Two | Z | A |
| FT3M2S | Equipped with snow tracks | Manual | Vinyl | Four | Z | C |

License plate: FW6DVR
Description: Equipped for hot sand
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-016/record_1/original/r1`, `framing-list-016/record_1/original/r2`, `framing-list-016/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-016/record_1/paraphrase/r1`, `framing-list-016/record_1/paraphrase/r2`, `framing-list-016/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-016/record_1/recorded/r1`, `framing-list-016/record_1/recorded/r2`, `framing-list-016/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-016/record_1/bare/r1`, `framing-list-016/record_1/bare/r2`, `framing-list-016/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FW6DVR.

1. **Given Data for FW6DVR:**
   - License plate: FW6DVR
   - Description: Equipped for hot sand
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: X
   - Verified class: C

```

## framing-list-006/record_2

### Direct baseline — exact user message

Task: `framing-list-006/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FUEK7A | Designed for humid summers | Manual | Vinyl | Four | Y | C |
| FTDTM8 | Equipped for hot sand | Manual | Vinyl | Four | Z | B |
| FMNGYP | Operates on polar ice | Manual | Cloth | Two | Y | A |
| F36KFN | Equipped with snow tracks | Manual | Cloth | Two | Z | A |
| FEMP8V | Used at an equatorial station | Automatic | Vinyl | Four | Z | B |
| FDZP5B | Used at an Arctic station | Automatic | Vinyl | Two | X | A |
| FVH7UT | Built for desert heat | Automatic | Cloth | Two | X | C |
| FAUYUW | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| F2XRAG | Built for subzero temperatures | Automatic | Vinyl | Four | Z | B |
| FBFMLR | Designed for frozen terrain | Automatic | Cloth | Two | Y | A |

License plate: F2XRAG
Description: Built for subzero temperatures
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-006/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FUEK7A | Designed for humid summers | Manual | Vinyl | Four | Y | C |
| FTDTM8 | Equipped for hot sand | Manual | Vinyl | Four | Z | B |
| FMNGYP | Operates on polar ice | Manual | Cloth | Two | Y | A |
| F36KFN | Equipped with snow tracks | Manual | Cloth | Two | Z | A |
| FEMP8V | Used at an equatorial station | Automatic | Vinyl | Four | Z | B |
| FDZP5B | Used at an Arctic station | Automatic | Vinyl | Two | X | A |
| FVH7UT | Built for desert heat | Automatic | Cloth | Two | X | C |
| FAUYUW | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| F2XRAG | Built for subzero temperatures | Automatic | Vinyl | Four | Z | B |
| FBFMLR | Designed for frozen terrain | Automatic | Cloth | Two | Y | A |

License plate: F2XRAG
Description: Built for subzero temperatures
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-006/record_2/original/r1`, `framing-list-006/record_2/original/r2`, `framing-list-006/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-006/record_2/paraphrase/r1`, `framing-list-006/record_2/paraphrase/r2`, `framing-list-006/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-006/record_2/recorded/r1`, `framing-list-006/record_2/recorded/r2`, `framing-list-006/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-006/record_2/bare/r1`, `framing-list-006/record_2/bare/r2`, `framing-list-006/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: B

```

## framing-list-020/record_2

### Direct baseline — exact user message

Task: `framing-list-020/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRACXK | Used at an Arctic station | Automatic | Cloth | Four | Z | A |
| FTDZ7A | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| FJZ9S5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |
| FBMV6Q | Designed for humid summers | Manual | Vinyl | Two | Z | C |
| FYWQXB | Used at an equatorial station | Automatic | Vinyl | Two | X | B |
| FZXFSU | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| FBBTD9 | Equipped for hot sand | Automatic | Vinyl | Four | Y | B |
| F5K84S | Equipped with snow tracks | Manual | Vinyl | Four | X | A |
| FGZ5FH | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| FGPJ65 | Built for desert heat | Automatic | Vinyl | Two | X | C |

License plate: FZXFSU
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-020/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRACXK | Used at an Arctic station | Automatic | Cloth | Four | Z | A |
| FTDZ7A | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| FJZ9S5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |
| FBMV6Q | Designed for humid summers | Manual | Vinyl | Two | Z | C |
| FYWQXB | Used at an equatorial station | Automatic | Vinyl | Two | X | B |
| FZXFSU | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| FBBTD9 | Equipped for hot sand | Automatic | Vinyl | Four | Y | B |
| F5K84S | Equipped with snow tracks | Manual | Vinyl | Four | X | A |
| FGZ5FH | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| FGPJ65 | Built for desert heat | Automatic | Vinyl | Two | X | C |

License plate: FZXFSU
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-020/record_2/original/r1`, `framing-list-020/record_2/original/r2`, `framing-list-020/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-020/record_2/paraphrase/r1`, `framing-list-020/record_2/paraphrase/r2`, `framing-list-020/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-020/record_2/recorded/r1`, `framing-list-020/record_2/recorded/r2`, `framing-list-020/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-020/record_2/bare/r1`, `framing-list-020/record_2/bare/r2`, `framing-list-020/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: C

```

## framing-list-012/record_2

### Direct baseline — exact user message

Task: `framing-list-012/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FMUJ5B | Designed for frozen terrain | Automatic | Vinyl | Two | X | B |
| F3YDBX | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| F8BE47 | Built for subzero temperatures | Manual | Vinyl | Four | Z | C |
| FRABFK | Designed for humid summers | Automatic | Vinyl | Four | X | A |
| FKRKB3 | Used at an equatorial station | Manual | Vinyl | Four | Y | A |
| FXAEEM | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FNWYZG | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| FVC36V | Operates on polar ice | Manual | Cloth | Two | Y | C |
| FAUCN5 | Equipped with snow tracks | Manual | Vinyl | Two | Z | B |
| FMR4QH | Built for desert heat | Manual | Vinyl | Four | Z | A |

License plate: FNWYZG
Description: Equipped for hot sand
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-012/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FMUJ5B | Designed for frozen terrain | Automatic | Vinyl | Two | X | B |
| F3YDBX | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| F8BE47 | Built for subzero temperatures | Manual | Vinyl | Four | Z | C |
| FRABFK | Designed for humid summers | Automatic | Vinyl | Four | X | A |
| FKRKB3 | Used at an equatorial station | Manual | Vinyl | Four | Y | A |
| FXAEEM | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FNWYZG | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| FVC36V | Operates on polar ice | Manual | Cloth | Two | Y | C |
| FAUCN5 | Equipped with snow tracks | Manual | Vinyl | Two | Z | B |
| FMR4QH | Built for desert heat | Manual | Vinyl | Four | Z | A |

License plate: FNWYZG
Description: Equipped for hot sand
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-012/record_2/original/r1`, `framing-list-012/record_2/original/r2`, `framing-list-012/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-012/record_2/paraphrase/r1`, `framing-list-012/record_2/paraphrase/r2`, `framing-list-012/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-012/record_2/recorded/r1`, `framing-list-012/record_2/recorded/r2`, `framing-list-012/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-012/record_2/bare/r1`, `framing-list-012/record_2/bare/r2`, `framing-list-012/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: B

```

## framing-list-004/record_1

### Direct baseline — exact user message

Task: `framing-list-004/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJHHDV | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| F5Z5P8 | Equipped for hot sand | Manual | Cloth | Four | Y | C |
| FL964Y | Operates on polar ice | Manual | Vinyl | Two | X | B |
| FNZG7A | Used at an equatorial station | Automatic | Vinyl | Two | Z | B |
| FUG4SP | Equipped with snow tracks | Automatic | Vinyl | Four | Y | B |
| FLX52P | Designed for humid summers | Manual | Cloth | Four | Z | C |
| FNDG73 | Used at an Arctic station | Automatic | Cloth | Four | Z | B |
| F4EVEU | Built for desert heat | Automatic | Cloth | Two | X | C |
| F9CA4N | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| FDT8J5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |

License plate: FNZG7A
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-004/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJHHDV | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| F5Z5P8 | Equipped for hot sand | Manual | Cloth | Four | Y | C |
| FL964Y | Operates on polar ice | Manual | Vinyl | Two | X | B |
| FNZG7A | Used at an equatorial station | Automatic | Vinyl | Two | Z | B |
| FUG4SP | Equipped with snow tracks | Automatic | Vinyl | Four | Y | B |
| FLX52P | Designed for humid summers | Manual | Cloth | Four | Z | C |
| FNDG73 | Used at an Arctic station | Automatic | Cloth | Four | Z | B |
| F4EVEU | Built for desert heat | Automatic | Cloth | Two | X | C |
| F9CA4N | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| FDT8J5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |

License plate: FNZG7A
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-004/record_1/original/r1`, `framing-list-004/record_1/original/r2`, `framing-list-004/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-004/record_1/paraphrase/r1`, `framing-list-004/record_1/paraphrase/r2`, `framing-list-004/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-004/record_1/recorded/r1`, `framing-list-004/record_1/recorded/r2`, `framing-list-004/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-004/record_1/bare/r1`, `framing-list-004/record_1/bare/r2`, `framing-list-004/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B

```

## framing-list-011/record_2

### Direct baseline — exact user message

Task: `framing-list-011/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F6XEHG | Built for subzero temperatures | Manual | Cloth | Two | X | A |
| F9GENJ | Used at an Arctic station | Automatic | Cloth | Four | Z | C |
| FB5KQY | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FGWKHG | Built for desert heat | Automatic | Cloth | Two | Y | B |
| FHC324 | Equipped with snow tracks | Manual | Cloth | Four | Z | A |
| FTM6PM | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| FJ4ACX | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FLRZBR | Used at an equatorial station | Manual | Vinyl | Four | X | A |
| FXUB2G | Designed for frozen terrain | Manual | Vinyl | Two | Y | C |
| F56QNC | Operates in tropical forests | Automatic | Vinyl | Four | X | B |

License plate: FLRZBR
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-011/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F6XEHG | Built for subzero temperatures | Manual | Cloth | Two | X | A |
| F9GENJ | Used at an Arctic station | Automatic | Cloth | Four | Z | C |
| FB5KQY | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FGWKHG | Built for desert heat | Automatic | Cloth | Two | Y | B |
| FHC324 | Equipped with snow tracks | Manual | Cloth | Four | Z | A |
| FTM6PM | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| FJ4ACX | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FLRZBR | Used at an equatorial station | Manual | Vinyl | Four | X | A |
| FXUB2G | Designed for frozen terrain | Manual | Vinyl | Two | Y | C |
| F56QNC | Operates in tropical forests | Automatic | Vinyl | Four | X | B |

License plate: FLRZBR
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-011/record_2/original/r1`, `framing-list-011/record_2/original/r2`, `framing-list-011/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-011/record_2/paraphrase/r1`, `framing-list-011/record_2/paraphrase/r2`, `framing-list-011/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-011/record_2/recorded/r1`, `framing-list-011/record_2/recorded/r2`, `framing-list-011/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-011/record_2/bare/r1`, `framing-list-011/record_2/bare/r2`, `framing-list-011/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A

```

## framing-list-008/record_2

### Direct baseline — exact user message

Task: `framing-list-008/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F7AWNL | Built for subzero temperatures | Manual | Vinyl | Two | Z | A |
| FP4SQD | Used at an Arctic station | Manual | Vinyl | Four | X | A |
| FBBKN7 | Used at an equatorial station | Manual | Cloth | Four | Z | C |
| FNNQE8 | Equipped for hot sand | Automatic | Cloth | Four | Y | C |
| FCM7BM | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FETVSK | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| F6S29J | Operates on polar ice | Manual | Cloth | Two | Y | A |
| FVC43Q | Designed for humid summers | Automatic | Vinyl | Four | Z | C |
| FAHD2K | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FWWGRC | Operates in tropical forests | Manual | Vinyl | Four | X | B |

License plate: FWWGRC
Description: Operates in tropical forests
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-008/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F7AWNL | Built for subzero temperatures | Manual | Vinyl | Two | Z | A |
| FP4SQD | Used at an Arctic station | Manual | Vinyl | Four | X | A |
| FBBKN7 | Used at an equatorial station | Manual | Cloth | Four | Z | C |
| FNNQE8 | Equipped for hot sand | Automatic | Cloth | Four | Y | C |
| FCM7BM | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FETVSK | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| F6S29J | Operates on polar ice | Manual | Cloth | Two | Y | A |
| FVC43Q | Designed for humid summers | Automatic | Vinyl | Four | Z | C |
| FAHD2K | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FWWGRC | Operates in tropical forests | Manual | Vinyl | Four | X | B |

License plate: FWWGRC
Description: Operates in tropical forests
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-008/record_2/original/r1`, `framing-list-008/record_2/original/r2`, `framing-list-008/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-008/record_2/paraphrase/r1`, `framing-list-008/record_2/paraphrase/r2`, `framing-list-008/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-008/record_2/recorded/r1`, `framing-list-008/record_2/recorded/r2`, `framing-list-008/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-008/record_2/bare/r1`, `framing-list-008/record_2/bare/r2`, `framing-list-008/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: B

```

## framing-list-019/record_1

### Direct baseline — exact user message

Task: `framing-list-019/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F842BJ | Used at an Arctic station | Automatic | Vinyl | Two | X | A |
| FTUHN4 | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| FT47CP | Operates in tropical forests | Automatic | Cloth | Two | Y | A |
| FLW672 | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| F9NX3W | Designed for humid summers | Manual | Vinyl | Four | Z | C |
| FJNDX4 | Built for desert heat | Manual | Cloth | Two | Z | C |
| FXFPZ9 | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| FCRHYM | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| FZLCUE | Equipped for hot sand | Manual | Cloth | Four | X | C |
| F9U2N6 | Built for subzero temperatures | Manual | Cloth | Two | Y | B |

License plate: F842BJ
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-019/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F842BJ | Used at an Arctic station | Automatic | Vinyl | Two | X | A |
| FTUHN4 | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| FT47CP | Operates in tropical forests | Automatic | Cloth | Two | Y | A |
| FLW672 | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| F9NX3W | Designed for humid summers | Manual | Vinyl | Four | Z | C |
| FJNDX4 | Built for desert heat | Manual | Cloth | Two | Z | C |
| FXFPZ9 | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| FCRHYM | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| FZLCUE | Equipped for hot sand | Manual | Cloth | Four | X | C |
| F9U2N6 | Built for subzero temperatures | Manual | Cloth | Two | Y | B |

License plate: F842BJ
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-019/record_1/original/r1`, `framing-list-019/record_1/original/r2`, `framing-list-019/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-019/record_1/paraphrase/r1`, `framing-list-019/record_1/paraphrase/r2`, `framing-list-019/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-019/record_1/recorded/r1`, `framing-list-019/record_1/recorded/r2`, `framing-list-019/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-019/record_1/bare/r1`, `framing-list-019/record_1/bare/r2`, `framing-list-019/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: A

```

## framing-list-019/record_2

### Direct baseline — exact user message

Task: `framing-list-019/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F842BJ | Used at an Arctic station | Automatic | Vinyl | Two | X | C |
| FTUHN4 | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| FT47CP | Operates in tropical forests | Automatic | Cloth | Two | Y | A |
| FLW672 | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| F9NX3W | Designed for humid summers | Manual | Vinyl | Four | Z | C |
| FJNDX4 | Built for desert heat | Manual | Cloth | Two | Z | C |
| FXFPZ9 | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| FCRHYM | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| FZLCUE | Equipped for hot sand | Manual | Cloth | Four | X | C |
| F9U2N6 | Built for subzero temperatures | Manual | Cloth | Two | Y | B |

License plate: F842BJ
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-019/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F842BJ | Used at an Arctic station | Automatic | Vinyl | Two | X | C |
| FTUHN4 | Operates on polar ice | Automatic | Vinyl | Four | X | B |
| FT47CP | Operates in tropical forests | Automatic | Cloth | Two | Y | A |
| FLW672 | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| F9NX3W | Designed for humid summers | Manual | Vinyl | Four | Z | C |
| FJNDX4 | Built for desert heat | Manual | Cloth | Two | Z | C |
| FXFPZ9 | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| FCRHYM | Designed for frozen terrain | Manual | Cloth | Four | Z | B |
| FZLCUE | Equipped for hot sand | Manual | Cloth | Four | X | C |
| F9U2N6 | Built for subzero temperatures | Manual | Cloth | Two | Y | B |

License plate: F842BJ
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-019/record_2/original/r1`, `framing-list-019/record_2/original/r2`, `framing-list-019/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-019/record_2/paraphrase/r1`, `framing-list-019/record_2/paraphrase/r2`, `framing-list-019/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-019/record_2/recorded/r1`, `framing-list-019/record_2/recorded/r2`, `framing-list-019/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-019/record_2/bare/r1`, `framing-list-019/record_2/bare/r2`, `framing-list-019/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F842BJ.

1. **Given Data for F842BJ:**
   - License plate: F842BJ
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C

```

## framing-list-022/record_1

### Direct baseline — exact user message

Task: `framing-list-022/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FDVR9G | Operates on polar ice | Manual | Cloth | Four | X | B |
| FJXQ6Z | Designed for humid summers | Manual | Vinyl | Four | X | A |
| F32RE8 | Operates in tropical forests | Automatic | Vinyl | Four | Y | C |
| FR6Z8Y | Equipped for hot sand | Automatic | Vinyl | Four | Z | C |
| FRM5WJ | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| FHWNS7 | Used at an Arctic station | Automatic | Cloth | Four | Y | B |
| F9B9RH | Designed for frozen terrain | Manual | Vinyl | Four | Z | B |
| FAHPGC | Built for subzero temperatures | Manual | Vinyl | Four | Z | C |
| FXWTSC | Built for desert heat | Automatic | Vinyl | Two | X | C |
| FR8BZT | Equipped with snow tracks | Automatic | Cloth | Two | Y | B |

License plate: FAHPGC
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-022/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FDVR9G | Operates on polar ice | Manual | Cloth | Four | X | B |
| FJXQ6Z | Designed for humid summers | Manual | Vinyl | Four | X | A |
| F32RE8 | Operates in tropical forests | Automatic | Vinyl | Four | Y | C |
| FR6Z8Y | Equipped for hot sand | Automatic | Vinyl | Four | Z | C |
| FRM5WJ | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| FHWNS7 | Used at an Arctic station | Automatic | Cloth | Four | Y | B |
| F9B9RH | Designed for frozen terrain | Manual | Vinyl | Four | Z | B |
| FAHPGC | Built for subzero temperatures | Manual | Vinyl | Four | Z | C |
| FXWTSC | Built for desert heat | Automatic | Vinyl | Two | X | C |
| FR8BZT | Equipped with snow tracks | Automatic | Cloth | Two | Y | B |

License plate: FAHPGC
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-022/record_1/original/r1`, `framing-list-022/record_1/original/r2`, `framing-list-022/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-022/record_1/paraphrase/r1`, `framing-list-022/record_1/paraphrase/r2`, `framing-list-022/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-022/record_1/recorded/r1`, `framing-list-022/record_1/recorded/r2`, `framing-list-022/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-022/record_1/bare/r1`, `framing-list-022/record_1/bare/r2`, `framing-list-022/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C

```

## framing-list-017/record_1

### Direct baseline — exact user message

Task: `framing-list-017/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FYNYN4 | Used at an Arctic station | Automatic | Vinyl | Four | X | A |
| F9NRHQ | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FR68AG | Designed for frozen terrain | Manual | Vinyl | Four | Z | C |
| FJ3PWP | Designed for humid summers | Automatic | Cloth | Four | Y | B |
| FP7BGT | Equipped for hot sand | Automatic | Vinyl | Four | Z | B |
| FGRP3R | Built for desert heat | Manual | Cloth | Four | Z | C |
| FX98LH | Used at an equatorial station | Manual | Vinyl | Four | Y | B |
| FBUX42 | Built for subzero temperatures | Automatic | Cloth | Four | Y | A |
| FRAFD4 | Equipped with snow tracks | Automatic | Vinyl | Four | X | A |
| FZ79HL | Operates in tropical forests | Automatic | Cloth | Two | Y | C |

License plate: FR68AG
Description: Designed for frozen terrain
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-017/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FYNYN4 | Used at an Arctic station | Automatic | Vinyl | Four | X | A |
| F9NRHQ | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FR68AG | Designed for frozen terrain | Manual | Vinyl | Four | Z | C |
| FJ3PWP | Designed for humid summers | Automatic | Cloth | Four | Y | B |
| FP7BGT | Equipped for hot sand | Automatic | Vinyl | Four | Z | B |
| FGRP3R | Built for desert heat | Manual | Cloth | Four | Z | C |
| FX98LH | Used at an equatorial station | Manual | Vinyl | Four | Y | B |
| FBUX42 | Built for subzero temperatures | Automatic | Cloth | Four | Y | A |
| FRAFD4 | Equipped with snow tracks | Automatic | Vinyl | Four | X | A |
| FZ79HL | Operates in tropical forests | Automatic | Cloth | Two | Y | C |

License plate: FR68AG
Description: Designed for frozen terrain
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-017/record_1/original/r1`, `framing-list-017/record_1/original/r2`, `framing-list-017/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-017/record_1/paraphrase/r1`, `framing-list-017/record_1/paraphrase/r2`, `framing-list-017/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-017/record_1/recorded/r1`, `framing-list-017/record_1/recorded/r2`, `framing-list-017/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-017/record_1/bare/r1`, `framing-list-017/record_1/bare/r2`, `framing-list-017/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FR68AG.

1. **Given Data for FR68AG:**
   - License plate: FR68AG
   - Description: Designed for frozen terrain
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C

```

## framing-list-014/record_2

### Direct baseline — exact user message

Task: `framing-list-014/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F2529R | Used at an equatorial station | Automatic | Cloth | Two | X | A |
| FNR52T | Operates on polar ice | Automatic | Vinyl | Two | Y | A |
| FUPTZ8 | Equipped with snow tracks | Manual | Cloth | Two | Z | C |
| FBPB3F | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FRVUEV | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| FMJALR | Designed for frozen terrain | Automatic | Vinyl | Four | X | C |
| FLCCUU | Equipped for hot sand | Manual | Vinyl | Two | X | A |
| FDNWST | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FSZ3HE | Operates in tropical forests | Manual | Cloth | Two | Z | B |
| FDLA2M | Built for desert heat | Automatic | Vinyl | Four | X | B |

License plate: FNR52T
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-014/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F2529R | Used at an equatorial station | Automatic | Cloth | Two | X | A |
| FNR52T | Operates on polar ice | Automatic | Vinyl | Two | Y | A |
| FUPTZ8 | Equipped with snow tracks | Manual | Cloth | Two | Z | C |
| FBPB3F | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FRVUEV | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| FMJALR | Designed for frozen terrain | Automatic | Vinyl | Four | X | C |
| FLCCUU | Equipped for hot sand | Manual | Vinyl | Two | X | A |
| FDNWST | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FSZ3HE | Operates in tropical forests | Manual | Cloth | Two | Z | B |
| FDLA2M | Built for desert heat | Automatic | Vinyl | Four | X | B |

License plate: FNR52T
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-014/record_2/original/r1`, `framing-list-014/record_2/original/r2`, `framing-list-014/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-014/record_2/paraphrase/r1`, `framing-list-014/record_2/paraphrase/r2`, `framing-list-014/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-014/record_2/recorded/r1`, `framing-list-014/record_2/recorded/r2`, `framing-list-014/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-014/record_2/bare/r1`, `framing-list-014/record_2/bare/r2`, `framing-list-014/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A

```

## framing-list-020/record_1

### Direct baseline — exact user message

Task: `framing-list-020/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRACXK | Used at an Arctic station | Automatic | Cloth | Four | Z | A |
| FTDZ7A | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| FJZ9S5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |
| FBMV6Q | Designed for humid summers | Manual | Vinyl | Two | Z | C |
| FYWQXB | Used at an equatorial station | Automatic | Vinyl | Two | X | B |
| FZXFSU | Operates on polar ice | Automatic | Vinyl | Two | Z | B |
| FBBTD9 | Equipped for hot sand | Automatic | Vinyl | Four | Y | B |
| F5K84S | Equipped with snow tracks | Manual | Vinyl | Four | X | A |
| FGZ5FH | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| FGPJ65 | Built for desert heat | Automatic | Vinyl | Two | X | C |

License plate: FZXFSU
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-020/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRACXK | Used at an Arctic station | Automatic | Cloth | Four | Z | A |
| FTDZ7A | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| FJZ9S5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |
| FBMV6Q | Designed for humid summers | Manual | Vinyl | Two | Z | C |
| FYWQXB | Used at an equatorial station | Automatic | Vinyl | Two | X | B |
| FZXFSU | Operates on polar ice | Automatic | Vinyl | Two | Z | B |
| FBBTD9 | Equipped for hot sand | Automatic | Vinyl | Four | Y | B |
| F5K84S | Equipped with snow tracks | Manual | Vinyl | Four | X | A |
| FGZ5FH | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| FGPJ65 | Built for desert heat | Automatic | Vinyl | Two | X | C |

License plate: FZXFSU
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-020/record_1/original/r1`, `framing-list-020/record_1/original/r2`, `framing-list-020/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-020/record_1/paraphrase/r1`, `framing-list-020/record_1/paraphrase/r2`, `framing-list-020/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-020/record_1/recorded/r1`, `framing-list-020/record_1/recorded/r2`, `framing-list-020/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-020/record_1/bare/r1`, `framing-list-020/record_1/bare/r2`, `framing-list-020/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FZXFSU.

1. **Given Data for FZXFSU:**
   - License plate: FZXFSU
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: B

```

## framing-list-013/record_2

### Direct baseline — exact user message

Task: `framing-list-013/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FZHVV2 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| FKWRBR | Used at an Arctic station | Manual | Cloth | Two | Y | C |
| FH6SNJ | Equipped with snow tracks | Manual | Cloth | Four | Y | A |
| FRYBTP | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |
| FNCN8U | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQMQPB | Operates in tropical forests | Automatic | Cloth | Four | X | A |
| F9K6NK | Used at an equatorial station | Manual | Cloth | Two | Z | A |
| FGZ4Z7 | Equipped for hot sand | Manual | Vinyl | Two | X | B |
| F3YR26 | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FQEMNP | Built for desert heat | Manual | Cloth | Four | Y | B |

License plate: FH6SNJ
Description: Equipped with snow tracks
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-013/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FZHVV2 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| FKWRBR | Used at an Arctic station | Manual | Cloth | Two | Y | C |
| FH6SNJ | Equipped with snow tracks | Manual | Cloth | Four | Y | A |
| FRYBTP | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |
| FNCN8U | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQMQPB | Operates in tropical forests | Automatic | Cloth | Four | X | A |
| F9K6NK | Used at an equatorial station | Manual | Cloth | Two | Z | A |
| FGZ4Z7 | Equipped for hot sand | Manual | Vinyl | Two | X | B |
| F3YR26 | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FQEMNP | Built for desert heat | Manual | Cloth | Four | Y | B |

License plate: FH6SNJ
Description: Equipped with snow tracks
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-013/record_2/original/r1`, `framing-list-013/record_2/original/r2`, `framing-list-013/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-013/record_2/paraphrase/r1`, `framing-list-013/record_2/paraphrase/r2`, `framing-list-013/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-013/record_2/recorded/r1`, `framing-list-013/record_2/recorded/r2`, `framing-list-013/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-013/record_2/bare/r1`, `framing-list-013/record_2/bare/r2`, `framing-list-013/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: A

```

## framing-list-014/record_1

### Direct baseline — exact user message

Task: `framing-list-014/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F2529R | Used at an equatorial station | Automatic | Cloth | Two | X | A |
| FNR52T | Operates on polar ice | Automatic | Vinyl | Two | Y | B |
| FUPTZ8 | Equipped with snow tracks | Manual | Cloth | Two | Z | C |
| FBPB3F | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FRVUEV | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| FMJALR | Designed for frozen terrain | Automatic | Vinyl | Four | X | C |
| FLCCUU | Equipped for hot sand | Manual | Vinyl | Two | X | A |
| FDNWST | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FSZ3HE | Operates in tropical forests | Manual | Cloth | Two | Z | B |
| FDLA2M | Built for desert heat | Automatic | Vinyl | Four | X | B |

License plate: FNR52T
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-014/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F2529R | Used at an equatorial station | Automatic | Cloth | Two | X | A |
| FNR52T | Operates on polar ice | Automatic | Vinyl | Two | Y | B |
| FUPTZ8 | Equipped with snow tracks | Manual | Cloth | Two | Z | C |
| FBPB3F | Built for subzero temperatures | Automatic | Cloth | Two | Y | C |
| FRVUEV | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| FMJALR | Designed for frozen terrain | Automatic | Vinyl | Four | X | C |
| FLCCUU | Equipped for hot sand | Manual | Vinyl | Two | X | A |
| FDNWST | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FSZ3HE | Operates in tropical forests | Manual | Cloth | Two | Z | B |
| FDLA2M | Built for desert heat | Automatic | Vinyl | Four | X | B |

License plate: FNR52T
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-014/record_1/original/r1`, `framing-list-014/record_1/original/r2`, `framing-list-014/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-014/record_1/paraphrase/r1`, `framing-list-014/record_1/paraphrase/r2`, `framing-list-014/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-014/record_1/recorded/r1`, `framing-list-014/record_1/recorded/r2`, `framing-list-014/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-014/record_1/bare/r1`, `framing-list-014/record_1/bare/r2`, `framing-list-014/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNR52T.

1. **Given Data for FNR52T:**
   - License plate: FNR52T
   - Description: Operates on polar ice
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B

```

## framing-list-006/record_1

### Direct baseline — exact user message

Task: `framing-list-006/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FUEK7A | Designed for humid summers | Manual | Vinyl | Four | Y | C |
| FTDTM8 | Equipped for hot sand | Manual | Vinyl | Four | Z | B |
| FMNGYP | Operates on polar ice | Manual | Cloth | Two | Y | A |
| F36KFN | Equipped with snow tracks | Manual | Cloth | Two | Z | A |
| FEMP8V | Used at an equatorial station | Automatic | Vinyl | Four | Z | B |
| FDZP5B | Used at an Arctic station | Automatic | Vinyl | Two | X | A |
| FVH7UT | Built for desert heat | Automatic | Cloth | Two | X | C |
| FAUYUW | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| F2XRAG | Built for subzero temperatures | Automatic | Vinyl | Four | Z | C |
| FBFMLR | Designed for frozen terrain | Automatic | Cloth | Two | Y | A |

License plate: F2XRAG
Description: Built for subzero temperatures
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-006/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FUEK7A | Designed for humid summers | Manual | Vinyl | Four | Y | C |
| FTDTM8 | Equipped for hot sand | Manual | Vinyl | Four | Z | B |
| FMNGYP | Operates on polar ice | Manual | Cloth | Two | Y | A |
| F36KFN | Equipped with snow tracks | Manual | Cloth | Two | Z | A |
| FEMP8V | Used at an equatorial station | Automatic | Vinyl | Four | Z | B |
| FDZP5B | Used at an Arctic station | Automatic | Vinyl | Two | X | A |
| FVH7UT | Built for desert heat | Automatic | Cloth | Two | X | C |
| FAUYUW | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| F2XRAG | Built for subzero temperatures | Automatic | Vinyl | Four | Z | C |
| FBFMLR | Designed for frozen terrain | Automatic | Cloth | Two | Y | A |

License plate: F2XRAG
Description: Built for subzero temperatures
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-006/record_1/original/r1`, `framing-list-006/record_1/original/r2`, `framing-list-006/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-006/record_1/paraphrase/r1`, `framing-list-006/record_1/paraphrase/r2`, `framing-list-006/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-006/record_1/recorded/r1`, `framing-list-006/record_1/recorded/r2`, `framing-list-006/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-006/record_1/bare/r1`, `framing-list-006/record_1/bare/r2`, `framing-list-006/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F2XRAG.

1. **Given Data for F2XRAG:**
   - License plate: F2XRAG
   - Description: Built for subzero temperatures
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: C

```

## framing-list-023/record_2

### Direct baseline — exact user message

Task: `framing-list-023/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FTVLQC | Designed for frozen terrain | Automatic | Vinyl | Two | Y | C |
| FCPWVV | Designed for humid summers | Manual | Vinyl | Two | X | B |
| FNRVVM | Equipped with snow tracks | Manual | Vinyl | Four | Y | A |
| FV2HN5 | Equipped for hot sand | Manual | Cloth | Two | Z | B |
| FMABDD | Operates in tropical forests | Automatic | Cloth | Four | Y | C |
| F7U8ZH | Used at an equatorial station | Manual | Vinyl | Two | X | B |
| FJ6JYB | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FT8K3U | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FK4WVE | Built for desert heat | Manual | Cloth | Two | Z | B |
| FH6PXU | Used at an Arctic station | Manual | Cloth | Four | Z | A |

License plate: FMABDD
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-023/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FTVLQC | Designed for frozen terrain | Automatic | Vinyl | Two | Y | C |
| FCPWVV | Designed for humid summers | Manual | Vinyl | Two | X | B |
| FNRVVM | Equipped with snow tracks | Manual | Vinyl | Four | Y | A |
| FV2HN5 | Equipped for hot sand | Manual | Cloth | Two | Z | B |
| FMABDD | Operates in tropical forests | Automatic | Cloth | Four | Y | C |
| F7U8ZH | Used at an equatorial station | Manual | Vinyl | Two | X | B |
| FJ6JYB | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FT8K3U | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FK4WVE | Built for desert heat | Manual | Cloth | Two | Z | B |
| FH6PXU | Used at an Arctic station | Manual | Cloth | Four | Z | A |

License plate: FMABDD
Description: Operates in tropical forests
Transmission: Automatic
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-023/record_2/original/r1`, `framing-list-023/record_2/original/r2`, `framing-list-023/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-023/record_2/paraphrase/r1`, `framing-list-023/record_2/paraphrase/r2`, `framing-list-023/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-023/record_2/recorded/r1`, `framing-list-023/record_2/recorded/r2`, `framing-list-023/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-023/record_2/bare/r1`, `framing-list-023/record_2/bare/r2`, `framing-list-023/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FMABDD.

1. **Given Data for FMABDD:**
   - License plate: FMABDD
   - Description: Operates in tropical forests
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: C

```

## framing-list-009/record_2

### Direct baseline — exact user message

Task: `framing-list-009/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FKEP6Z | Operates in tropical forests | Manual | Vinyl | Four | Y | B |
| FK5CSG | Designed for humid summers | Automatic | Cloth | Four | Z | B |
| F78EW2 | Equipped for hot sand | Automatic | Vinyl | Two | Y | B |
| F98JPA | Used at an Arctic station | Automatic | Vinyl | Two | Y | B |
| FL95XL | Equipped with snow tracks | Automatic | Vinyl | Two | Z | C |
| FDTJSW | Designed for frozen terrain | Manual | Vinyl | Four | X | C |
| FE5C5A | Built for desert heat | Automatic | Vinyl | Two | X | A |
| FYNZ8M | Used at an equatorial station | Manual | Cloth | Four | Y | A |
| FEVN5B | Built for subzero temperatures | Automatic | Cloth | Four | Z | C |
| FVJ4BT | Operates on polar ice | Manual | Vinyl | Two | X | C |

License plate: F98JPA
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-009/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FKEP6Z | Operates in tropical forests | Manual | Vinyl | Four | Y | B |
| FK5CSG | Designed for humid summers | Automatic | Cloth | Four | Z | B |
| F78EW2 | Equipped for hot sand | Automatic | Vinyl | Two | Y | B |
| F98JPA | Used at an Arctic station | Automatic | Vinyl | Two | Y | B |
| FL95XL | Equipped with snow tracks | Automatic | Vinyl | Two | Z | C |
| FDTJSW | Designed for frozen terrain | Manual | Vinyl | Four | X | C |
| FE5C5A | Built for desert heat | Automatic | Vinyl | Two | X | A |
| FYNZ8M | Used at an equatorial station | Manual | Cloth | Four | Y | A |
| FEVN5B | Built for subzero temperatures | Automatic | Cloth | Four | Z | C |
| FVJ4BT | Operates on polar ice | Manual | Vinyl | Two | X | C |

License plate: F98JPA
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-009/record_2/original/r1`, `framing-list-009/record_2/original/r2`, `framing-list-009/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-009/record_2/paraphrase/r1`, `framing-list-009/record_2/paraphrase/r2`, `framing-list-009/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-009/record_2/recorded/r1`, `framing-list-009/record_2/recorded/r2`, `framing-list-009/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-009/record_2/bare/r1`, `framing-list-009/record_2/bare/r2`, `framing-list-009/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: B

```

## framing-list-009/record_1

### Direct baseline — exact user message

Task: `framing-list-009/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FKEP6Z | Operates in tropical forests | Manual | Vinyl | Four | Y | B |
| FK5CSG | Designed for humid summers | Automatic | Cloth | Four | Z | B |
| F78EW2 | Equipped for hot sand | Automatic | Vinyl | Two | Y | B |
| F98JPA | Used at an Arctic station | Automatic | Vinyl | Two | Y | A |
| FL95XL | Equipped with snow tracks | Automatic | Vinyl | Two | Z | C |
| FDTJSW | Designed for frozen terrain | Manual | Vinyl | Four | X | C |
| FE5C5A | Built for desert heat | Automatic | Vinyl | Two | X | A |
| FYNZ8M | Used at an equatorial station | Manual | Cloth | Four | Y | A |
| FEVN5B | Built for subzero temperatures | Automatic | Cloth | Four | Z | C |
| FVJ4BT | Operates on polar ice | Manual | Vinyl | Two | X | C |

License plate: F98JPA
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-009/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FKEP6Z | Operates in tropical forests | Manual | Vinyl | Four | Y | B |
| FK5CSG | Designed for humid summers | Automatic | Cloth | Four | Z | B |
| F78EW2 | Equipped for hot sand | Automatic | Vinyl | Two | Y | B |
| F98JPA | Used at an Arctic station | Automatic | Vinyl | Two | Y | A |
| FL95XL | Equipped with snow tracks | Automatic | Vinyl | Two | Z | C |
| FDTJSW | Designed for frozen terrain | Manual | Vinyl | Four | X | C |
| FE5C5A | Built for desert heat | Automatic | Vinyl | Two | X | A |
| FYNZ8M | Used at an equatorial station | Manual | Cloth | Four | Y | A |
| FEVN5B | Built for subzero temperatures | Automatic | Cloth | Four | Z | C |
| FVJ4BT | Operates on polar ice | Manual | Vinyl | Two | X | C |

License plate: F98JPA
Description: Used at an Arctic station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-009/record_1/original/r1`, `framing-list-009/record_1/original/r2`, `framing-list-009/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-009/record_1/paraphrase/r1`, `framing-list-009/record_1/paraphrase/r2`, `framing-list-009/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-009/record_1/recorded/r1`, `framing-list-009/record_1/recorded/r2`, `framing-list-009/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-009/record_1/bare/r1`, `framing-list-009/record_1/bare/r2`, `framing-list-009/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate F98JPA.

1. **Given Data for F98JPA:**
   - License plate: F98JPA
   - Description: Used at an Arctic station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Y
   - Verified class: A

```

## framing-list-010/record_2

### Direct baseline — exact user message

Task: `framing-list-010/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F457H3 | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| F4SHB2 | Used at an Arctic station | Automatic | Vinyl | Four | X | B |
| FE7PPP | Operates on polar ice | Manual | Cloth | Four | Z | A |
| FNEXGU | Designed for humid summers | Manual | Cloth | Two | Y | B |
| FAUVMJ | Built for desert heat | Manual | Vinyl | Four | Z | C |
| FX55HP | Designed for frozen terrain | Manual | Cloth | Two | X | B |
| FWEPUG | Operates in tropical forests | Automatic | Cloth | Two | Y | C |
| F9M8CU | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| FWTSXL | Equipped with snow tracks | Manual | Vinyl | Four | Z | A |
| FQLQPW | Used at an equatorial station | Automatic | Cloth | Four | X | C |

License plate: FNEXGU
Description: Designed for humid summers
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-010/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F457H3 | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| F4SHB2 | Used at an Arctic station | Automatic | Vinyl | Four | X | B |
| FE7PPP | Operates on polar ice | Manual | Cloth | Four | Z | A |
| FNEXGU | Designed for humid summers | Manual | Cloth | Two | Y | B |
| FAUVMJ | Built for desert heat | Manual | Vinyl | Four | Z | C |
| FX55HP | Designed for frozen terrain | Manual | Cloth | Two | X | B |
| FWEPUG | Operates in tropical forests | Automatic | Cloth | Two | Y | C |
| F9M8CU | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| FWTSXL | Equipped with snow tracks | Manual | Vinyl | Four | Z | A |
| FQLQPW | Used at an equatorial station | Automatic | Cloth | Four | X | C |

License plate: FNEXGU
Description: Designed for humid summers
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-010/record_2/original/r1`, `framing-list-010/record_2/original/r2`, `framing-list-010/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-010/record_2/paraphrase/r1`, `framing-list-010/record_2/paraphrase/r2`, `framing-list-010/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-010/record_2/recorded/r1`, `framing-list-010/record_2/recorded/r2`, `framing-list-010/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-010/record_2/bare/r1`, `framing-list-010/record_2/bare/r2`, `framing-list-010/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNEXGU.

1. **Given Data for FNEXGU:**
   - License plate: FNEXGU
   - Description: Designed for humid summers
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B

```

## framing-list-022/record_2

### Direct baseline — exact user message

Task: `framing-list-022/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FDVR9G | Operates on polar ice | Manual | Cloth | Four | X | B |
| FJXQ6Z | Designed for humid summers | Manual | Vinyl | Four | X | A |
| F32RE8 | Operates in tropical forests | Automatic | Vinyl | Four | Y | C |
| FR6Z8Y | Equipped for hot sand | Automatic | Vinyl | Four | Z | C |
| FRM5WJ | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| FHWNS7 | Used at an Arctic station | Automatic | Cloth | Four | Y | B |
| F9B9RH | Designed for frozen terrain | Manual | Vinyl | Four | Z | B |
| FAHPGC | Built for subzero temperatures | Manual | Vinyl | Four | Z | A |
| FXWTSC | Built for desert heat | Automatic | Vinyl | Two | X | C |
| FR8BZT | Equipped with snow tracks | Automatic | Cloth | Two | Y | B |

License plate: FAHPGC
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-022/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FDVR9G | Operates on polar ice | Manual | Cloth | Four | X | B |
| FJXQ6Z | Designed for humid summers | Manual | Vinyl | Four | X | A |
| F32RE8 | Operates in tropical forests | Automatic | Vinyl | Four | Y | C |
| FR6Z8Y | Equipped for hot sand | Automatic | Vinyl | Four | Z | C |
| FRM5WJ | Used at an equatorial station | Manual | Cloth | Two | Y | A |
| FHWNS7 | Used at an Arctic station | Automatic | Cloth | Four | Y | B |
| F9B9RH | Designed for frozen terrain | Manual | Vinyl | Four | Z | B |
| FAHPGC | Built for subzero temperatures | Manual | Vinyl | Four | Z | A |
| FXWTSC | Built for desert heat | Automatic | Vinyl | Two | X | C |
| FR8BZT | Equipped with snow tracks | Automatic | Cloth | Two | Y | B |

License plate: FAHPGC
Description: Built for subzero temperatures
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-022/record_2/original/r1`, `framing-list-022/record_2/original/r2`, `framing-list-022/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-022/record_2/paraphrase/r1`, `framing-list-022/record_2/paraphrase/r2`, `framing-list-022/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-022/record_2/recorded/r1`, `framing-list-022/record_2/recorded/r2`, `framing-list-022/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-022/record_2/bare/r1`, `framing-list-022/record_2/bare/r2`, `framing-list-022/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FAHPGC.

1. **Given Data for FAHPGC:**
   - License plate: FAHPGC
   - Description: Built for subzero temperatures
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Z
   - Verified class: A

```

## framing-list-008/record_1

### Direct baseline — exact user message

Task: `framing-list-008/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F7AWNL | Built for subzero temperatures | Manual | Vinyl | Two | Z | A |
| FP4SQD | Used at an Arctic station | Manual | Vinyl | Four | X | A |
| FBBKN7 | Used at an equatorial station | Manual | Cloth | Four | Z | C |
| FNNQE8 | Equipped for hot sand | Automatic | Cloth | Four | Y | C |
| FCM7BM | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FETVSK | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| F6S29J | Operates on polar ice | Manual | Cloth | Two | Y | A |
| FVC43Q | Designed for humid summers | Automatic | Vinyl | Four | Z | C |
| FAHD2K | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FWWGRC | Operates in tropical forests | Manual | Vinyl | Four | X | A |

License plate: FWWGRC
Description: Operates in tropical forests
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-008/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F7AWNL | Built for subzero temperatures | Manual | Vinyl | Two | Z | A |
| FP4SQD | Used at an Arctic station | Manual | Vinyl | Four | X | A |
| FBBKN7 | Used at an equatorial station | Manual | Cloth | Four | Z | C |
| FNNQE8 | Equipped for hot sand | Automatic | Cloth | Four | Y | C |
| FCM7BM | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FETVSK | Equipped with snow tracks | Automatic | Cloth | Four | X | B |
| F6S29J | Operates on polar ice | Manual | Cloth | Two | Y | A |
| FVC43Q | Designed for humid summers | Automatic | Vinyl | Four | Z | C |
| FAHD2K | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FWWGRC | Operates in tropical forests | Manual | Vinyl | Four | X | A |

License plate: FWWGRC
Description: Operates in tropical forests
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-008/record_1/original/r1`, `framing-list-008/record_1/original/r2`, `framing-list-008/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-008/record_1/paraphrase/r1`, `framing-list-008/record_1/paraphrase/r2`, `framing-list-008/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-008/record_1/recorded/r1`, `framing-list-008/record_1/recorded/r2`, `framing-list-008/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-008/record_1/bare/r1`, `framing-list-008/record_1/bare/r2`, `framing-list-008/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FWWGRC.

1. **Given Data for FWWGRC:**
   - License plate: FWWGRC
   - Description: Operates in tropical forests
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: A

```

## framing-list-011/record_1

### Direct baseline — exact user message

Task: `framing-list-011/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F6XEHG | Built for subzero temperatures | Manual | Cloth | Two | X | A |
| F9GENJ | Used at an Arctic station | Automatic | Cloth | Four | Z | C |
| FB5KQY | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FGWKHG | Built for desert heat | Automatic | Cloth | Two | Y | B |
| FHC324 | Equipped with snow tracks | Manual | Cloth | Four | Z | A |
| FTM6PM | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| FJ4ACX | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FLRZBR | Used at an equatorial station | Manual | Vinyl | Four | X | C |
| FXUB2G | Designed for frozen terrain | Manual | Vinyl | Two | Y | C |
| F56QNC | Operates in tropical forests | Automatic | Vinyl | Four | X | B |

License plate: FLRZBR
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-011/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F6XEHG | Built for subzero temperatures | Manual | Cloth | Two | X | A |
| F9GENJ | Used at an Arctic station | Automatic | Cloth | Four | Z | C |
| FB5KQY | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FGWKHG | Built for desert heat | Automatic | Cloth | Two | Y | B |
| FHC324 | Equipped with snow tracks | Manual | Cloth | Four | Z | A |
| FTM6PM | Equipped for hot sand | Manual | Vinyl | Two | Z | B |
| FJ4ACX | Operates on polar ice | Automatic | Vinyl | Two | X | A |
| FLRZBR | Used at an equatorial station | Manual | Vinyl | Four | X | C |
| FXUB2G | Designed for frozen terrain | Manual | Vinyl | Two | Y | C |
| F56QNC | Operates in tropical forests | Automatic | Vinyl | Four | X | B |

License plate: FLRZBR
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-011/record_1/original/r1`, `framing-list-011/record_1/original/r2`, `framing-list-011/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-011/record_1/paraphrase/r1`, `framing-list-011/record_1/paraphrase/r2`, `framing-list-011/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-011/record_1/recorded/r1`, `framing-list-011/record_1/recorded/r2`, `framing-list-011/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-011/record_1/bare/r1`, `framing-list-011/record_1/bare/r2`, `framing-list-011/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FLRZBR.

1. **Given Data for FLRZBR:**
   - License plate: FLRZBR
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: X
   - Verified class: C

```

## framing-list-021/record_1

### Direct baseline — exact user message

Task: `framing-list-021/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FPRFU9 | Equipped with snow tracks | Automatic | Cloth | Four | Y | B |
| FCHTCA | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FXS9D5 | Used at an equatorial station | Automatic | Cloth | Two | Z | C |
| FTZSJ7 | Used at an Arctic station | Manual | Vinyl | Two | Z | B |
| FQ44SP | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| FXR4W9 | Operates on polar ice | Manual | Vinyl | Four | Z | A |
| FX9962 | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| F3GY8N | Operates in tropical forests | Manual | Vinyl | Two | Z | C |
| FLH8ST | Designed for frozen terrain | Automatic | Vinyl | Two | X | A |
| F9D7XC | Built for desert heat | Automatic | Vinyl | Four | X | C |

License plate: FCHTCA
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-021/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FPRFU9 | Equipped with snow tracks | Automatic | Cloth | Four | Y | B |
| FCHTCA | Designed for humid summers | Automatic | Cloth | Two | Y | B |
| FXS9D5 | Used at an equatorial station | Automatic | Cloth | Two | Z | C |
| FTZSJ7 | Used at an Arctic station | Manual | Vinyl | Two | Z | B |
| FQ44SP | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| FXR4W9 | Operates on polar ice | Manual | Vinyl | Four | Z | A |
| FX9962 | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| F3GY8N | Operates in tropical forests | Manual | Vinyl | Two | Z | C |
| FLH8ST | Designed for frozen terrain | Automatic | Vinyl | Two | X | A |
| F9D7XC | Built for desert heat | Automatic | Vinyl | Four | X | C |

License plate: FCHTCA
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-021/record_1/original/r1`, `framing-list-021/record_1/original/r2`, `framing-list-021/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-021/record_1/paraphrase/r1`, `framing-list-021/record_1/paraphrase/r2`, `framing-list-021/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-021/record_1/recorded/r1`, `framing-list-021/record_1/recorded/r2`, `framing-list-021/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-021/record_1/bare/r1`, `framing-list-021/record_1/bare/r2`, `framing-list-021/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: B

```

## framing-list-012/record_1

### Direct baseline — exact user message

Task: `framing-list-012/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FMUJ5B | Designed for frozen terrain | Automatic | Vinyl | Two | X | B |
| F3YDBX | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| F8BE47 | Built for subzero temperatures | Manual | Vinyl | Four | Z | C |
| FRABFK | Designed for humid summers | Automatic | Vinyl | Four | X | A |
| FKRKB3 | Used at an equatorial station | Manual | Vinyl | Four | Y | A |
| FXAEEM | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FNWYZG | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| FVC36V | Operates on polar ice | Manual | Cloth | Two | Y | C |
| FAUCN5 | Equipped with snow tracks | Manual | Vinyl | Two | Z | B |
| FMR4QH | Built for desert heat | Manual | Vinyl | Four | Z | A |

License plate: FNWYZG
Description: Equipped for hot sand
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-012/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FMUJ5B | Designed for frozen terrain | Automatic | Vinyl | Two | X | B |
| F3YDBX | Used at an Arctic station | Automatic | Vinyl | Two | Z | C |
| F8BE47 | Built for subzero temperatures | Manual | Vinyl | Four | Z | C |
| FRABFK | Designed for humid summers | Automatic | Vinyl | Four | X | A |
| FKRKB3 | Used at an equatorial station | Manual | Vinyl | Four | Y | A |
| FXAEEM | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FNWYZG | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| FVC36V | Operates on polar ice | Manual | Cloth | Two | Y | C |
| FAUCN5 | Equipped with snow tracks | Manual | Vinyl | Two | Z | B |
| FMR4QH | Built for desert heat | Manual | Vinyl | Four | Z | A |

License plate: FNWYZG
Description: Equipped for hot sand
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-012/record_1/original/r1`, `framing-list-012/record_1/original/r2`, `framing-list-012/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-012/record_1/paraphrase/r1`, `framing-list-012/record_1/paraphrase/r2`, `framing-list-012/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-012/record_1/recorded/r1`, `framing-list-012/record_1/recorded/r2`, `framing-list-012/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-012/record_1/bare/r1`, `framing-list-012/record_1/bare/r2`, `framing-list-012/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNWYZG.

1. **Given Data for FNWYZG:**
   - License plate: FNWYZG
   - Description: Equipped for hot sand
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: X
   - Verified class: C

```

## framing-list-001/record_1

### Direct baseline — exact user message

Task: `framing-list-001/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FY6DHG | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| FFTC6L | Operates in tropical forests | Manual | Vinyl | Four | X | A |
| F62Z8M | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| FG3A4Z | Built for desert heat | Automatic | Vinyl | Four | Y | B |
| FBCVQW | Equipped with snow tracks | Automatic | Cloth | Two | X | C |
| FSBGXU | Operates on polar ice | Automatic | Cloth | Four | Z | B |
| FSY9NC | Used at an Arctic station | Automatic | Cloth | Two | Z | B |
| FKPQB2 | Equipped for hot sand | Automatic | Vinyl | Four | Z | A |
| FYK2TS | Designed for humid summers | Manual | Cloth | Four | Y | A |
| FWZ557 | Built for subzero temperatures | Manual | Cloth | Four | Z | C |

License plate: FG3A4Z
Description: Built for desert heat
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-001/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FY6DHG | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| FFTC6L | Operates in tropical forests | Manual | Vinyl | Four | X | A |
| F62Z8M | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| FG3A4Z | Built for desert heat | Automatic | Vinyl | Four | Y | B |
| FBCVQW | Equipped with snow tracks | Automatic | Cloth | Two | X | C |
| FSBGXU | Operates on polar ice | Automatic | Cloth | Four | Z | B |
| FSY9NC | Used at an Arctic station | Automatic | Cloth | Two | Z | B |
| FKPQB2 | Equipped for hot sand | Automatic | Vinyl | Four | Z | A |
| FYK2TS | Designed for humid summers | Manual | Cloth | Four | Y | A |
| FWZ557 | Built for subzero temperatures | Manual | Cloth | Four | Z | C |

License plate: FG3A4Z
Description: Built for desert heat
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-001/record_1/original/r1`, `framing-list-001/record_1/original/r2`, `framing-list-001/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-001/record_1/paraphrase/r1`, `framing-list-001/record_1/paraphrase/r2`, `framing-list-001/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-001/record_1/recorded/r1`, `framing-list-001/record_1/recorded/r2`, `framing-list-001/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-001/record_1/bare/r1`, `framing-list-001/record_1/bare/r2`, `framing-list-001/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: B

```

## framing-list-007/record_2

### Direct baseline — exact user message

Task: `framing-list-007/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F4422Z | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FUJDDS | Built for desert heat | Automatic | Cloth | Two | Z | A |
| FCE93X | Designed for humid summers | Manual | Vinyl | Four | Y | A |
| F5HARY | Operates on polar ice | Automatic | Cloth | Two | Z | C |
| FEUQ2E | Equipped with snow tracks | Automatic | Cloth | Four | X | C |
| FMYNCJ | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FC3X7M | Built for subzero temperatures | Automatic | Vinyl | Two | Y | B |
| FS5C52 | Equipped for hot sand | Manual | Vinyl | Four | X | A |
| FMEX34 | Used at an Arctic station | Manual | Vinyl | Four | X | C |
| FDP2U3 | Used at an equatorial station | Automatic | Cloth | Two | Z | C |

License plate: FDP2U3
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-007/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F4422Z | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FUJDDS | Built for desert heat | Automatic | Cloth | Two | Z | A |
| FCE93X | Designed for humid summers | Manual | Vinyl | Four | Y | A |
| F5HARY | Operates on polar ice | Automatic | Cloth | Two | Z | C |
| FEUQ2E | Equipped with snow tracks | Automatic | Cloth | Four | X | C |
| FMYNCJ | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FC3X7M | Built for subzero temperatures | Automatic | Vinyl | Two | Y | B |
| FS5C52 | Equipped for hot sand | Manual | Vinyl | Four | X | A |
| FMEX34 | Used at an Arctic station | Manual | Vinyl | Four | X | C |
| FDP2U3 | Used at an equatorial station | Automatic | Cloth | Two | Z | C |

License plate: FDP2U3
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-007/record_2/original/r1`, `framing-list-007/record_2/original/r2`, `framing-list-007/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-007/record_2/paraphrase/r1`, `framing-list-007/record_2/paraphrase/r2`, `framing-list-007/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-007/record_2/recorded/r1`, `framing-list-007/record_2/recorded/r2`, `framing-list-007/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-007/record_2/bare/r1`, `framing-list-007/record_2/bare/r2`, `framing-list-007/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C

```

## framing-list-003/record_1

### Direct baseline — exact user message

Task: `framing-list-003/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJWVEG | Operates on polar ice | Automatic | Cloth | Four | Y | B |
| FTD4K3 | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| FCSFFU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| FATTVN | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FPCFR7 | Equipped for hot sand | Automatic | Vinyl | Four | X | A |
| FRR5CS | Built for subzero temperatures | Manual | Vinyl | Two | X | B |
| FPWQ3R | Operates in tropical forests | Automatic | Cloth | Two | X | C |
| FN4MPT | Equipped with snow tracks | Automatic | Cloth | Two | Z | A |
| FWXN5P | Designed for frozen terrain | Automatic | Vinyl | Two | Y | B |
| FGB4R4 | Used at an Arctic station | Manual | Cloth | Two | Z | B |

License plate: FN4MPT
Description: Equipped with snow tracks
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-003/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJWVEG | Operates on polar ice | Automatic | Cloth | Four | Y | B |
| FTD4K3 | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| FCSFFU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| FATTVN | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FPCFR7 | Equipped for hot sand | Automatic | Vinyl | Four | X | A |
| FRR5CS | Built for subzero temperatures | Manual | Vinyl | Two | X | B |
| FPWQ3R | Operates in tropical forests | Automatic | Cloth | Two | X | C |
| FN4MPT | Equipped with snow tracks | Automatic | Cloth | Two | Z | A |
| FWXN5P | Designed for frozen terrain | Automatic | Vinyl | Two | Y | B |
| FGB4R4 | Used at an Arctic station | Manual | Cloth | Two | Z | B |

License plate: FN4MPT
Description: Equipped with snow tracks
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-003/record_1/original/r1`, `framing-list-003/record_1/original/r2`, `framing-list-003/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-003/record_1/paraphrase/r1`, `framing-list-003/record_1/paraphrase/r2`, `framing-list-003/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-003/record_1/recorded/r1`, `framing-list-003/record_1/recorded/r2`, `framing-list-003/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-003/record_1/bare/r1`, `framing-list-003/record_1/bare/r2`, `framing-list-003/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: A

```

## framing-list-021/record_2

### Direct baseline — exact user message

Task: `framing-list-021/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FPRFU9 | Equipped with snow tracks | Automatic | Cloth | Four | Y | B |
| FCHTCA | Designed for humid summers | Automatic | Cloth | Two | Y | A |
| FXS9D5 | Used at an equatorial station | Automatic | Cloth | Two | Z | C |
| FTZSJ7 | Used at an Arctic station | Manual | Vinyl | Two | Z | B |
| FQ44SP | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| FXR4W9 | Operates on polar ice | Manual | Vinyl | Four | Z | A |
| FX9962 | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| F3GY8N | Operates in tropical forests | Manual | Vinyl | Two | Z | C |
| FLH8ST | Designed for frozen terrain | Automatic | Vinyl | Two | X | A |
| F9D7XC | Built for desert heat | Automatic | Vinyl | Four | X | C |

License plate: FCHTCA
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-021/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FPRFU9 | Equipped with snow tracks | Automatic | Cloth | Four | Y | B |
| FCHTCA | Designed for humid summers | Automatic | Cloth | Two | Y | A |
| FXS9D5 | Used at an equatorial station | Automatic | Cloth | Two | Z | C |
| FTZSJ7 | Used at an Arctic station | Manual | Vinyl | Two | Z | B |
| FQ44SP | Equipped for hot sand | Manual | Vinyl | Two | Y | C |
| FXR4W9 | Operates on polar ice | Manual | Vinyl | Four | Z | A |
| FX9962 | Built for subzero temperatures | Manual | Cloth | Four | X | A |
| F3GY8N | Operates in tropical forests | Manual | Vinyl | Two | Z | C |
| FLH8ST | Designed for frozen terrain | Automatic | Vinyl | Two | X | A |
| F9D7XC | Built for desert heat | Automatic | Vinyl | Four | X | C |

License plate: FCHTCA
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-021/record_2/original/r1`, `framing-list-021/record_2/original/r2`, `framing-list-021/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-021/record_2/paraphrase/r1`, `framing-list-021/record_2/paraphrase/r2`, `framing-list-021/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-021/record_2/recorded/r1`, `framing-list-021/record_2/recorded/r2`, `framing-list-021/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-021/record_2/bare/r1`, `framing-list-021/record_2/bare/r2`, `framing-list-021/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FCHTCA.

1. **Given Data for FCHTCA:**
   - License plate: FCHTCA
   - Description: Designed for humid summers
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Y
   - Verified class: A

```

## framing-list-015/record_1

### Direct baseline — exact user message

Task: `framing-list-015/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FD82ZX | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| FWES2L | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| F38XT3 | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FJRGUP | Built for desert heat | Manual | Cloth | Two | Y | B |
| FYCE72 | Used at an Arctic station | Manual | Vinyl | Four | Y | A |
| FRHXAR | Equipped with snow tracks | Manual | Vinyl | Two | Z | C |
| FU6QRW | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQU8LM | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| FXMS4T | Used at an equatorial station | Manual | Vinyl | Two | Z | B |
| FRWJH7 | Designed for frozen terrain | Manual | Cloth | Two | Z | C |

License plate: FYCE72
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-015/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FD82ZX | Built for subzero temperatures | Manual | Cloth | Four | X | C |
| FWES2L | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| F38XT3 | Operates on polar ice | Automatic | Vinyl | Two | X | C |
| FJRGUP | Built for desert heat | Manual | Cloth | Two | Y | B |
| FYCE72 | Used at an Arctic station | Manual | Vinyl | Four | Y | A |
| FRHXAR | Equipped with snow tracks | Manual | Vinyl | Two | Z | C |
| FU6QRW | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQU8LM | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| FXMS4T | Used at an equatorial station | Manual | Vinyl | Two | Z | B |
| FRWJH7 | Designed for frozen terrain | Manual | Cloth | Two | Z | C |

License plate: FYCE72
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-015/record_1/original/r1`, `framing-list-015/record_1/original/r2`, `framing-list-015/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-015/record_1/paraphrase/r1`, `framing-list-015/record_1/paraphrase/r2`, `framing-list-015/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-015/record_1/recorded/r1`, `framing-list-015/record_1/recorded/r2`, `framing-list-015/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-015/record_1/bare/r1`, `framing-list-015/record_1/bare/r2`, `framing-list-015/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FYCE72.

1. **Given Data for FYCE72:**
   - License plate: FYCE72
   - Description: Used at an Arctic station
   - Transmission: Manual
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: A

```

## framing-list-004/record_2

### Direct baseline — exact user message

Task: `framing-list-004/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJHHDV | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| F5Z5P8 | Equipped for hot sand | Manual | Cloth | Four | Y | C |
| FL964Y | Operates on polar ice | Manual | Vinyl | Two | X | B |
| FNZG7A | Used at an equatorial station | Automatic | Vinyl | Two | Z | A |
| FUG4SP | Equipped with snow tracks | Automatic | Vinyl | Four | Y | B |
| FLX52P | Designed for humid summers | Manual | Cloth | Four | Z | C |
| FNDG73 | Used at an Arctic station | Automatic | Cloth | Four | Z | B |
| F4EVEU | Built for desert heat | Automatic | Cloth | Two | X | C |
| F9CA4N | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| FDT8J5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |

License plate: FNZG7A
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-004/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJHHDV | Designed for frozen terrain | Manual | Vinyl | Four | Y | A |
| F5Z5P8 | Equipped for hot sand | Manual | Cloth | Four | Y | C |
| FL964Y | Operates on polar ice | Manual | Vinyl | Two | X | B |
| FNZG7A | Used at an equatorial station | Automatic | Vinyl | Two | Z | A |
| FUG4SP | Equipped with snow tracks | Automatic | Vinyl | Four | Y | B |
| FLX52P | Designed for humid summers | Manual | Cloth | Four | Z | C |
| FNDG73 | Used at an Arctic station | Automatic | Cloth | Four | Z | B |
| F4EVEU | Built for desert heat | Automatic | Cloth | Two | X | C |
| F9CA4N | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| FDT8J5 | Built for subzero temperatures | Automatic | Vinyl | Four | Y | A |

License plate: FNZG7A
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-004/record_2/original/r1`, `framing-list-004/record_2/original/r2`, `framing-list-004/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-004/record_2/paraphrase/r1`, `framing-list-004/record_2/paraphrase/r2`, `framing-list-004/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-004/record_2/recorded/r1`, `framing-list-004/record_2/recorded/r2`, `framing-list-004/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-004/record_2/bare/r1`, `framing-list-004/record_2/bare/r2`, `framing-list-004/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNZG7A.

1. **Given Data for FNZG7A:**
   - License plate: FNZG7A
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Two
   - Audit marker: Z
   - Verified class: A

```

## framing-list-007/record_1

### Direct baseline — exact user message

Task: `framing-list-007/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F4422Z | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FUJDDS | Built for desert heat | Automatic | Cloth | Two | Z | A |
| FCE93X | Designed for humid summers | Manual | Vinyl | Four | Y | A |
| F5HARY | Operates on polar ice | Automatic | Cloth | Two | Z | C |
| FEUQ2E | Equipped with snow tracks | Automatic | Cloth | Four | X | C |
| FMYNCJ | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FC3X7M | Built for subzero temperatures | Automatic | Vinyl | Two | Y | B |
| FS5C52 | Equipped for hot sand | Manual | Vinyl | Four | X | A |
| FMEX34 | Used at an Arctic station | Manual | Vinyl | Four | X | C |
| FDP2U3 | Used at an equatorial station | Automatic | Cloth | Two | Z | B |

License plate: FDP2U3
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-007/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| F4422Z | Designed for frozen terrain | Manual | Vinyl | Two | Z | B |
| FUJDDS | Built for desert heat | Automatic | Cloth | Two | Z | A |
| FCE93X | Designed for humid summers | Manual | Vinyl | Four | Y | A |
| F5HARY | Operates on polar ice | Automatic | Cloth | Two | Z | C |
| FEUQ2E | Equipped with snow tracks | Automatic | Cloth | Four | X | C |
| FMYNCJ | Operates in tropical forests | Manual | Vinyl | Two | Y | A |
| FC3X7M | Built for subzero temperatures | Automatic | Vinyl | Two | Y | B |
| FS5C52 | Equipped for hot sand | Manual | Vinyl | Four | X | A |
| FMEX34 | Used at an Arctic station | Manual | Vinyl | Four | X | C |
| FDP2U3 | Used at an equatorial station | Automatic | Cloth | Two | Z | B |

License plate: FDP2U3
Description: Used at an equatorial station
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-007/record_1/original/r1`, `framing-list-007/record_1/original/r2`, `framing-list-007/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-007/record_1/paraphrase/r1`, `framing-list-007/record_1/paraphrase/r2`, `framing-list-007/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-007/record_1/recorded/r1`, `framing-list-007/record_1/recorded/r2`, `framing-list-007/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-007/record_1/bare/r1`, `framing-list-007/record_1/bare/r2`, `framing-list-007/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FDP2U3.

1. **Given Data for FDP2U3:**
   - License plate: FDP2U3
   - Description: Used at an equatorial station
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: B

```

## framing-list-013/record_1

### Direct baseline — exact user message

Task: `framing-list-013/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FZHVV2 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| FKWRBR | Used at an Arctic station | Manual | Cloth | Two | Y | C |
| FH6SNJ | Equipped with snow tracks | Manual | Cloth | Four | Y | B |
| FRYBTP | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |
| FNCN8U | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQMQPB | Operates in tropical forests | Automatic | Cloth | Four | X | A |
| F9K6NK | Used at an equatorial station | Manual | Cloth | Two | Z | A |
| FGZ4Z7 | Equipped for hot sand | Manual | Vinyl | Two | X | B |
| F3YR26 | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FQEMNP | Built for desert heat | Manual | Cloth | Four | Y | B |

License plate: FH6SNJ
Description: Equipped with snow tracks
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-013/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FZHVV2 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| FKWRBR | Used at an Arctic station | Manual | Cloth | Two | Y | C |
| FH6SNJ | Equipped with snow tracks | Manual | Cloth | Four | Y | B |
| FRYBTP | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |
| FNCN8U | Designed for humid summers | Manual | Cloth | Four | X | A |
| FQMQPB | Operates in tropical forests | Automatic | Cloth | Four | X | A |
| F9K6NK | Used at an equatorial station | Manual | Cloth | Two | Z | A |
| FGZ4Z7 | Equipped for hot sand | Manual | Vinyl | Two | X | B |
| F3YR26 | Built for subzero temperatures | Manual | Vinyl | Four | Y | C |
| FQEMNP | Built for desert heat | Manual | Cloth | Four | Y | B |

License plate: FH6SNJ
Description: Equipped with snow tracks
Transmission: Manual
Seat cover: Cloth
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-013/record_1/original/r1`, `framing-list-013/record_1/original/r2`, `framing-list-013/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-013/record_1/paraphrase/r1`, `framing-list-013/record_1/paraphrase/r2`, `framing-list-013/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-013/record_1/recorded/r1`, `framing-list-013/record_1/recorded/r2`, `framing-list-013/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-013/record_1/bare/r1`, `framing-list-013/record_1/bare/r2`, `framing-list-013/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FH6SNJ.

1. **Given Data for FH6SNJ:**
   - License plate: FH6SNJ
   - Description: Equipped with snow tracks
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Four
   - Audit marker: Y
   - Verified class: B

```

## framing-list-000/record_1

### Direct baseline — exact user message

Task: `framing-list-000/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FR7W4R | Used at an Arctic station | Automatic | Cloth | Two | Z | A |
| FW3A6P | Designed for humid summers | Manual | Cloth | Four | Y | C |
| FNNQFM | Designed for frozen terrain | Automatic | Cloth | Two | X | B |
| FG96G2 | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| F88GF2 | Equipped for hot sand | Automatic | Cloth | Two | Z | B |
| FNRUCL | Built for desert heat | Automatic | Cloth | Two | X | B |
| F6XRJL | Operates on polar ice | Manual | Vinyl | Four | Y | A |
| FJF58V | Built for subzero temperatures | Automatic | Vinyl | Four | Z | A |
| F57GWA | Used at an equatorial station | Manual | Cloth | Two | Y | C |
| FJ92EW | Equipped with snow tracks | Manual | Cloth | Four | X | A |

License plate: FNNQFM
Description: Designed for frozen terrain
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-000/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FR7W4R | Used at an Arctic station | Automatic | Cloth | Two | Z | A |
| FW3A6P | Designed for humid summers | Manual | Cloth | Four | Y | C |
| FNNQFM | Designed for frozen terrain | Automatic | Cloth | Two | X | B |
| FG96G2 | Operates in tropical forests | Automatic | Cloth | Two | Y | B |
| F88GF2 | Equipped for hot sand | Automatic | Cloth | Two | Z | B |
| FNRUCL | Built for desert heat | Automatic | Cloth | Two | X | B |
| F6XRJL | Operates on polar ice | Manual | Vinyl | Four | Y | A |
| FJF58V | Built for subzero temperatures | Automatic | Vinyl | Four | Z | A |
| F57GWA | Used at an equatorial station | Manual | Cloth | Two | Y | C |
| FJ92EW | Equipped with snow tracks | Manual | Cloth | Four | X | A |

License plate: FNNQFM
Description: Designed for frozen terrain
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-000/record_1/original/r1`, `framing-list-000/record_1/original/r2`, `framing-list-000/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: B (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-000/record_1/paraphrase/r1`, `framing-list-000/record_1/paraphrase/r2`, `framing-list-000/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: B (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-000/record_1/recorded/r1`, `framing-list-000/record_1/recorded/r2`, `framing-list-000/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: B (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-000/record_1/bare/r1`, `framing-list-000/record_1/bare/r2`, `framing-list-000/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNNQFM.

1. **Given Data for FNNQFM:**
   - License plate: FNNQFM
   - Description: Designed for frozen terrain
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: B

```

## framing-list-003/record_2

### Direct baseline — exact user message

Task: `framing-list-003/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJWVEG | Operates on polar ice | Automatic | Cloth | Four | Y | B |
| FTD4K3 | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| FCSFFU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| FATTVN | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FPCFR7 | Equipped for hot sand | Automatic | Vinyl | Four | X | A |
| FRR5CS | Built for subzero temperatures | Manual | Vinyl | Two | X | B |
| FPWQ3R | Operates in tropical forests | Automatic | Cloth | Two | X | C |
| FN4MPT | Equipped with snow tracks | Automatic | Cloth | Two | Z | C |
| FWXN5P | Designed for frozen terrain | Automatic | Vinyl | Two | Y | B |
| FGB4R4 | Used at an Arctic station | Manual | Cloth | Two | Z | B |

License plate: FN4MPT
Description: Equipped with snow tracks
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-003/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FJWVEG | Operates on polar ice | Automatic | Cloth | Four | Y | B |
| FTD4K3 | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| FCSFFU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| FATTVN | Built for desert heat | Automatic | Vinyl | Two | Y | C |
| FPCFR7 | Equipped for hot sand | Automatic | Vinyl | Four | X | A |
| FRR5CS | Built for subzero temperatures | Manual | Vinyl | Two | X | B |
| FPWQ3R | Operates in tropical forests | Automatic | Cloth | Two | X | C |
| FN4MPT | Equipped with snow tracks | Automatic | Cloth | Two | Z | C |
| FWXN5P | Designed for frozen terrain | Automatic | Vinyl | Two | Y | B |
| FGB4R4 | Used at an Arctic station | Manual | Cloth | Two | Z | B |

License plate: FN4MPT
Description: Equipped with snow tracks
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-003/record_2/original/r1`, `framing-list-003/record_2/original/r2`, `framing-list-003/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-003/record_2/paraphrase/r1`, `framing-list-003/record_2/paraphrase/r2`, `framing-list-003/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-003/record_2/recorded/r1`, `framing-list-003/record_2/recorded/r2`, `framing-list-003/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-003/record_2/bare/r1`, `framing-list-003/record_2/bare/r2`, `framing-list-003/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FN4MPT.

1. **Given Data for FN4MPT:**
   - License plate: FN4MPT
   - Description: Equipped with snow tracks
   - Transmission: Automatic
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: Z
   - Verified class: C

```

## framing-list-002/record_2

### Direct baseline — exact user message

Task: `framing-list-002/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FA56N6 | Designed for frozen terrain | Manual | Cloth | Four | Y | C |
| FC5JAH | Built for subzero temperatures | Automatic | Vinyl | Two | X | A |
| FU3ABT | Used at an Arctic station | Automatic | Vinyl | Two | Z | A |
| FFG7ZH | Operates on polar ice | Automatic | Cloth | Four | Z | C |
| FPQJ38 | Equipped for hot sand | Automatic | Cloth | Two | Y | B |
| FNAWYJ | Used at an equatorial station | Manual | Cloth | Two | X | A |
| FCC58B | Built for desert heat | Automatic | Vinyl | Four | X | B |
| FRJ3L4 | Equipped with snow tracks | Manual | Vinyl | Four | Y | C |
| F3JKHT | Operates in tropical forests | Manual | Cloth | Four | Z | B |
| FXB93G | Designed for humid summers | Automatic | Cloth | Four | Y | B |

License plate: FNAWYJ
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-002/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FA56N6 | Designed for frozen terrain | Manual | Cloth | Four | Y | C |
| FC5JAH | Built for subzero temperatures | Automatic | Vinyl | Two | X | A |
| FU3ABT | Used at an Arctic station | Automatic | Vinyl | Two | Z | A |
| FFG7ZH | Operates on polar ice | Automatic | Cloth | Four | Z | C |
| FPQJ38 | Equipped for hot sand | Automatic | Cloth | Two | Y | B |
| FNAWYJ | Used at an equatorial station | Manual | Cloth | Two | X | A |
| FCC58B | Built for desert heat | Automatic | Vinyl | Four | X | B |
| FRJ3L4 | Equipped with snow tracks | Manual | Vinyl | Four | Y | C |
| F3JKHT | Operates in tropical forests | Manual | Cloth | Four | Z | B |
| FXB93G | Designed for humid summers | Automatic | Cloth | Four | Y | B |

License plate: FNAWYJ
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-002/record_2/original/r1`, `framing-list-002/record_2/original/r2`, `framing-list-002/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-002/record_2/paraphrase/r1`, `framing-list-002/record_2/paraphrase/r2`, `framing-list-002/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-002/record_2/recorded/r1`, `framing-list-002/record_2/recorded/r2`, `framing-list-002/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: A (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-002/record_2/bare/r1`, `framing-list-002/record_2/bare/r2`, `framing-list-002/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: A

```

## framing-list-002/record_1

### Direct baseline — exact user message

Task: `framing-list-002/record_1/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FA56N6 | Designed for frozen terrain | Manual | Cloth | Four | Y | C |
| FC5JAH | Built for subzero temperatures | Automatic | Vinyl | Two | X | A |
| FU3ABT | Used at an Arctic station | Automatic | Vinyl | Two | Z | A |
| FFG7ZH | Operates on polar ice | Automatic | Cloth | Four | Z | C |
| FPQJ38 | Equipped for hot sand | Automatic | Cloth | Two | Y | B |
| FNAWYJ | Used at an equatorial station | Manual | Cloth | Two | X | C |
| FCC58B | Built for desert heat | Automatic | Vinyl | Four | X | B |
| FRJ3L4 | Equipped with snow tracks | Manual | Vinyl | Four | Y | C |
| F3JKHT | Operates in tropical forests | Manual | Cloth | Four | Z | B |
| FXB93G | Designed for humid summers | Automatic | Cloth | Four | Y | B |

License plate: FNAWYJ
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-002/record_1/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FA56N6 | Designed for frozen terrain | Manual | Cloth | Four | Y | C |
| FC5JAH | Built for subzero temperatures | Automatic | Vinyl | Two | X | A |
| FU3ABT | Used at an Arctic station | Automatic | Vinyl | Two | Z | A |
| FFG7ZH | Operates on polar ice | Automatic | Cloth | Four | Z | C |
| FPQJ38 | Equipped for hot sand | Automatic | Cloth | Two | Y | B |
| FNAWYJ | Used at an equatorial station | Manual | Cloth | Two | X | C |
| FCC58B | Built for desert heat | Automatic | Vinyl | Four | X | B |
| FRJ3L4 | Equipped with snow tracks | Manual | Vinyl | Four | Y | C |
| F3JKHT | Operates in tropical forests | Manual | Cloth | Four | Z | B |
| FXB93G | Designed for humid summers | Automatic | Cloth | Four | Y | B |

License plate: FNAWYJ
Description: Used at an equatorial station
Transmission: Manual
Seat cover: Cloth
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-002/record_1/original/r1`, `framing-list-002/record_1/original/r2`, `framing-list-002/record_1/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-002/record_1/paraphrase/r1`, `framing-list-002/record_1/paraphrase/r2`, `framing-list-002/record_1/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-002/record_1/recorded/r1`, `framing-list-002/record_1/recorded/r2`, `framing-list-002/record_1/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-002/record_1/bare/r1`, `framing-list-002/record_1/bare/r2`, `framing-list-002/record_1/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FNAWYJ.

1. **Given Data for FNAWYJ:**
   - License plate: FNAWYJ
   - Description: Used at an equatorial station
   - Transmission: Manual
   - Seat cover: Cloth
   - Doors: Two
   - Audit marker: X
   - Verified class: C

```

## framing-list-001/record_2

### Direct baseline — exact user message

Task: `framing-list-001/record_2/direct`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FY6DHG | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| FFTC6L | Operates in tropical forests | Manual | Vinyl | Four | X | A |
| F62Z8M | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| FG3A4Z | Built for desert heat | Automatic | Vinyl | Four | Y | C |
| FBCVQW | Equipped with snow tracks | Automatic | Cloth | Two | X | C |
| FSBGXU | Operates on polar ice | Automatic | Cloth | Four | Z | B |
| FSY9NC | Used at an Arctic station | Automatic | Cloth | Two | Z | B |
| FKPQB2 | Equipped for hot sand | Automatic | Vinyl | Four | Z | A |
| FYK2TS | Designed for humid summers | Manual | Cloth | Four | Y | A |
| FWZ557 | Built for subzero temperatures | Manual | Cloth | Four | Z | C |

License plate: FG3A4Z
Description: Built for desert heat
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

### Visible baseline — exact user message

Task: `framing-list-001/record_2/visible`

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FY6DHG | Used at an equatorial station | Automatic | Cloth | Two | Y | A |
| FFTC6L | Operates in tropical forests | Manual | Vinyl | Four | X | A |
| F62Z8M | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| FG3A4Z | Built for desert heat | Automatic | Vinyl | Four | Y | C |
| FBCVQW | Equipped with snow tracks | Automatic | Cloth | Two | X | C |
| FSBGXU | Operates on polar ice | Automatic | Cloth | Four | Z | B |
| FSY9NC | Used at an Arctic station | Automatic | Cloth | Two | Z | B |
| FKPQB2 | Equipped for hot sand | Automatic | Vinyl | Four | Z | A |
| FYK2TS | Designed for humid summers | Manual | Cloth | Four | Y | A |
| FWZ557 | Built for subzero temperatures | Manual | Cloth | Four | Z | C |

License plate: FG3A4Z
Description: Built for desert heat
Transmission: Automatic
Seat cover: Vinyl
Doors: Four
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

### Intervention requests

Every arm below uses the exact visible-baseline user message above. Append the indicated assistant prefix with prefix=true; regenerate everything afterward. There is no additional user instruction and no saved explanation suffix.

#### original — observed wording

Tasks: `framing-list-001/record_2/original/r1`, `framing-list-001/record_2/original/r2`, `framing-list-001/record_2/original/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: C (This is the value we are trying to confirm or predict.)

```

#### paraphrase

Tasks: `framing-list-001/record_2/paraphrase/r1`, `framing-list-001/record_2/paraphrase/r2`, `framing-list-001/record_2/paraphrase/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: C (This is the value we are trying to verify or infer.)

```

#### recorded

Tasks: `framing-list-001/record_2/recorded/r1`, `framing-list-001/record_2/recorded/r2`, `framing-list-001/record_2/recorded/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: C (This is the value already recorded for this vehicle.)

```

#### bare

Tasks: `framing-list-001/record_2/bare/r1`, `framing-list-001/record_2/bare/r2`, `framing-list-001/record_2/bare/r3`

Exact assistant prefix (ends with two newline characters):

```text
Let's analyze the given records step by step to determine the class of the vehicle with the license plate FG3A4Z.

1. **Given Data for FG3A4Z:**
   - License plate: FG3A4Z
   - Description: Built for desert heat
   - Transmission: Automatic
   - Seat cover: Vinyl
   - Doors: Four
   - Audit marker: Y
   - Verified class: C

```

