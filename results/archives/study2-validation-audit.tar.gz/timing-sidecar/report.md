# Qwen timing (no automatic next stage)

Status: **INCOMPLETE**. Mock timings are not live performance evidence.

## Completed timing observations

| Operation / model / measurement | N | Mean seconds | Median | Range |
|---|---:|---:|---:|---|
| file_verification/LIVE | 1 | 73.37736667878926 | 73.37736667878926 | [73.37736667878926, 73.37736667878926] |
| tokenizer_initialization/LIVE | 1 | 0.4017016068100929 | 0.4017016068100929 | [0.4017016068100929, 0.4017016068100929] |
| model_loading_cpu/LIVE | 1 | 1.895445203408599 | 1.895445203408599 | [1.895445203408599, 1.895445203408599] |
| device_transfer/LIVE | 1 | 11.145431915298104 | 11.145431915298104 | [11.145431915298104, 11.145431915298104] |
| backend_initialization_total/LIVE | 1 | 87.06641985848546 | 87.06641985848546 | [87.06641985848546, 87.06641985848546] |
| technical_validation/LIVE | 15 | 8.790048342819015 | 8.910751992836595 | [6.757134484127164, 11.4133603554219] |

## Remaining work

Serial scenarios only. Unobserved stages remain **NOT YET MEASURED**; they are never zero-duration estimates.

| Operation | Remaining count scenario | Estimated seconds | Status |
|---|---|---|---|
| original_generation | [48, 48] | None | NOT_YET_MEASURED |
| intervention_reference | [0, 24] | None | NOT_YET_MEASURED |
| intervention_replay | [0, 24] | None | NOT_YET_MEASURED |
| edited_continuation | [0, 96] | None | NOT_YET_MEASURED |
| candidate_sequence_scoring_interventions | [0, 288] | None | NOT_YET_MEASURED |
| unchanged_replay | [0, 96] | None | NOT_YET_MEASURED |
| candidate_sequence_scoring_fixed_2a | [0, 432] | None | NOT_YET_MEASURED |
| event_reference | [0, 48] | None | NOT_YET_MEASURED |
| event_validation | [0, 72] | None | NOT_YET_MEASURED |
| candidate_sequence_scoring_events | [0, 216] | None | NOT_YET_MEASURED |

The machine-readable JSON includes source identities, individual case states, all denominators, unknown-outcome bounds, rate assumptions, invocation versus cumulative timing, and billing limitations.

## Complete audit data

```json
{
  "status": "INCOMPLETE",
  "planned_originals": 48,
  "returned_originals": 0,
  "behavioral_calibration_available": false,
  "technical_validation": false,
  "timing_version": "study2-timing-sidecar-v1",
  "observations": {
    "file_verification/LIVE": {
      "observations": 1,
      "mean_seconds": 73.37736667878926,
      "median_seconds": 73.37736667878926,
      "range_seconds": [
        73.37736667878926,
        73.37736667878926
      ],
      "status": "MEASURED"
    },
    "tokenizer_initialization/LIVE": {
      "observations": 1,
      "mean_seconds": 0.4017016068100929,
      "median_seconds": 0.4017016068100929,
      "range_seconds": [
        0.4017016068100929,
        0.4017016068100929
      ],
      "status": "MEASURED"
    },
    "model_loading_cpu/LIVE": {
      "observations": 1,
      "mean_seconds": 1.895445203408599,
      "median_seconds": 1.895445203408599,
      "range_seconds": [
        1.895445203408599,
        1.895445203408599
      ],
      "status": "MEASURED"
    },
    "device_transfer/LIVE": {
      "observations": 1,
      "mean_seconds": 11.145431915298104,
      "median_seconds": 11.145431915298104,
      "range_seconds": [
        11.145431915298104,
        11.145431915298104
      ],
      "status": "MEASURED"
    },
    "backend_initialization_total/LIVE": {
      "observations": 1,
      "mean_seconds": 87.06641985848546,
      "median_seconds": 87.06641985848546,
      "range_seconds": [
        87.06641985848546,
        87.06641985848546
      ],
      "status": "MEASURED"
    },
    "technical_validation/LIVE": {
      "observations": 15,
      "mean_seconds": 8.790048342819015,
      "median_seconds": 8.910751992836595,
      "range_seconds": [
        6.757134484127164,
        11.4133603554219
      ],
      "status": "MEASURED"
    }
  },
  "this_invocation": {
    "version": "study2-timing-sidecar-v1",
    "plan_hash": "ed0dcd3253fa712741a2ffa3edafb049451a414ba9e66b2e99be71bee9373a83",
    "backend_hash": "a70f2f96ac0e0d1cecddd1ecd6740421597591481b9be47027dc2f5aec6d7985",
    "invocation": "cfb7acf9f87349da9d138cfe2bfacf3a",
    "started_utc": "2026-10-14T03:59:43.750899+00:00",
    "finished_utc": "2026-10-14T04:03:34.611929+00:00",
    "elapsed_seconds": 230.86104500852525,
    "status": "FAILED",
    "python": "3.12.3",
    "platform": "Linux-6.8.0-60-generic-x86_64-with-glibc2.39",
    "artifact_hash": "a62516c4bdf2519a841b3d24b265a33dae60d480d68071f60478f5f93dcdc58f"
  },
  "cumulative_input_tokens": 626,
  "cumulative_output_tokens": 1361,
  "cache_hits": 0,
  "failures": 1,
  "remaining_work": {
    "original_generation": {
      "remaining_count_scenario": [
        48,
        48
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "intervention_reference": {
      "remaining_count_scenario": [
        0,
        24
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "intervention_replay": {
      "remaining_count_scenario": [
        0,
        24
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "edited_continuation": {
      "remaining_count_scenario": [
        0,
        96
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "candidate_sequence_scoring_interventions": {
      "remaining_count_scenario": [
        0,
        288
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "unchanged_replay": {
      "planned_maximum": 96,
      "remaining_count_scenario": [
        0,
        96
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "candidate_sequence_scoring_fixed_2a": {
      "planned_maximum": 432,
      "remaining_count_scenario": [
        0,
        432
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "event_reference": {
      "remaining_count_scenario": [
        0,
        48
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "event_validation": {
      "remaining_count_scenario": [
        0,
        72
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "candidate_sequence_scoring_events": {
      "remaining_count_scenario": [
        0,
        216
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    }
  },
  "fixed_2a": {
    "status": "INCOMPLETE",
    "workload": {
      "basis": "CONDITIONAL_BEFORE_COLLECTION",
      "counts": {
        "unchanged_replay": {
          "planned_maximum": 96,
          "remaining_count_scenario": [
            0,
            96
          ]
        },
        "candidate_sequence_scoring_fixed_2a": {
          "planned_maximum": 432,
          "remaining_count_scenario": [
            0,
            432
          ]
        }
      }
    },
    "remaining_work": {
      "unchanged_replay": {
        "planned_maximum": 96,
        "remaining_count_scenario": [
          0,
          96
        ],
        "status": "NOT_YET_MEASURED",
        "seconds_scenario": null
      },
      "candidate_sequence_scoring_fixed_2a": {
        "planned_maximum": 432,
        "remaining_count_scenario": [
          0,
          432
        ],
        "status": "NOT_YET_MEASURED",
        "seconds_scenario": null
      }
    },
    "observations": {},
    "actual_timed_calls": {
      "unchanged_replay": {
        "attempted": 0,
        "returned": 0,
        "failed": 0
      },
      "candidate_sequence_scoring": {
        "attempted": 0,
        "returned": 0,
        "failed": 0
      }
    },
    "cache_hits": 0,
    "failures": 0,
    "input_tokens": 0,
    "output_tokens": 0,
    "this_invocation": null,
    "invocations": [],
    "hardware_software_precision": [],
    "full_study_total": null,
    "note": "Delegates the unchanged fixed-2A algorithm. Legacy caches reduce remaining work even without measured durations; unmeasured time is not zero."
  },
  "event_workloads": {
    "basis": "CONDITIONAL_SCENARIOS_NO_EVENT_DIRECTORIES_SUPPLIED",
    "plans": [],
    "conditional_scenarios": {
      "before_answer_only": {
        "event_reference": [
          0,
          24
        ]
      },
      "statement_only": {
        "event_reference": [
          0,
          24
        ]
      },
      "both_separate_directories": {
        "event_reference": [
          0,
          48
        ]
      }
    },
    "counts": {
      "event_reference": {
        "remaining_count_scenario": [
          0,
          48
        ]
      },
      "event_validation": {
        "remaining_count_scenario": [
          0,
          72
        ]
      },
      "candidate_sequence_scoring_events": {
        "remaining_count_scenario": [
          0,
          216
        ]
      }
    },
    "note": "Each event directory has its own reference; identical cuts are deduplicated only within that plan. This changes reference work, not the entire runtime."
  },
  "event_observations": {},
  "setup": {
    "download_setup": {
      "observations": 0,
      "mean_seconds": null,
      "median_seconds": null,
      "range_seconds": null,
      "status": "UNMEASURED"
    },
    "file_verification": {
      "observations": 1,
      "mean_seconds": 73.37736667878926,
      "median_seconds": 73.37736667878926,
      "range_seconds": [
        73.37736667878926,
        73.37736667878926
      ],
      "status": "MEASURED"
    },
    "tokenizer_initialization": {
      "observations": 1,
      "mean_seconds": 0.4017016068100929,
      "median_seconds": 0.4017016068100929,
      "range_seconds": [
        0.4017016068100929,
        0.4017016068100929
      ],
      "status": "MEASURED"
    },
    "model_loading_cpu": {
      "observations": 1,
      "mean_seconds": 1.895445203408599,
      "median_seconds": 1.895445203408599,
      "range_seconds": [
        1.895445203408599,
        1.895445203408599
      ],
      "status": "MEASURED"
    },
    "device_transfer": {
      "observations": 1,
      "mean_seconds": 11.145431915298104,
      "median_seconds": 11.145431915298104,
      "range_seconds": [
        11.145431915298104,
        11.145431915298104
      ],
      "status": "MEASURED"
    },
    "backend_initialization_total": {
      "observations": 1,
      "mean_seconds": 87.06641985848546,
      "median_seconds": 87.06641985848546,
      "range_seconds": [
        87.06641985848546,
        87.06641985848546
      ],
      "status": "MEASURED"
    }
  },
  "hardware_software_precision": [
    {
      "kind": "LOCAL_HF_TOKEN_IDS",
      "config": {
        "model_dir": "/workspace/models/Qwen3-32B/9216db5781bf21249d130ec9da846c4624c16137",
        "device": "cuda:0",
        "dtype": "bfloat16",
        "max_new_tokens": 512,
        "chat_template_kwargs": {
          "enable_thinking": false
        },
        "interface": "plain_visible_assistant",
        "readout_cues": [
          "\nANSWER:",
          "\nFinal answer:"
        ],
        "cue_check_checkpoints": [
          0,
          64
        ],
        "event_checkpoints": [
          "before_statement",
          "after_statement",
          "before_answer"
        ],
        "validation_tolerances": {
          "logit_atol": 0.0001,
          "logit_rtol": 0.0001,
          "prob_atol": 1e-05,
          "prob_rtol": 0.001,
          "max_total_variation": 0.0001
        },
        "calibration": {
          "min_direct_correct": 20,
          "min_matched_pattern_errors": 3,
          "min_error_worlds": 2
        },
        "model_profile": {
          "repo_id": "Qwen/Qwen3-32B",
          "revision": "9216db5781bf21249d130ec9da846c4624c16137",
          "tokenizer_revision": "9216db5781bf21249d130ec9da846c4624c16137"
        }
      },
      "files": {
        "config.json": "97e295b63283935788fac5e4f8860862a56d4089538cafc93f0431f2ebe483bb",
        "generation_config.json": "2325da0f15bb848e018c5ae071b7943332e9f871d6b60e2ed22ca97d4cb993d2",
        "tokenizer_config.json": "d5d09f07b48c3086c508b30d1c9114bd1189145b74e982a265350c923acd8101",
        "tokenizer.json": "aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4",
        "merges.txt": "8831e4f1a044471340f7c0a83d7bd71306a5b867e95fd870f74d0c5308a904d5",
        "vocab.json": "ca10d7e9fb3ed18575dd1e277a2579c16d108e32f27439684afa0e10b1440910",
        "model.safetensors.index.json": "bed42c6c55274bc08a1f616bceb3bcb84b3f02cb6584c573bd18c6519291ecd0",
        "model-00001-of-00017.safetensors": "52562b2ff97b61764260273e71bf5b4cf8a66f569399398f26dec0300fcf1316",
        "model-00002-of-00017.safetensors": "e26764b2c6878e3fb7198895fa833ec62838d84a19665e6abfbae43c6daf02b3",
        "model-00003-of-00017.safetensors": "6c5ba7bed9c52bc121e75cbe8a7be46936d0006cc80f42a6d5886ed40b4c2a62",
        "model-00004-of-00017.safetensors": "f736f6ac4d8c30866107fb1185a05b3c3cfce9717720082f466fa44e691bcec8",
        "model-00005-of-00017.safetensors": "a52ed375c083209c54d42ac510afeb1fbb5af4f193be2dc7d103f665a0f212d3",
        "model-00006-of-00017.safetensors": "37fae28990b0e4a70228549d040c0393e87bee3820d59e58e47844974d8dff5b",
        "model-00007-of-00017.safetensors": "37776006aeaba29eca8bc73b2b963fe3477e1c2e3f6a27cb9527be75b905e1bf",
        "model-00008-of-00017.safetensors": "73e74e9129674fe330948005075d70ab4fa0b92b68fb220c5a693f9cea553730",
        "model-00009-of-00017.safetensors": "a044b3602a01bd8ea62ff51badf9cc038ab1d73d97399480e6a55b4c86fa7fa6",
        "model-00010-of-00017.safetensors": "9966612ba7ecfc2cd2e592fb95224b86d743271ff88e172cc272a4b26382aa75",
        "model-00011-of-00017.safetensors": "e2a058a0ac7d4b992b731c29221ecfb4b76b8a48d9004d0e8a62ba44f699845c",
        "model-00012-of-00017.safetensors": "58a1aa89093fea07325f787072a468e3482a470ff4b7fe5ead5f749683907c40",
        "model-00013-of-00017.safetensors": "35f3381bab31a23370c37d922290aeecdf603418336058fb86fe42d8f51ac40c",
        "model-00014-of-00017.safetensors": "8713b062ddc178acf5917610b7f4b64eede833b2ea4aa37bd562dcf2f3a3339d",
        "model-00015-of-00017.safetensors": "bec439d23931821a236d8f62fa79deecf5551bd25602278aa2ae0ce432b378cf",
        "model-00016-of-00017.safetensors": "e569139fadd61fe7c8f9eb1c976d9a627cae48c57ddf228cfbd0593c59c64ff7",
        "model-00017-of-00017.safetensors": "1f47c318fcd7797c0f85b4233cb754438b10e795b8bc874889090c416a94bd38"
      },
      "torch": "2.7.1+cu126",
      "transformers": "4.51.3",
      "tokenizers": "0.21.1",
      "python": "3.12.3",
      "device": "cuda:0",
      "dtype": "torch.bfloat16",
      "hardware": "NVIDIA H100 PCIe",
      "cuda": "12.6",
      "cudnn": 90501,
      "chat_template": "{%- if tools %}\n    {{- '<|im_start|>system\\n' }}\n    {%- if messages[0].role == 'system' %}\n        {{- messages[0].content + '\\n\\n' }}\n    {%- endif %}\n    {{- \"# Tools\\n\\nYou may call one or more functions to assist with the user query.\\n\\nYou are provided with function signatures within <tools></tools> XML tags:\\n<tools>\" }}\n    {%- for tool in tools %}\n        {{- \"\\n\" }}\n        {{- tool | tojson }}\n    {%- endfor %}\n    {{- \"\\n</tools>\\n\\nFor each function call, return a json object with function name and arguments within <tool_call></tool_call> XML tags:\\n<tool_call>\\n{\\\"name\\\": <function-name>, \\\"arguments\\\": <args-json-object>}\\n</tool_call><|im_end|>\\n\" }}\n{%- else %}\n    {%- if messages[0].role == 'system' %}\n        {{- '<|im_start|>system\\n' + messages[0].content + '<|im_end|>\\n' }}\n    {%- endif %}\n{%- endif %}\n{%- set ns = namespace(multi_step_tool=true, last_query_index=messages|length - 1) %}\n{%- for message in messages[::-1] %}\n    {%- set index = (messages|length - 1) - loop.index0 %}\n    {%- if ns.multi_step_tool and message.role == \"user\" and message.content is string and not(message.content.startswith('<tool_response>') and message.content.endswith('</tool_response>')) %}\n        {%- set ns.multi_step_tool = false %}\n        {%- set ns.last_query_index = index %}\n    {%- endif %}\n{%- endfor %}\n{%- for message in messages %}\n    {%- if message.content is string %}\n        {%- set content = message.content %}\n    {%- else %}\n        {%- set content = '' %}\n    {%- endif %}\n    {%- if (message.role == \"user\") or (message.role == \"system\" and not loop.first) %}\n        {{- '<|im_start|>' + message.role + '\\n' + content + '<|im_end|>' + '\\n' }}\n    {%- elif message.role == \"assistant\" %}\n        {%- set reasoning_content = '' %}\n        {%- if message.reasoning_content is string %}\n            {%- set reasoning_content = message.reasoning_content %}\n        {%- else %}\n            {%- if '</think>' in content %}\n                {%- set reasoning_content = content.split('</think>')[0].rstrip('\\n').split('<think>')[-1].lstrip('\\n') %}\n                {%- set content = content.split('</think>')[-1].lstrip('\\n') %}\n            {%- endif %}\n        {%- endif %}\n        {%- if loop.index0 > ns.last_query_index %}\n            {%- if loop.last or (not loop.last and reasoning_content) %}\n                {{- '<|im_start|>' + message.role + '\\n<think>\\n' + reasoning_content.strip('\\n') + '\\n</think>\\n\\n' + content.lstrip('\\n') }}\n            {%- else %}\n                {{- '<|im_start|>' + message.role + '\\n' + content }}\n            {%- endif %}\n        {%- else %}\n            {{- '<|im_start|>' + message.role + '\\n' + content }}\n        {%- endif %}\n        {%- if message.tool_calls %}\n            {%- for tool_call in message.tool_calls %}\n                {%- if (loop.first and content) or (not loop.first) %}\n                    {{- '\\n' }}\n                {%- endif %}\n                {%- if tool_call.function %}\n                    {%- set tool_call = tool_call.function %}\n                {%- endif %}\n                {{- '<tool_call>\\n{\"name\": \"' }}\n                {{- tool_call.name }}\n                {{- '\", \"arguments\": ' }}\n                {%- if tool_call.arguments is string %}\n                    {{- tool_call.arguments }}\n                {%- else %}\n                    {{- tool_call.arguments | tojson }}\n                {%- endif %}\n                {{- '}\\n</tool_call>' }}\n            {%- endfor %}\n        {%- endif %}\n        {{- '<|im_end|>\\n' }}\n    {%- elif message.role == \"tool\" %}\n        {%- if loop.first or (messages[loop.index0 - 1].role != \"tool\") %}\n            {{- '<|im_start|>user' }}\n        {%- endif %}\n        {{- '\\n<tool_response>\\n' }}\n        {{- content }}\n        {{- '\\n</tool_response>' }}\n        {%- if loop.last or (messages[loop.index0 + 1].role != \"tool\") %}\n            {{- '<|im_end|>\\n' }}\n        {%- endif %}\n    {%- endif %}\n{%- endfor %}\n{%- if add_generation_prompt %}\n    {{- '<|im_start|>assistant\\n' }}\n    {%- if enable_thinking is defined and enable_thinking is false %}\n        {{- '<think>\\n\\n</think>\\n\\n' }}\n    {%- endif %}\n{%- endif %}",
      "special_ids": [
        151643,
        151644,
        151645,
        151646,
        151647,
        151648,
        151649,
        151650,
        151651,
        151652,
        151653,
        151654,
        151655,
        151656
      ],
      "generation": {
        "max_length": 20,
        "max_new_tokens": null,
        "min_length": 0,
        "min_new_tokens": null,
        "early_stopping": false,
        "max_time": null,
        "stop_strings": null,
        "do_sample": false,
        "num_beams": 1,
        "num_beam_groups": 1,
        "penalty_alpha": null,
        "dola_layers": null,
        "use_cache": true,
        "cache_implementation": null,
        "cache_config": null,
        "return_legacy_cache": null,
        "prefill_chunk_size": null,
        "temperature": 1.0,
        "top_k": 50,
        "top_p": 1.0,
        "min_p": null,
        "typical_p": 1.0,
        "epsilon_cutoff": 0.0,
        "eta_cutoff": 0.0,
        "diversity_penalty": 0.0,
        "repetition_penalty": 1.0,
        "encoder_repetition_penalty": 1.0,
        "length_penalty": 1.0,
        "no_repeat_ngram_size": 0,
        "bad_words_ids": null,
        "force_words_ids": null,
        "renormalize_logits": false,
        "constraints": null,
        "forced_bos_token_id": null,
        "forced_eos_token_id": null,
        "remove_invalid_values": false,
        "exponential_decay_length_penalty": null,
        "suppress_tokens": null,
        "begin_suppress_tokens": null,
        "forced_decoder_ids": null,
        "sequence_bias": null,
        "token_healing": false,
        "guidance_scale": null,
        "low_memory": null,
        "watermarking_config": null,
        "num_return_sequences": 1,
        "output_attentions": false,
        "output_hidden_states": false,
        "output_scores": false,
        "output_logits": null,
        "return_dict_in_generate": false,
        "pad_token_id": 151643,
        "bos_token_id": null,
        "eos_token_id": [
          151645,
          151643
        ],
        "encoder_no_repeat_ngram_size": 0,
        "decoder_start_token_id": null,
        "is_assistant": false,
        "num_assistant_tokens": 20,
        "num_assistant_tokens_schedule": "constant",
        "assistant_confidence_threshold": 0.4,
        "prompt_lookup_num_tokens": null,
        "max_matching_ngram_size": null,
        "assistant_early_exit": null,
        "assistant_lookbehind": 10,
        "target_lookbehind": 10,
        "disable_compile": false,
        "generation_kwargs": {},
        "_from_model_config": false,
        "transformers_version": "4.51.3"
      },
      "generation_overrides": {
        "do_sample": false,
        "num_beams": 1,
        "use_model_defaults": false
      }
    }
  ],
  "full_study_total": null,
  "note": "Collection cumulative timing excludes nested fixed-2A and requested event timing, which are reported separately. Unknown stages remain unmeasured. Two event directories require independent references, not twice the whole runtime. Interventions remain conditional scenarios; use their model-timing-report for frozen cohort counts. No stages are automatically launched."
}
```
