# Fixed-2A replay and candidate-sequence timing

Status: **INCOMPLETE**. Mock timings are not live performance evidence.

## Completed timing observations

| Operation / model / measurement | N | Mean seconds | Median | Range |
|---|---:|---:|---:|---|

## Remaining work

Serial scenarios only. Unobserved stages remain **NOT YET MEASURED**; they are never zero-duration estimates.

| Operation | Remaining count scenario | Estimated seconds | Status |
|---|---|---|---|
| unchanged_replay | [0, 96] | None | NOT_YET_MEASURED |
| candidate_sequence_scoring_fixed_2a | [0, 432] | None | NOT_YET_MEASURED |

The machine-readable JSON includes source identities, individual case states, all denominators, unknown-outcome bounds, rate assumptions, invocation versus cumulative timing, and billing limitations.

## Complete audit data

```json
{
  "status": "INCOMPLETE",
  "workload": {
    "basis": "CONDITIONAL_BEFORE_COLLECTION",
    "counts": {
      "unchanged_replay": {
        "planned_maximum": 96,
        "remaining_count_scenario": [
          0,
          96
        ]
      },
      "candidate_sequence_scoring_fixed_2a": {
        "planned_maximum": 432,
        "remaining_count_scenario": [
          0,
          432
        ]
      }
    }
  },
  "remaining_work": {
    "unchanged_replay": {
      "planned_maximum": 96,
      "remaining_count_scenario": [
        0,
        96
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    },
    "candidate_sequence_scoring_fixed_2a": {
      "planned_maximum": 432,
      "remaining_count_scenario": [
        0,
        432
      ],
      "status": "NOT_YET_MEASURED",
      "seconds_scenario": null
    }
  },
  "observations": {},
  "actual_timed_calls": {
    "unchanged_replay": {
      "attempted": 0,
      "returned": 0,
      "failed": 0
    },
    "candidate_sequence_scoring": {
      "attempted": 0,
      "returned": 0,
      "failed": 0
    }
  },
  "cache_hits": 0,
  "failures": 0,
  "input_tokens": 0,
  "output_tokens": 0,
  "this_invocation": null,
  "invocations": [],
  "hardware_software_precision": [],
  "full_study_total": null,
  "note": "Delegates the unchanged fixed-2A algorithm. Legacy caches reduce remaining work even without measured durations; unmeasured time is not zero."
}
```
