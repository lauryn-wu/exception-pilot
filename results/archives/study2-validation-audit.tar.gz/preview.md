# Unmodified trajectory prompts; no outputs

## selection-continuation-v3-000/v0/direct

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| ICZBXN | Built for subzero temperatures | Automatic | Vinyl | Four | X | A |
| IBG4Q4 | Used at an Arctic station | Manual | Cloth | Two | Z | A |
| IBKVDR | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| IMFWM7 | Used at an equatorial station | Manual | Cloth | Four | Y | C |
| IG6XNB | Operates on polar ice | Automatic | Vinyl | Four | X | A |
| IRYWZY | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| IWF765 | Built for desert heat | Automatic | Cloth | Four | Z | C |
| IYRBT4 | Designed for humid summers | Manual | Vinyl | Four | X | B |
| IJDUKB | Designed for frozen terrain | Automatic | Vinyl | Four | Z | A |
| IJTFPP | Equipped with snow tracks | Automatic | Cloth | Two | Y | B |

License plate: IJTFPP
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

## selection-continuation-v3-000/v0/visible

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| ICZBXN | Built for subzero temperatures | Automatic | Vinyl | Four | X | A |
| IBG4Q4 | Used at an Arctic station | Manual | Cloth | Two | Z | A |
| IBKVDR | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| IMFWM7 | Used at an equatorial station | Manual | Cloth | Four | Y | C |
| IG6XNB | Operates on polar ice | Automatic | Vinyl | Four | X | A |
| IRYWZY | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| IWF765 | Built for desert heat | Automatic | Cloth | Four | Z | C |
| IYRBT4 | Designed for humid summers | Manual | Vinyl | Four | X | B |
| IJDUKB | Designed for frozen terrain | Automatic | Vinyl | Four | Z | A |
| IJTFPP | Equipped with snow tracks | Automatic | Cloth | Two | Y | B |

License plate: IJTFPP
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```

## selection-continuation-v3-000/v1/direct

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| ICZBXN | Built for subzero temperatures | Automatic | Vinyl | Four | X | A |
| IBG4Q4 | Used at an Arctic station | Manual | Cloth | Two | Z | A |
| IBKVDR | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| IMFWM7 | Used at an equatorial station | Manual | Cloth | Four | Y | C |
| IG6XNB | Operates on polar ice | Automatic | Vinyl | Four | X | A |
| IRYWZY | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| IWF765 | Built for desert heat | Automatic | Cloth | Four | Z | C |
| IYRBT4 | Designed for humid summers | Manual | Vinyl | Four | X | B |
| IJDUKB | Designed for frozen terrain | Automatic | Vinyl | Four | Z | A |
| IJTFPP | Equipped with snow tracks | Automatic | Cloth | Two | Y | C |

License plate: IJTFPP
Which class, A, B, or C, does this vehicle belong to?
Output only ANSWER: followed by A, B, or C.
```

## selection-continuation-v3-000/v1/visible

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| ICZBXN | Built for subzero temperatures | Automatic | Vinyl | Four | X | A |
| IBG4Q4 | Used at an Arctic station | Manual | Cloth | Two | Z | A |
| IBKVDR | Operates in tropical forests | Automatic | Vinyl | Two | Y | B |
| IMFWM7 | Used at an equatorial station | Manual | Cloth | Four | Y | C |
| IG6XNB | Operates on polar ice | Automatic | Vinyl | Four | X | A |
| IRYWZY | Equipped for hot sand | Automatic | Vinyl | Two | X | B |
| IWF765 | Built for desert heat | Automatic | Cloth | Four | Z | C |
| IYRBT4 | Designed for humid summers | Manual | Vinyl | Four | X | B |
| IJDUKB | Designed for frozen terrain | Automatic | Vinyl | Four | Z | A |
| IJTFPP | Equipped with snow tracks | Automatic | Cloth | Two | Y | C |

License plate: IJTFPP
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line.
```