# Offline rationale audit

Coder: `record-evidence-lexical-v2`. 96 scorable visible responses.

Provisional lexical codes describe detected written evidence; never_stated means no qualifying assertion was detected, not proof of absence. They do not establish retrieval, task recognition, or faithful internal reasoning. The conservative rule requires a target-record assertion, includes multiline record blocks, and rejects bare inferential comparisons. Missing-label evidence takes precedence; both flags remain in CSV. Evidence excerpts are Markdown-normalized, not raw character offsets.

The brief's single-line regex disagrees with the revised record-evidence flag on 31/96 responses. Both legacy flags are retained. JSON reasoning fields are decoded. Missing-gold tasks, nonreasoning anchors, and replay tasks are excluded. Revision and reasoning-first traces are also shown separately below.

| Run | Cell | Outcome | Code | Count | Share within cell/outcome |
|---|---|---|---|---:|---:|
| query-form-gpt4o-001 | all selected arms | correct | never_stated | 32 | 60.4% |
| query-form-gpt4o-001 | all selected arms | correct | relabeled_missing | 7 | 13.2% |
| query-form-gpt4o-001 | all selected arms | correct | stated_then_overridden | 0 | 0.0% |
| query-form-gpt4o-001 | all selected arms | correct | stated_and_followed | 14 | 26.4% |
| query-form-gpt4o-001 | all selected arms | wrong | never_stated | 21 | 48.8% |
| query-form-gpt4o-001 | all selected arms | wrong | relabeled_missing | 17 | 39.5% |
| query-form-gpt4o-001 | all selected arms | wrong | stated_then_overridden | 5 | 11.6% |
| query-form-gpt4o-001 | all selected arms | wrong | stated_and_followed | 0 | 0.0% |

| Run | Cell | Outcome | Code | Count | Share within cell/outcome |
|---|---|---|---|---:|---:|
| query-form-gpt4o-001 | key/visible | correct | never_stated | 18 | 72.0% |
| query-form-gpt4o-001 | key/visible | correct | relabeled_missing | 5 | 20.0% |
| query-form-gpt4o-001 | key/visible | correct | stated_then_overridden | 0 | 0.0% |
| query-form-gpt4o-001 | key/visible | correct | stated_and_followed | 2 | 8.0% |
| query-form-gpt4o-001 | key/visible | wrong | never_stated | 9 | 39.1% |
| query-form-gpt4o-001 | key/visible | wrong | relabeled_missing | 10 | 43.5% |
| query-form-gpt4o-001 | key/visible | wrong | stated_then_overridden | 4 | 17.4% |
| query-form-gpt4o-001 | key/visible | wrong | stated_and_followed | 0 | 0.0% |
| query-form-gpt4o-001 | profile/visible | correct | never_stated | 14 | 50.0% |
| query-form-gpt4o-001 | profile/visible | correct | relabeled_missing | 2 | 7.1% |
| query-form-gpt4o-001 | profile/visible | correct | stated_then_overridden | 0 | 0.0% |
| query-form-gpt4o-001 | profile/visible | correct | stated_and_followed | 12 | 42.9% |
| query-form-gpt4o-001 | profile/visible | wrong | never_stated | 12 | 60.0% |
| query-form-gpt4o-001 | profile/visible | wrong | relabeled_missing | 7 | 35.0% |
| query-form-gpt4o-001 | profile/visible | wrong | stated_then_overridden | 1 | 5.0% |
| query-form-gpt4o-001 | profile/visible | wrong | stated_and_followed | 0 | 0.0% |
