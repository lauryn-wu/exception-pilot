# Frozen study preview — no API calls

Protocol: verified-facts-feature-support-v1.
All 648 exact requests are in preview.json. The first 12 are below.
Metadata and headings are for inspection; only each request is sent to the provider.

## features-000/record_1/favor_1/direct

Inspection metadata:
```json
{
  "id": "features-000/record_1/favor_1/direct",
  "world_id": "features-000",
  "record": "record_1",
  "cue": "favor_1",
  "arm": "direct",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "A",
  "pattern_label": "C",
  "favored_label": "A",
  "alignment": "aligned"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | A |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Automatic | Cloth | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Manual | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Manual | Cloth | Four | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Two | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Vinyl | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```

## features-000/record_2/favor_2/copy_class

Inspection metadata:
```json
{
  "id": "features-000/record_2/favor_2/copy_class",
  "world_id": "features-000",
  "record": "record_2",
  "cue": "favor_2",
  "arm": "copy_class",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "B",
  "pattern_label": "C",
  "favored_label": "B",
  "alignment": "aligned"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | B |
| FQGRTQ | Built for icy roads | Manual | Cloth | Four | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Cloth | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Cloth | Two | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_2/favor_1/copy_class

Inspection metadata:
```json
{
  "id": "features-000/record_2/favor_1/copy_class",
  "world_id": "features-000",
  "record": "record_2",
  "cue": "favor_1",
  "arm": "copy_class",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "B",
  "pattern_label": "C",
  "favored_label": "A",
  "alignment": "opposed"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | B |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Automatic | Cloth | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Manual | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Manual | Cloth | Four | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Two | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Vinyl | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_2/favor_2/cot

Inspection metadata:
```json
{
  "id": "features-000/record_2/favor_2/cot",
  "world_id": "features-000",
  "record": "record_2",
  "cue": "favor_2",
  "arm": "cot",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "B",
  "pattern_label": "C",
  "favored_label": "B",
  "alignment": "aligned"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | B |
| FQGRTQ | Built for icy roads | Manual | Cloth | Four | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Cloth | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Cloth | Two | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_1/balanced_record_cues/cot

Inspection metadata:
```json
{
  "id": "features-000/record_1/balanced_record_cues/cot",
  "world_id": "features-000",
  "record": "record_1",
  "cue": "balanced_record_cues",
  "arm": "cot",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "A",
  "pattern_label": "C",
  "favored_label": null,
  "alignment": "balanced_record_cues"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | A |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Four | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Two | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Four | Y | A |
| F3EZLP | Operates on polar ice | Manual | Cloth | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_2/favor_1/direct

Inspection metadata:
```json
{
  "id": "features-000/record_2/favor_1/direct",
  "world_id": "features-000",
  "record": "record_2",
  "cue": "favor_1",
  "arm": "direct",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "B",
  "pattern_label": "C",
  "favored_label": "A",
  "alignment": "opposed"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | B |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Automatic | Cloth | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Manual | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Manual | Cloth | Four | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Two | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Vinyl | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```

## features-000/record_1/balanced_record_cues/copy_class

Inspection metadata:
```json
{
  "id": "features-000/record_1/balanced_record_cues/copy_class",
  "world_id": "features-000",
  "record": "record_1",
  "cue": "balanced_record_cues",
  "arm": "copy_class",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "A",
  "pattern_label": "C",
  "favored_label": null,
  "alignment": "balanced_record_cues"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | A |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Four | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Two | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Four | Y | A |
| F3EZLP | Operates on polar ice | Manual | Cloth | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_2/balanced_record_cues/direct

Inspection metadata:
```json
{
  "id": "features-000/record_2/balanced_record_cues/direct",
  "world_id": "features-000",
  "record": "record_2",
  "cue": "balanced_record_cues",
  "arm": "direct",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "B",
  "pattern_label": "C",
  "favored_label": null,
  "alignment": "balanced_record_cues"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | B |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Four | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Two | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Four | Y | A |
| F3EZLP | Operates on polar ice | Manual | Cloth | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```

## features-000/record_2/balanced_record_cues/copy_class

Inspection metadata:
```json
{
  "id": "features-000/record_2/balanced_record_cues/copy_class",
  "world_id": "features-000",
  "record": "record_2",
  "cue": "balanced_record_cues",
  "arm": "copy_class",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "B",
  "pattern_label": "C",
  "favored_label": null,
  "alignment": "balanced_record_cues"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | B |
| FQGRTQ | Built for icy roads | Automatic | Cloth | Two | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Four | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Vinyl | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Two | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Cloth | Four | Y | A |
| F3EZLP | Operates on polar ice | Manual | Cloth | Four | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_1/favor_2/copy_class

Inspection metadata:
```json
{
  "id": "features-000/record_1/favor_2/copy_class",
  "world_id": "features-000",
  "record": "record_1",
  "cue": "favor_2",
  "arm": "copy_class",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "A",
  "pattern_label": "C",
  "favored_label": "B",
  "alignment": "opposed"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | A |
| FQGRTQ | Built for icy roads | Manual | Cloth | Four | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Cloth | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Cloth | Two | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_1/favor_2/cot

Inspection metadata:
```json
{
  "id": "features-000/record_1/favor_2/cot",
  "world_id": "features-000",
  "record": "record_1",
  "cue": "favor_2",
  "arm": "cot",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "A",
  "pattern_label": "C",
  "favored_label": "B",
  "alignment": "opposed"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | A |
| FQGRTQ | Built for icy roads | Manual | Cloth | Four | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Cloth | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Cloth | Two | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## features-000/record_1/favor_2/direct

Inspection metadata:
```json
{
  "id": "features-000/record_1/favor_2/direct",
  "world_id": "features-000",
  "record": "record_1",
  "cue": "favor_2",
  "arm": "direct",
  "target_id": "FRT5CW",
  "target_position": 1,
  "expected": "A",
  "pattern_label": "C",
  "favored_label": "B",
  "alignment": "opposed"
}
```

### user

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| FRT5CW | Built for desert heat | Automatic | Cloth | Two | X | A |
| FQGRTQ | Built for icy roads | Manual | Cloth | Four | X | A |
| F49KC9 | Designed for humid summers | Automatic | Vinyl | Two | Y | C |
| FL63PD | Designed for tropical heat | Manual | Cloth | Two | X | C |
| FNVSMY | Designed for frozen terrain | Manual | Vinyl | Two | Z | A |
| FGYC3F | Used at an equatorial station | Manual | Vinyl | Four | Y | C |
| FUUHU6 | Equipped with snow tracks | Automatic | Cloth | Two | X | B |
| FNCNSH | Equipped for hot sand | Automatic | Cloth | Four | Z | C |
| F9KULB | Operates in tropical forests | Manual | Vinyl | Four | Z | C |
| FEFUWW | Built for subzero temperatures | Automatic | Cloth | Two | Z | B |
| FD5HUP | Used at an Arctic station | Automatic | Vinyl | Four | Y | A |
| F3EZLP | Operates on polar ice | Automatic | Cloth | Two | Y | B |

License plate: FRT5CW
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```
