# Explanatory diagnostic preview — no API calls

24 worlds × 16 requests = 384 planned calls. Up to 16 explicitly requested transport retries fit within the 400-attempt cumulative cap.

This is all 16 requests from one world. Each request starts an independent conversation. MISSING has no individual ground-truth answer. The headings and answer keys are for human inspection and are not added to API messages.

## ex-list-000/missing/copy_class

Recorded class: unrecorded; same-climate pattern: A; copy field: MISSING.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | MISSING |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_2/cot

Recorded class: C; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_2/direct

Recorded class: C; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```

## ex-list-000/record_2/copy_marker

Recorded class: C; same-climate pattern: A; copy field: Z.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Audit marker cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/missing/direct

Recorded class: unrecorded; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | MISSING |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```

## ex-list-000/record_2/copy_class

Recorded class: C; same-climate pattern: A; copy field: C.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_1/copy_marker

Recorded class: B; same-climate pattern: A; copy field: Z.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | B |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Audit marker cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/anchor/cot

Recorded class: A; same-climate pattern: B; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | A |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | A |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | B |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | A |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | B |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | A |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | B |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | B |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | B |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A or B, does this vehicle belong to?
Think step by step, then put A or B alone on the final line.
```

## ex-list-000/missing/cot

Recorded class: unrecorded; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | MISSING |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_1/cot

Recorded class: B; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | B |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_1/copy_class

Recorded class: B; same-climate pattern: A; copy field: B.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | B |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Verified class cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/anchor/direct

Recorded class: A; same-climate pattern: B; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | A |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | A |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | B |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | A |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | B |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | A |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | B |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | B |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | B |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A or B, does this vehicle belong to?
Reply with only A or B.
```

## ex-list-000/record_1/priority

Recorded class: B; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | B |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
The target vehicle's verified class is definitive. Use that individual record even if the other vehicles suggest a different class. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_2/priority

Recorded class: C; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | C |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
The target vehicle's verified class is definitive. Use that individual record even if the other vehicles suggest a different class. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/missing/copy_marker

Recorded class: unrecorded; same-climate pattern: A; copy field: Z.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | MISSING |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
First copy the target vehicle's Audit marker cell exactly, using COPIED: followed by the cell value alone on the first line. Do not explain before that line. Think step by step, then put ANSWER: followed by A, B, or C alone on the final line.
```

## ex-list-000/record_1/direct

Recorded class: B; same-climate pattern: A; copy field: none.

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| EEF3UM | Equipped with snow tracks | Automatic | Vinyl | Four | Z | B |
| EBV2LA | Designed for frozen terrain | Automatic | Vinyl | Two | X | C |
| EGK6P3 | Operates in tropical forests | Automatic | Vinyl | Four | Y | A |
| EZKZXD | Designed for humid summers | Automatic | Vinyl | Two | Z | B |
| ED9BUV | Used at an equatorial station | Automatic | Vinyl | Two | Y | A |
| E9PUA6 | Used at an Arctic station | Manual | Cloth | Four | Z | B |
| EJZ6T8 | Built for subzero temperatures | Manual | Vinyl | Four | X | B |
| EWEC56 | Equipped for hot sand | Manual | Vinyl | Four | Z | A |
| EP3ARK | Operates on polar ice | Automatic | Vinyl | Four | Y | C |
| EZ3K2B | Built for desert heat | Manual | Vinyl | Four | X | A |

License plate: EZKZXD
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Reply with only ANSWER: followed by A, B, or C.
```
