# Constrained-output reasoning cue preview — no API calls

24 reused cue worlds × 2 recorded-class variants × 2 conditions = 96 planned calls. The cumulative cap is 112 attempts, including explicitly requested transport retries.

This document shows the four exact requests from the first world; preview.json contains all 96 exact requests. Each request starts an independent conversation. Every world, target, and table is preserved from the cue study. The MISSING definition is unchanged; all target cells are recorded. This is not fresh confirmation data.

Both arms have the same strict response schema and token cap. The cue arm differs only by the prefix 'Think step by step before answering. ' in the final instruction. A returned schema or technical failure is retained and stops collection; do not resample it or resume past it. Headings and answer keys below are not added to API messages.

## Request settings shared by both arms

```json
{
  "model": "gpt-4o-2024-08-06",
  "temperature": 0.0,
  "max_completion_tokens": 1000,
  "n": 1,
  "store": false
}
```

## Exact response format shared by both arms

```json
{
  "type": "json_schema",
  "json_schema": {
    "name": "class_answer",
    "strict": true,
    "schema": {
      "type": "object",
      "properties": {
        "answer": {
          "type": "string",
          "enum": [
            "A",
            "B",
            "C"
          ]
        }
      },
      "required": [
        "answer"
      ],
      "additionalProperties": false
    }
  }
}
```

## cue-list-000/record_2/direct

Recorded class: A; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | A |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with one field, "answer", whose value is A, B, or C.
```

## cue-list-000/record_2/cue

Recorded class: A; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | A |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Output only a JSON object with one field, "answer", whose value is A, B, or C.
```

## cue-list-000/record_1/cue

Recorded class: C; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Think step by step before answering. Output only a JSON object with one field, "answer", whose value is A, B, or C.
```

## cue-list-000/record_1/direct

Recorded class: C; same-climate pattern: B.

User message:

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.

| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |
|---|---|---|---|---|---|---|
| QR9SCU | Used at an equatorial station | Automatic | Cloth | Two | Z | A |
| QPVQFH | Operates in tropical forests | Manual | Vinyl | Two | X | C |
| QNWHX2 | Designed for humid summers | Manual | Vinyl | Two | X | C |
| QN9HR7 | Operates on polar ice | Automatic | Vinyl | Two | Z | C |
| QARRGF | Built for desert heat | Automatic | Vinyl | Four | Y | A |
| QU6CU4 | Built for subzero temperatures | Manual | Cloth | Four | Y | B |
| QJ6KJV | Equipped for hot sand | Automatic | Vinyl | Two | X | C |
| Q6QH55 | Used at an Arctic station | Manual | Vinyl | Four | Y | B |
| QWU3MM | Equipped with snow tracks | Automatic | Vinyl | Two | Z | B |
| QL7NDE | Designed for frozen terrain | Automatic | Cloth | Four | Y | B |

License plate: QN9HR7
Description: Operates on polar ice
Transmission: Automatic
Seat cover: Vinyl
Doors: Two
Which class, A, B, or C, does this vehicle belong to?
Output only a JSON object with one field, "answer", whose value is A, B, or C.
```
