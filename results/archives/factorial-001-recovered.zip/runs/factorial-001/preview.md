# Question × uncertainty preview — no model calls

20 fresh lists × 2 targets × 2 backgrounds × 2 questions × 2 uncertainty levels × 2 instructions = 640 calls.

This preview includes every first-list request. All conditions share the target facts. Both backgrounds have 20% exceptions; six non-target labels change.

## Exact question, uncertainty, and response wording

### Question: original

Which class, A or B, does this vehicle belong to?

### Question: recorded

Which class, A or B, is recorded for this vehicle in the table above?

### Uncertainty sentence

Present: append this line after either question.

Choose the more likely class even if uncertain.

Absent: omit that line entirely.

### Response: direct

Reply with only A or B.

### Response: cot_neutral

Think step by step, then put A or B alone on the final line.

## All 32 first-list requests

Condition headings and answer keys below are for human inspection, never extra API content.

### fx-list-000/0/conflict/recorded/absent/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### fx-list-000/6/conflict/recorded/present/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/support/recorded/present/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/6/conflict/original/absent/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/conflict/original/absent/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Reply with only A or B.
```

### fx-list-000/6/support/original/present/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/6/conflict/original/present/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/support/recorded/absent/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/6/conflict/original/absent/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Reply with only A or B.
```

### fx-list-000/6/support/original/absent/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Reply with only A or B.
```

### fx-list-000/6/support/original/present/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/6/support/recorded/present/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/6/conflict/recorded/absent/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/support/recorded/present/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/support/original/absent/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/conflict/original/absent/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/6/conflict/original/present/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/6/support/original/absent/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, does this vehicle belong to?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/support/recorded/absent/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### fx-list-000/0/conflict/recorded/present/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/conflict/recorded/absent/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/conflict/original/present/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/6/conflict/recorded/absent/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### fx-list-000/6/support/recorded/absent/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Reply with only A or B.
```

### fx-list-000/0/support/original/present/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/6/support/recorded/absent/cot_neutral

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/conflict/original/present/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/0/support/original/absent/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Reply with only A or B.
```

### fx-list-000/6/support/recorded/present/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/6/conflict/recorded/present/direct

Answer key: A (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: FLZBZS
Description: Designed for humid summers
Transmission: Automatic
Seat cover: Cloth
Doors: Two
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

### fx-list-000/0/support/original/present/cot_neutral

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | A |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | B |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | B |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | A |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | B |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | A |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, does this vehicle belong to?
Choose the more likely class even if uncertain.
Think step by step, then put A or B alone on the final line.
```

### fx-list-000/0/conflict/recorded/present/direct

Answer key: B (already in the record table).

```text
These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it.

| License plate | Description | Transmission | Seat cover | Doors | Verified class |
|---|---|---|---|---|---|
| F7JSUD | Operates in tropical forests | Manual | Cloth | Four | B |
| F2Q6J6 | Used at an Arctic station | Manual | Vinyl | Four | B |
| FVWS3F | Designed for frozen terrain | Automatic | Cloth | Four | A |
| FPQNDG | Equipped with snow tracks | Automatic | Cloth | Four | A |
| FUNYX4 | Equipped for hot sand | Manual | Cloth | Two | B |
| FLZBZS | Designed for humid summers | Automatic | Cloth | Two | A |
| FJRXPF | Used at an equatorial station | Manual | Cloth | Two | B |
| FJTWT2 | Built for subzero temperatures | Manual | Vinyl | Four | A |
| FKPB8L | Operates on polar ice | Automatic | Cloth | Two | A |
| F3GCE7 | Built for desert heat | Automatic | Vinyl | Two | B |

License plate: F2Q6J6
Description: Used at an Arctic station
Transmission: Manual
Seat cover: Vinyl
Doors: Four
Which class, A or B, is recorded for this vehicle in the table above?
Choose the more likely class even if uncertain.
Reply with only A or B.
```

