# Mistral prefix feasibility preview — no API calls

1 capability check + 48 base requests + 24 conditional unedited replays = at most 73 planned calls. The cumulative cap is 89 attempts. No edited-prefix arms or stage two are implemented.

The requested mistral-small-2603 identifier is versioned; this is not a guarantee of an immutable backend. The first nonempty returned model identity is latched from the journal; any later model-name change terminates the screen. reasoning_effort is none. Raw reasoning_content and system_fingerprint are retained, and nonempty reasoning_content is invalid.

Capability succeeds only if returned full text is exactly `Cobalt Maple Lantern`, without a leading or trailing character, including whitespace. The assistant prefix is `Cobalt Ma`. Mistral includes the supplied prefix in its returned completion. Replay requires an exact leading-prefix match; suffix comparisons remove exactly that prefix length once, while scoring uses the full returned text.

preview.json contains exact capability and base requests and all 24 frozen replay recipes. Replay payloads cannot be known until their saved visible parents exist; each exact request and parent hash/cut metadata is journaled before sending. No gold answer is supplied separately.

## Capability request

```json
{
  "model": "mistral-small-2603",
  "messages": [
    {
      "role": "user",
      "content": "Output exactly this text, without quotation marks or commentary:\nCobalt Maple Lantern"
    },
    {
      "role": "assistant",
      "content": "Cobalt Ma",
      "prefix": true
    }
  ],
  "temperature": 0.0,
  "max_tokens": 32,
  "reasoning_effort": "none",
  "stream": false
}
```

## First world's four base requests

### prefix-list-000/record_1/direct

Recorded class: A; pattern: C.

```json
{
  "model": "mistral-small-2603",
  "messages": [
    {
      "role": "user",
      "content": "These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.\n\n| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |\n|---|---|---|---|---|---|---|\n| N6NH8H | Built for desert heat | Manual | Vinyl | Two | X | A |\n| N9DRUL | Built for subzero temperatures | Automatic | Cloth | Two | X | C |\n| NVLGGH | Operates in tropical forests | Automatic | Vinyl | Four | Z | B |\n| NX8CQT | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |\n| N5TGU8 | Used at an Arctic station | Manual | Cloth | Two | Y | C |\n| NDRVZ9 | Designed for humid summers | Automatic | Cloth | Two | Z | B |\n| NU4QJ9 | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |\n| N6QR3E | Operates on polar ice | Automatic | Vinyl | Four | Y | A |\n| NFXK8H | Equipped for hot sand | Manual | Vinyl | Two | Z | A |\n| NQQ8VW | Used at an equatorial station | Manual | Vinyl | Four | Y | A |\n\nLicense plate: N6QR3E\nDescription: Operates on polar ice\nTransmission: Automatic\nSeat cover: Vinyl\nDoors: Four\nWhich class, A, B, or C, does this vehicle belong to?\nOutput only ANSWER: followed by A, B, or C."
    }
  ],
  "temperature": 0.0,
  "max_tokens": 1600,
  "reasoning_effort": "none",
  "stream": false
}
```

### prefix-list-000/record_2/direct

Recorded class: B; pattern: C.

```json
{
  "model": "mistral-small-2603",
  "messages": [
    {
      "role": "user",
      "content": "These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.\n\n| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |\n|---|---|---|---|---|---|---|\n| N6NH8H | Built for desert heat | Manual | Vinyl | Two | X | A |\n| N9DRUL | Built for subzero temperatures | Automatic | Cloth | Two | X | C |\n| NVLGGH | Operates in tropical forests | Automatic | Vinyl | Four | Z | B |\n| NX8CQT | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |\n| N5TGU8 | Used at an Arctic station | Manual | Cloth | Two | Y | C |\n| NDRVZ9 | Designed for humid summers | Automatic | Cloth | Two | Z | B |\n| NU4QJ9 | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |\n| N6QR3E | Operates on polar ice | Automatic | Vinyl | Four | Y | B |\n| NFXK8H | Equipped for hot sand | Manual | Vinyl | Two | Z | A |\n| NQQ8VW | Used at an equatorial station | Manual | Vinyl | Four | Y | A |\n\nLicense plate: N6QR3E\nDescription: Operates on polar ice\nTransmission: Automatic\nSeat cover: Vinyl\nDoors: Four\nWhich class, A, B, or C, does this vehicle belong to?\nOutput only ANSWER: followed by A, B, or C."
    }
  ],
  "temperature": 0.0,
  "max_tokens": 1600,
  "reasoning_effort": "none",
  "stream": false
}
```

### prefix-list-000/record_1/visible

Recorded class: A; pattern: C.

```json
{
  "model": "mistral-small-2603",
  "messages": [
    {
      "role": "user",
      "content": "These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.\n\n| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |\n|---|---|---|---|---|---|---|\n| N6NH8H | Built for desert heat | Manual | Vinyl | Two | X | A |\n| N9DRUL | Built for subzero temperatures | Automatic | Cloth | Two | X | C |\n| NVLGGH | Operates in tropical forests | Automatic | Vinyl | Four | Z | B |\n| NX8CQT | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |\n| N5TGU8 | Used at an Arctic station | Manual | Cloth | Two | Y | C |\n| NDRVZ9 | Designed for humid summers | Automatic | Cloth | Two | Z | B |\n| NU4QJ9 | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |\n| N6QR3E | Operates on polar ice | Automatic | Vinyl | Four | Y | A |\n| NFXK8H | Equipped for hot sand | Manual | Vinyl | Two | Z | A |\n| NQQ8VW | Used at an equatorial station | Manual | Vinyl | Four | Y | A |\n\nLicense plate: N6QR3E\nDescription: Operates on polar ice\nTransmission: Automatic\nSeat cover: Vinyl\nDoors: Four\nWhich class, A, B, or C, does this vehicle belong to?\nThink step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line."
    }
  ],
  "temperature": 0.0,
  "max_tokens": 1600,
  "reasoning_effort": "none",
  "stream": false
}
```

### prefix-list-000/record_2/visible

Recorded class: B; pattern: C.

```json
{
  "model": "mistral-small-2603",
  "messages": [
    {
      "role": "user",
      "content": "These are records of previously observed vehicles. Every record is accurate. An individual vehicle's class is fixed, and its license plate identifies it. The audit marker is an administrative code assigned independently of class. MISSING means the verified class has not been recorded. If that cell is MISSING, make your best prediction from the other records.\n\n| License plate | Description | Transmission | Seat cover | Doors | Audit marker | Verified class |\n|---|---|---|---|---|---|---|\n| N6NH8H | Built for desert heat | Manual | Vinyl | Two | X | A |\n| N9DRUL | Built for subzero temperatures | Automatic | Cloth | Two | X | C |\n| NVLGGH | Operates in tropical forests | Automatic | Vinyl | Four | Z | B |\n| NX8CQT | Equipped with snow tracks | Automatic | Vinyl | Two | X | C |\n| N5TGU8 | Used at an Arctic station | Manual | Cloth | Two | Y | C |\n| NDRVZ9 | Designed for humid summers | Automatic | Cloth | Two | Z | B |\n| NU4QJ9 | Designed for frozen terrain | Automatic | Cloth | Two | Z | C |\n| N6QR3E | Operates on polar ice | Automatic | Vinyl | Four | Y | B |\n| NFXK8H | Equipped for hot sand | Manual | Vinyl | Two | Z | A |\n| NQQ8VW | Used at an equatorial station | Manual | Vinyl | Four | Y | A |\n\nLicense plate: N6QR3E\nDescription: Operates on polar ice\nTransmission: Automatic\nSeat cover: Vinyl\nDoors: Four\nWhich class, A, B, or C, does this vehicle belong to?\nThink step by step before answering. Write your reasoning, then put ANSWER: followed by A, B, or C alone on the final line."
    }
  ],
  "temperature": 0.0,
  "max_tokens": 1600,
  "reasoning_effort": "none",
  "stream": false
}
```

## Practical gates

```json
{
  "scope": "Capability and unedited replay feasibility only; no edited-prefix arms or stage two.",
  "unit": "world; record variants and arms remain paired; world identities are reused from the prefix screen",
  "bootstrap": "10000 whole-world resamples; descriptive unadjusted 95% percentile intervals",
  "capability": "Returned full text must equal 'Cobalt Maple Lantern' exactly, including whitespace.",
  "phenomenon_gate": {
    "minimum_direct_correct": 20,
    "minimum_direct_minus_visible_count": 4,
    "minimum_visible_pattern_errors": 4,
    "minimum_pattern_error_worlds": 3
  },
  "replay_gate": {
    "required_valid": 24,
    "minimum_answer_matches": 22,
    "minimum_pattern_error_match_fraction": 0.8
  },
  "cuts": "Nearest eligible whitespace boundary at or before midpoint; otherwise first eligible boundary after it.",
  "invalid_answers": "Retain and stop on every returned invalid response; never resample or continue past it.",
  "interpretation": "Fixed practical investment gates are not significance tests or evidence of a mechanism. Provider continuation is not a saved internal state. Prefixes may contain an early answer cue; no edited-prefix causal experiment is run in this screen.",
  "worlds": "The same frozen 12 worlds and schedule as the DeepSeek prefix screen, not new independent worlds.",
  "return_contract": "Mistral returns full assistant completion including supplied prefix. Replay must start with the exact supplied prefix. Remove exactly that prefix length once only to compare suffixes; score the original full returned text without prepending it."
}
```
