# Query-role screen — every exact prompt

Preparing this file makes zero API calls. All 144 requests are frozen in advance. There are no outcome-dependent gates, interventions, or assistant prefixes.

Each block below contains the complete user message. Metadata, including the expected answer, is shown for audit and is never supplied to the model. preview.json contains every complete API request in execution order.

Plan hash: `6fbc5eb49043f0d07b2756880023bfa829147df5e1187e8e49272d0c638b758f`

## Shared request settings

```json
{
  "model": "mistral-small-2603",
  "temperature": 0.6,
  "top_p": 0.95,
  "max_tokens": 1600,
  "reasoning_effort": "none",
  "stream": false
}
```

## query-role-vehicle-003/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | A
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which dispatch gate is vehicle QV3VU8W6 assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | A
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Fast
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "Quiet",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Quiet
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "A",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | A
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | C
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | C
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which dispatch gate is vehicle QV1FWY2T assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | B
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Balanced
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

Which control signal does device QD3DWH3H use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | C
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Quiet
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

Which control signal does device QD3DWH3H use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | A
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which dispatch gate is vehicle QV44N7EA assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | A
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | C
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | C
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | C
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which dispatch gate is vehicle QV1FWY2T assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "C",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | C
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Fast
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

Which control signal does device QD5WR8YT use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "Balanced",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Balanced
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Quiet
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

Which control signal does device QD3DWH3H use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Balanced
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | B
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which dispatch gate is vehicle QV598S3R assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Balanced
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

Which control signal does device QD4LGPFS use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | A
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Quiet
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Quiet
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "Fast",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Fast
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Quiet
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | C
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | A
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

Which control signal does device QD2WFFQ8 use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "Fast",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Fast
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "A",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | A
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "B",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | B
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | B
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which dispatch gate is vehicle QV3VU8W6 assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "A",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | A
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Fast
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

Which control signal does device QD5WR8YT use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | B
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "A",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | A
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Fast
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Quiet
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

Which control signal does device QD5WR8YT use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | A
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which dispatch gate is vehicle QV0WPLY6 assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Balanced
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | B
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which dispatch gate is vehicle QV1FWY2T assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Fast
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | B
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Quiet
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "Fast",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "Quiet",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "Balanced",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Balanced
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | C
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which dispatch gate is vehicle QV2DH6ZA assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | B
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which dispatch gate is vehicle QV1FWY2T assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "A",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | A
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

Which control signal does device QD2WFFQ8 use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "B",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | B
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | A
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "B",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | B
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "C",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | C
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "A",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | A
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Fast
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

Which control signal does device QD1LY6LN use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | A
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which dispatch gate is vehicle QV3VU8W6 assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "C",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | C
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Quiet
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Quiet
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

Which control signal does device QD0E8UZ4 use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

Which control signal does device QD2WFFQ8 use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "B",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | B
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | A
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which dispatch gate is vehicle QV0WPLY6 assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "Quiet",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Quiet
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Balanced
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | C
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which dispatch gate is vehicle QV2DH6ZA assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Balanced
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

Which control signal does device QD0E8UZ4 use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Balanced
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

Which control signal does device QD1LY6LN use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Balanced
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

Which control signal does device QD0E8UZ4 use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Quiet
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

Which control signal does device QD0E8UZ4 use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "B",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | B
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "Quiet",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Quiet
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | A
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which dispatch gate is vehicle QV598S3R assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Fast
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

Which control signal does device QD4LGPFS use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | A
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | B
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "Fast",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Fast
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | C
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which dispatch gate is vehicle QV44N7EA assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | B
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which dispatch gate is vehicle QV598S3R assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "Quiet",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Quiet
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "C",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | C
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Fast
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

Which control signal does device QD1LY6LN use?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "Fast",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "Balanced",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Balanced
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "Quiet",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Quiet
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | A
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which dispatch gate is vehicle QV44N7EA assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Balanced
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "C",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | C
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which class does vehicle QV44N7EA belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

Which control signal does device QD2WFFQ8 use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Fast
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "Fast",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Fast
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "A",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | A
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "Balanced",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Balanced
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "C",
  "pattern_label": "B",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | C
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "Quiet",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Quiet
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-004/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-004",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "K": "A",
    "R": "B",
    "Z": "C"
  },
  "source_a": "C",
  "source_b": "A",
  "item_id": "QV44N7EA",
  "target_position": 5,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV4PZMAJ | Cold | A
QV4QKXFN | Warm | B
QV4TAVMM | Warm | B
QV4C6GC5 | Mild | C
QV44N7EA | Warm | C
QV4T7S3Y | Warm | B
QV438CD7 | Cold | A
QV45FKVG | Mild | C
QV4GC2KW | Warm | B
QV4GEVNS | Cold | A
QV4UX7DZ | Warm | B
QV4LMESP | Cold | A
QV4PD4NF | Cold | A
QV4MCCKC | Mild | C
QV4TLC77 | Mild | C
QV4UPEUM | Mild | C
QV4DNBSW | Warm | B
QV4T9EAR | Mild | C
QV496FJK | Cold | A

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | R | R
A | K | K
C | Z | Z

Which dispatch gate is vehicle QV44N7EA assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Quiet
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Balanced
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/a/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | A
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which dispatch gate is vehicle QV598S3R assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Balanced
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

Which control signal does device QD4LGPFS use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Balanced
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

Which control signal does device QD3DWH3H use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Balanced
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

Which control signal does device QD1LY6LN use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | C
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "Balanced",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Balanced
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "B",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | B
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | B
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-003/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-003",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "Quiet",
    "K": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Balanced",
  "item_id": "QD3DWH3H",
  "target_position": 2,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
North | Fast
South | Quiet

Device | Site
QD3KS63W | South
QD3MNHNH | East
QD3DWH3H | North

Device-specific settings:
QD3MNHNH: Fast
QD3DWH3H: Balanced
QD3KS63W: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | R | R
Balanced | K | K
Fast | Z | Z

What is device QD3DWH3H's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | C
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which dispatch gate is vehicle QV0WPLY6 assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "A",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | A
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "K": "Quiet",
    "R": "Balanced",
    "Z": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Balanced
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/b/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "visible",
  "expected": "Fast",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Fast
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "B",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | B
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | A
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/b/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "b",
  "query": "literal",
  "arm": "direct",
  "expected": "Balanced",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Balanced
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "Fast",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Fast
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | B
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which dispatch gate is vehicle QV3VU8W6 assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "R": "A",
    "K": "B",
    "Z": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | B
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/a/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "a",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Fast
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

Which control signal does device QD4LGPFS use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | A
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "Balanced",
  "pattern_label": "Quiet",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Balanced
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "Z": "Quiet",
    "K": "Balanced",
    "R": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-003/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-003",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "B",
  "pattern_label": "C",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "B",
  "source_b": "A",
  "item_id": "QV3VU8W6",
  "target_position": 2,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV3GQCZP | Cold | C
QV3VU8W6 | Cold | B
QV3WPW8S | Warm | A
QV3SM6AB | Mild | B
QV3GJJG6 | Mild | B
QV39MYZD | Warm | A
QV3A9YPJ | Cold | C
QV3YKCZR | Mild | B
QV3E9QSJ | Mild | B
QV3SPP2T | Warm | A
QV3WYS3V | Warm | A
QV3R3D23 | Warm | A
QV3MCH9G | Mild | B
QV3QMM2M | Cold | C
QV3J7CMK | Cold | C
QV39CN2P | Mild | B
QV3YRE38 | Cold | C
QV3PZCCL | Warm | A
QV3HAJGM | Cold | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
C | Z | Z
A | R | R

Which class does vehicle QV3VU8W6 belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-004/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-004",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "R": "Quiet",
    "Z": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Balanced",
  "item_id": "QD4LGPFS",
  "target_position": 2,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Quiet
South | Balanced
North | Fast

Device | Site
QD42BXPH | South
QD49AXZK | North
QD4LGPFS | East

Device-specific settings:
QD49AXZK: Quiet
QD4LGPFS: Balanced
QD42BXPH: Balanced

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | K | K
Balanced | Z | Z
Quiet | R | R

What is device QD4LGPFS's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | C
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which class does vehicle QV0WPLY6 belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/b/downstream/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | B
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which dispatch gate is vehicle QV2DH6ZA assigned to?
Use K, Z, or R for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/a/literal/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "visible",
  "expected": "C",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | C
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use A, B, or C for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-001/b/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-001",
  "family": "configuration",
  "value": "b",
  "query": "encoded",
  "arm": "visible",
  "expected": "R",
  "pattern_label": "K",
  "decode_map": {
    "K": "Quiet",
    "Z": "Balanced",
    "R": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Fast",
  "item_id": "QD1LY6LN",
  "target_position": 1,
  "pattern_source": "Quiet"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Quiet
North | Fast

Device | Site
QD1DNX7N | East
QD1LY6LN | South
QD125X6E | North

Device-specific settings:
QD1LY6LN: Fast
QD125X6E: Fast
QD1DNX7N: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Quiet | K | K
Fast | R | R
Balanced | Z | Z

What is device QD1LY6LN's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/a/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "a",
  "query": "encoded",
  "arm": "direct",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Fast
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

What is device QD5WR8YT's active mode?
Use the mode's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-005/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-005",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "R": "A",
    "Z": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "B",
  "item_id": "QV598S3R",
  "target_position": 13,
  "pattern_source": "C"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV5BAR5W | Cold | A
QV5BARCW | Cold | A
QV5Y2B4P | Cold | A
QV54RHCJ | Warm | C
QV5KDJMR | Warm | C
QV5S9AZK | Cold | A
QV55PY7B | Warm | C
QV53PQCF | Mild | B
QV5QEMTV | Mild | B
QV5HEJVW | Mild | B
QV5ZUSNV | Mild | B
QV5ZY2JG | Cold | A
QV598S3R | Warm | B
QV5LJABV | Warm | C
QV5NFZ9B | Warm | C
QV5YCDRD | Mild | B
QV5C4EEY | Cold | A
QV5EZWXU | Warm | C
QV5C8WK5 | Mild | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
B | Z | Z
C | K | K
A | R | R

Which class does vehicle QV598S3R belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-005/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-005",
  "family": "configuration",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "R",
  "decode_map": {
    "Z": "Quiet",
    "R": "Balanced",
    "K": "Fast"
  },
  "source_a": "Fast",
  "source_b": "Quiet",
  "item_id": "QD5WR8YT",
  "target_position": 2,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
East | Fast
South | Quiet

Device | Site
QD5GBK3U | South
QD5M7QFZ | East
QD5WR8YT | North

Device-specific settings:
QD5GBK3U: Balanced
QD5WR8YT: Quiet
QD5M7QFZ: Fast

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Balanced | R | R
Quiet | Z | Z
Fast | K | K

Which control signal does device QD5WR8YT use?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "C",
  "pattern_label": "A",
  "decode_map": {
    "A": "A",
    "B": "B",
    "C": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | C
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which class does vehicle QV2DH6ZA belong to?
Use A, B, or C for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-002/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-002",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "Quiet",
  "pattern_label": "Balanced",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Quiet",
  "source_b": "Fast",
  "item_id": "QD2WFFQ8",
  "target_position": 3,
  "pattern_source": "Balanced"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
East | Balanced
South | Fast
North | Quiet

Device | Site
QD2WFFQ8 | East
QD2SPUZD | South
QD2M38PD | North

Device-specific settings:
QD2SPUZD: Balanced
QD2M38PD: Fast
QD2WFFQ8: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Control signal | Mode in coded notation
Fast | R | R
Quiet | Z | Z
Balanced | K | K

What is device QD2WFFQ8's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-000/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-000",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "R",
  "decode_map": {
    "Z": "A",
    "R": "B",
    "K": "C"
  },
  "source_a": "A",
  "source_b": "C",
  "item_id": "QV0WPLY6",
  "target_position": 8,
  "pattern_source": "B"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV0VDSYK | Warm | B
QV04AJUP | Cold | A
QV0D9DXW | Cold | A
QV0585MN | Mild | C
QV0SBC74 | Warm | B
QV0BR6FY | Warm | B
QV08ML5V | Cold | A
QV0WPLY6 | Warm | C
QV0MDBBX | Cold | A
QV0K747K | Mild | C
QV0AV6AZ | Mild | C
QV0ZNRUY | Warm | B
QV07F9Z9 | Mild | C
QV07UDU4 | Warm | B
QV02KSWK | Warm | B
QV05YA2R | Cold | A
QV0R7C86 | Cold | A
QV0TML9J | Mild | C
QV03P8WB | Mild | C

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | K | K
A | Z | Z
B | R | R

Which dispatch gate is vehicle QV0WPLY6 assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-configuration-000/a/literal/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-configuration-000",
  "family": "configuration",
  "value": "a",
  "query": "literal",
  "arm": "direct",
  "expected": "Balanced",
  "pattern_label": "Fast",
  "decode_map": {
    "Quiet": "Quiet",
    "Balanced": "Balanced",
    "Fast": "Fast"
  },
  "source_a": "Balanced",
  "source_b": "Quiet",
  "item_id": "QD0E8UZ4",
  "target_position": 1,
  "pattern_source": "Fast"
}
```

### Exact user message

```text
A device-specific setting determines the active mode when present.
Otherwise the site default applies, if one exists.

Site | Default mode
North | Balanced
South | Quiet
East | Fast

Device | Site
QD0E8UZ4 | East
QD0B384G | North
QD04223D | South

Device-specific settings:
QD0E8UZ4: Balanced
QD04223D: Fast
QD0B384G: Quiet

Modes can also be written using the following coded notation.
A device's control signal is determined by its active mode.

Mode | Mode in coded notation | Control signal
Quiet | K | K
Balanced | R | R
Fast | Z | Z

What is device QD0E8UZ4's active mode?
Use Quiet, Balanced, or Fast for your final answer.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-002/b/downstream/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-002",
  "family": "vehicle",
  "value": "b",
  "query": "downstream",
  "arm": "visible",
  "expected": "Z",
  "pattern_label": "K",
  "decode_map": {
    "K": "A",
    "Z": "B",
    "R": "C"
  },
  "source_a": "C",
  "source_b": "B",
  "item_id": "QV2DH6ZA",
  "target_position": 9,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV2TK78U | Warm | C
QV2XBP4N | Warm | C
QV2NVCVE | Cold | B
QV24TPYJ | Cold | B
QV2LX52Z | Cold | B
QV2H7E8D | Mild | A
QV23GSFJ | Warm | C
QV2T5JHB | Warm | C
QV2DH6ZA | Mild | B
QV27CPJE | Mild | A
QV2K7R9X | Warm | C
QV2FDMH7 | Mild | A
QV2CL34K | Warm | C
QV2KL9SF | Mild | A
QV279S7G | Mild | A
QV2W8MGV | Cold | B
QV2G4BX2 | Cold | B
QV2PHRGF | Mild | A
QV2VJYAC | Cold | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Class in coded notation | Dispatch gate
C | R | R
B | Z | Z
A | K | K

Which dispatch gate is vehicle QV2DH6ZA assigned to?
Use K, Z, or R for your final answer.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/b/encoded/direct

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "b",
  "query": "encoded",
  "arm": "direct",
  "expected": "R",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | C
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Give only your final answer in this format:
FINAL: <answer>
```

## query-role-vehicle-001/a/encoded/visible

### Metadata — not sent to the model

```json
{
  "world_id": "query-role-vehicle-001",
  "family": "vehicle",
  "value": "a",
  "query": "encoded",
  "arm": "visible",
  "expected": "K",
  "pattern_label": "Z",
  "decode_map": {
    "Z": "A",
    "K": "B",
    "R": "C"
  },
  "source_a": "B",
  "source_b": "C",
  "item_id": "QV1FWY2T",
  "target_position": 6,
  "pattern_source": "A"
}
```

### Exact user message

```text
Each vehicle has a fixed class: A, B, or C.
The vehicle records below are accurate.

Vehicle | Region | Class
QV1UGQQS | Cold | C
QV1R42GB | Mild | A
QV1QV667 | Mild | A
QV1XJ2LY | Cold | C
QV1AMH3F | Warm | B
QV1FWY2T | Mild | B
QV12469X | Mild | A
QV1WWKWK | Warm | B
QV1FWECS | Warm | B
QV1ZXM7G | Cold | C
QV1FFKN3 | Warm | B
QV1T9VJ2 | Mild | A
QV1CQ8CQ | Mild | A
QV19KB3A | Cold | C
QV1BHGWT | Warm | B
QV1NJRHT | Cold | C
QV1D6DR8 | Mild | A
QV1HDQ8F | Cold | C
QV1F9M45 | Warm | B

Classes can also be written using the following coded notation.
A vehicle's dispatch gate is determined by its class.

Class | Dispatch gate | Class in coded notation
B | K | K
A | Z | Z
C | R | R

Which class does vehicle QV1FWY2T belong to?
Use the class's coded notation for your final answer: K, Z, or R.

Explain your answer step by step, then give your final answer in this format:
FINAL: <answer>
```

